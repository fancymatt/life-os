--
-- PostgreSQL database dump
--

\restrict oB2pJ2mm1B2BDDjdWCFufQGTIqiKvMjvob5BpZhu7xbxS36OJURv5fVX6HgIDw0

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.story_scenes DROP CONSTRAINT IF EXISTS fk_story_scenes_story_id_stories;
ALTER TABLE IF EXISTS ONLY public.stories DROP CONSTRAINT IF EXISTS fk_stories_user_id_users;
ALTER TABLE IF EXISTS ONLY public.stories DROP CONSTRAINT IF EXISTS fk_stories_character_id_characters;
ALTER TABLE IF EXISTS ONLY public.outfits DROP CONSTRAINT IF EXISTS fk_outfits_user_id_users;
ALTER TABLE IF EXISTS ONLY public.images DROP CONSTRAINT IF EXISTS fk_images_user_id_users;
ALTER TABLE IF EXISTS ONLY public.image_entity_relationships DROP CONSTRAINT IF EXISTS fk_image_entity_relationships_image_id_images;
ALTER TABLE IF EXISTS ONLY public.favorites DROP CONSTRAINT IF EXISTS fk_favorites_user_id_users;
ALTER TABLE IF EXISTS ONLY public.compositions DROP CONSTRAINT IF EXISTS fk_compositions_user_id_users;
ALTER TABLE IF EXISTS ONLY public.clothing_items DROP CONSTRAINT IF EXISTS fk_clothing_items_user_id_users;
ALTER TABLE IF EXISTS ONLY public.characters DROP CONSTRAINT IF EXISTS fk_characters_user_id_users;
ALTER TABLE IF EXISTS ONLY public.board_games DROP CONSTRAINT IF EXISTS fk_board_games_user_id_users;
DROP INDEX IF EXISTS public.ix_users_username;
DROP INDEX IF EXISTS public.ix_users_email;
DROP INDEX IF EXISTS public.ix_story_scenes_story_id;
DROP INDEX IF EXISTS public.ix_story_scenes_scene_id;
DROP INDEX IF EXISTS public.ix_stories_user_id;
DROP INDEX IF EXISTS public.ix_stories_story_id;
DROP INDEX IF EXISTS public.ix_stories_character_id;
DROP INDEX IF EXISTS public.ix_scene_story_number;
DROP INDEX IF EXISTS public.ix_relationship_unique;
DROP INDEX IF EXISTS public.ix_relationship_image;
DROP INDEX IF EXISTS public.ix_relationship_entity;
DROP INDEX IF EXISTS public.ix_outfits_user_id;
DROP INDEX IF EXISTS public.ix_outfits_outfit_id;
DROP INDEX IF EXISTS public.ix_images_user_id;
DROP INDEX IF EXISTS public.ix_images_image_id;
DROP INDEX IF EXISTS public.ix_image_user_created;
DROP INDEX IF EXISTS public.ix_image_entity_relationships_role;
DROP INDEX IF EXISTS public.ix_image_entity_relationships_image_id;
DROP INDEX IF EXISTS public.ix_image_entity_relationships_entity_type;
DROP INDEX IF EXISTS public.ix_image_entity_relationships_entity_id;
DROP INDEX IF EXISTS public.ix_favorites_user_id;
DROP INDEX IF EXISTS public.ix_favorites_category;
DROP INDEX IF EXISTS public.ix_favorite_user_category;
DROP INDEX IF EXISTS public.ix_favorite_unique;
DROP INDEX IF EXISTS public.ix_compositions_user_id;
DROP INDEX IF EXISTS public.ix_compositions_composition_id;
DROP INDEX IF EXISTS public.ix_composition_user_id;
DROP INDEX IF EXISTS public.ix_composition_name;
DROP INDEX IF EXISTS public.ix_clothing_user_category;
DROP INDEX IF EXISTS public.ix_clothing_items_user_id;
DROP INDEX IF EXISTS public.ix_clothing_items_item_id;
DROP INDEX IF EXISTS public.ix_clothing_items_category;
DROP INDEX IF EXISTS public.ix_characters_user_id;
DROP INDEX IF EXISTS public.ix_characters_name;
DROP INDEX IF EXISTS public.ix_characters_character_id;
DROP INDEX IF EXISTS public.ix_character_user_id_name;
DROP INDEX IF EXISTS public.ix_boardgame_user_name;
DROP INDEX IF EXISTS public.ix_boardgame_bgg_id;
DROP INDEX IF EXISTS public.ix_board_games_user_id;
DROP INDEX IF EXISTS public.ix_board_games_name;
DROP INDEX IF EXISTS public.ix_board_games_game_id;
DROP INDEX IF EXISTS public.ix_board_games_bgg_id;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS pk_users;
ALTER TABLE IF EXISTS ONLY public.story_scenes DROP CONSTRAINT IF EXISTS pk_story_scenes;
ALTER TABLE IF EXISTS ONLY public.stories DROP CONSTRAINT IF EXISTS pk_stories;
ALTER TABLE IF EXISTS ONLY public.outfits DROP CONSTRAINT IF EXISTS pk_outfits;
ALTER TABLE IF EXISTS ONLY public.images DROP CONSTRAINT IF EXISTS pk_images;
ALTER TABLE IF EXISTS ONLY public.image_entity_relationships DROP CONSTRAINT IF EXISTS pk_image_entity_relationships;
ALTER TABLE IF EXISTS ONLY public.favorites DROP CONSTRAINT IF EXISTS pk_favorites;
ALTER TABLE IF EXISTS ONLY public.compositions DROP CONSTRAINT IF EXISTS pk_compositions;
ALTER TABLE IF EXISTS ONLY public.clothing_items DROP CONSTRAINT IF EXISTS pk_clothing_items;
ALTER TABLE IF EXISTS ONLY public.characters DROP CONSTRAINT IF EXISTS pk_characters;
ALTER TABLE IF EXISTS ONLY public.board_games DROP CONSTRAINT IF EXISTS pk_board_games;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.story_scenes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.stories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.outfits ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.images ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.image_entity_relationships ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.favorites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.compositions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.clothing_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.characters ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.board_games ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.story_scenes_id_seq;
DROP TABLE IF EXISTS public.story_scenes;
DROP SEQUENCE IF EXISTS public.stories_id_seq;
DROP TABLE IF EXISTS public.stories;
DROP SEQUENCE IF EXISTS public.outfits_id_seq;
DROP TABLE IF EXISTS public.outfits;
DROP SEQUENCE IF EXISTS public.images_id_seq;
DROP TABLE IF EXISTS public.images;
DROP SEQUENCE IF EXISTS public.image_entity_relationships_id_seq;
DROP TABLE IF EXISTS public.image_entity_relationships;
DROP SEQUENCE IF EXISTS public.favorites_id_seq;
DROP TABLE IF EXISTS public.favorites;
DROP SEQUENCE IF EXISTS public.compositions_id_seq;
DROP TABLE IF EXISTS public.compositions;
DROP SEQUENCE IF EXISTS public.clothing_items_id_seq;
DROP TABLE IF EXISTS public.clothing_items;
DROP SEQUENCE IF EXISTS public.characters_id_seq;
DROP TABLE IF EXISTS public.characters;
DROP SEQUENCE IF EXISTS public.board_games_id_seq;
DROP TABLE IF EXISTS public.board_games;
DROP TABLE IF EXISTS public.alembic_version;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: lifeos
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO lifeos;

--
-- Name: board_games; Type: TABLE; Schema: public; Owner: lifeos
--

CREATE TABLE public.board_games (
    id integer NOT NULL,
    game_id character varying(50) NOT NULL,
    name character varying(500) NOT NULL,
    bgg_id integer,
    designer character varying(500),
    publisher character varying(500),
    year integer,
    description text,
    player_count_min integer,
    player_count_max integer,
    playtime_min integer,
    playtime_max integer,
    complexity double precision,
    metadata json NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_id integer
);


ALTER TABLE public.board_games OWNER TO lifeos;

--
-- Name: board_games_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeos
--

CREATE SEQUENCE public.board_games_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.board_games_id_seq OWNER TO lifeos;

--
-- Name: board_games_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeos
--

ALTER SEQUENCE public.board_games_id_seq OWNED BY public.board_games.id;


--
-- Name: characters; Type: TABLE; Schema: public; Owner: lifeos
--

CREATE TABLE public.characters (
    id integer NOT NULL,
    character_id character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    visual_description text,
    physical_description text,
    personality text,
    reference_image_path character varying(500),
    age character varying(100),
    skin_tone character varying(100),
    face_description text,
    hair_description text,
    body_description text,
    tags json NOT NULL,
    metadata json NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_id integer
);


ALTER TABLE public.characters OWNER TO lifeos;

--
-- Name: characters_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeos
--

CREATE SEQUENCE public.characters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.characters_id_seq OWNER TO lifeos;

--
-- Name: characters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeos
--

ALTER SEQUENCE public.characters_id_seq OWNED BY public.characters.id;


--
-- Name: clothing_items; Type: TABLE; Schema: public; Owner: lifeos
--

CREATE TABLE public.clothing_items (
    id integer NOT NULL,
    item_id character varying(50) NOT NULL,
    category character varying(100) NOT NULL,
    item character varying(500) NOT NULL,
    fabric text,
    color character varying(255),
    details text,
    source_image character varying(500),
    preview_image_path character varying(500),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone,
    user_id integer
);


ALTER TABLE public.clothing_items OWNER TO lifeos;

--
-- Name: clothing_items_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeos
--

CREATE SEQUENCE public.clothing_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clothing_items_id_seq OWNER TO lifeos;

--
-- Name: clothing_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeos
--

ALTER SEQUENCE public.clothing_items_id_seq OWNED BY public.clothing_items.id;


--
-- Name: compositions; Type: TABLE; Schema: public; Owner: lifeos
--

CREATE TABLE public.compositions (
    id integer NOT NULL,
    composition_id character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    subject character varying(500) NOT NULL,
    presets json NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_id integer
);


ALTER TABLE public.compositions OWNER TO lifeos;

--
-- Name: compositions_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeos
--

CREATE SEQUENCE public.compositions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.compositions_id_seq OWNER TO lifeos;

--
-- Name: compositions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeos
--

ALTER SEQUENCE public.compositions_id_seq OWNED BY public.compositions.id;


--
-- Name: favorites; Type: TABLE; Schema: public; Owner: lifeos
--

CREATE TABLE public.favorites (
    id integer NOT NULL,
    user_id integer NOT NULL,
    category character varying(100) NOT NULL,
    preset_id character varying(100) NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.favorites OWNER TO lifeos;

--
-- Name: favorites_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeos
--

CREATE SEQUENCE public.favorites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.favorites_id_seq OWNER TO lifeos;

--
-- Name: favorites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeos
--

ALTER SEQUENCE public.favorites_id_seq OWNED BY public.favorites.id;


--
-- Name: image_entity_relationships; Type: TABLE; Schema: public; Owner: lifeos
--

CREATE TABLE public.image_entity_relationships (
    id integer NOT NULL,
    image_id character varying(100) NOT NULL,
    entity_type character varying(100) NOT NULL,
    entity_id character varying(100) NOT NULL,
    role character varying(100),
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.image_entity_relationships OWNER TO lifeos;

--
-- Name: image_entity_relationships_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeos
--

CREATE SEQUENCE public.image_entity_relationships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.image_entity_relationships_id_seq OWNER TO lifeos;

--
-- Name: image_entity_relationships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeos
--

ALTER SEQUENCE public.image_entity_relationships_id_seq OWNED BY public.image_entity_relationships.id;


--
-- Name: images; Type: TABLE; Schema: public; Owner: lifeos
--

CREATE TABLE public.images (
    id integer NOT NULL,
    image_id character varying(100) NOT NULL,
    file_path character varying(500) NOT NULL,
    filename character varying(255) NOT NULL,
    width integer,
    height integer,
    generation_metadata json NOT NULL,
    created_at timestamp without time zone NOT NULL,
    user_id integer
);


ALTER TABLE public.images OWNER TO lifeos;

--
-- Name: images_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeos
--

CREATE SEQUENCE public.images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.images_id_seq OWNER TO lifeos;

--
-- Name: images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeos
--

ALTER SEQUENCE public.images_id_seq OWNED BY public.images.id;


--
-- Name: outfits; Type: TABLE; Schema: public; Owner: lifeos
--

CREATE TABLE public.outfits (
    id integer NOT NULL,
    outfit_id character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    style_genre character varying(100),
    formality character varying(100),
    clothing_item_ids json NOT NULL,
    source_image character varying(500),
    preview_image_path character varying(500),
    metadata json NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_id integer
);


ALTER TABLE public.outfits OWNER TO lifeos;

--
-- Name: outfits_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeos
--

CREATE SEQUENCE public.outfits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.outfits_id_seq OWNER TO lifeos;

--
-- Name: outfits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeos
--

ALTER SEQUENCE public.outfits_id_seq OWNED BY public.outfits.id;


--
-- Name: stories; Type: TABLE; Schema: public; Owner: lifeos
--

CREATE TABLE public.stories (
    id integer NOT NULL,
    story_id character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    content text NOT NULL,
    character_id character varying(50),
    theme character varying(100),
    story_type character varying(50),
    word_count integer NOT NULL,
    metadata json NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_id integer
);


ALTER TABLE public.stories OWNER TO lifeos;

--
-- Name: stories_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeos
--

CREATE SEQUENCE public.stories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stories_id_seq OWNER TO lifeos;

--
-- Name: stories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeos
--

ALTER SEQUENCE public.stories_id_seq OWNED BY public.stories.id;


--
-- Name: story_scenes; Type: TABLE; Schema: public; Owner: lifeos
--

CREATE TABLE public.story_scenes (
    id integer NOT NULL,
    scene_id character varying(50) NOT NULL,
    story_id character varying(50) NOT NULL,
    scene_number integer NOT NULL,
    title character varying(500) NOT NULL,
    content text NOT NULL,
    action text,
    illustration_prompt text,
    illustration_url character varying(500),
    metadata json NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.story_scenes OWNER TO lifeos;

--
-- Name: story_scenes_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeos
--

CREATE SEQUENCE public.story_scenes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.story_scenes_id_seq OWNER TO lifeos;

--
-- Name: story_scenes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeos
--

ALTER SEQUENCE public.story_scenes_id_seq OWNED BY public.story_scenes.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: lifeos
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    full_name character varying(255),
    hashed_password character varying(255) NOT NULL,
    disabled boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    last_login timestamp without time zone
);


ALTER TABLE public.users OWNER TO lifeos;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: lifeos
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO lifeos;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lifeos
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: board_games id; Type: DEFAULT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.board_games ALTER COLUMN id SET DEFAULT nextval('public.board_games_id_seq'::regclass);


--
-- Name: characters id; Type: DEFAULT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.characters ALTER COLUMN id SET DEFAULT nextval('public.characters_id_seq'::regclass);


--
-- Name: clothing_items id; Type: DEFAULT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.clothing_items ALTER COLUMN id SET DEFAULT nextval('public.clothing_items_id_seq'::regclass);


--
-- Name: compositions id; Type: DEFAULT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.compositions ALTER COLUMN id SET DEFAULT nextval('public.compositions_id_seq'::regclass);


--
-- Name: favorites id; Type: DEFAULT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.favorites ALTER COLUMN id SET DEFAULT nextval('public.favorites_id_seq'::regclass);


--
-- Name: image_entity_relationships id; Type: DEFAULT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.image_entity_relationships ALTER COLUMN id SET DEFAULT nextval('public.image_entity_relationships_id_seq'::regclass);


--
-- Name: images id; Type: DEFAULT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.images ALTER COLUMN id SET DEFAULT nextval('public.images_id_seq'::regclass);


--
-- Name: outfits id; Type: DEFAULT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.outfits ALTER COLUMN id SET DEFAULT nextval('public.outfits_id_seq'::regclass);


--
-- Name: stories id; Type: DEFAULT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.stories ALTER COLUMN id SET DEFAULT nextval('public.stories_id_seq'::regclass);


--
-- Name: story_scenes id; Type: DEFAULT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.story_scenes ALTER COLUMN id SET DEFAULT nextval('public.story_scenes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: lifeos
--

COPY public.alembic_version (version_num) FROM stdin;
f85c460c4214
\.


--
-- Data for Name: board_games; Type: TABLE DATA; Schema: public; Owner: lifeos
--

COPY public.board_games (id, game_id, name, bgg_id, designer, publisher, year, description, player_count_min, player_count_max, playtime_min, playtime_max, complexity, metadata, created_at, updated_at, user_id) FROM stdin;
1	bgg-420033	Vantage	420033	Jamey Stegmaier	Stonemaier Games, Feuerland Spiele, Keep Exploring Games, Maldito Games	2025	Vantage is an open-world, co-operative, non-campaign adventure game that features an entire planet to explore, with&nbsp;players communicating while scattered across the world. With nearly eight hundred interconnected locations on four hundred cards and over nine hundred other discoverable cards, the world is your sandbox.&#10;&#10;You begin each game of Vantage on an intergalactic vessel heading towards an uncharted planet. After crashing far from your companions, you have complete freedom as to how you explore, discover, and interact with the planet. You view your location from a first-person perspective, and you can communicate with and support other players, but you are separated by vast distances, so only you can see your current location.&#10;&#10;In addition to a mission victory, a destiny victory, or an epic victory (completing both the mission and a destiny), you may define success in Vantage through anything you pursue and achieve.&#10;&#10;Vantage is not a campaign game. Each game is a standalone experience; you bring to future sessions only what you&rsquo;ve learned about the world. It is completely self-contained with no&nbsp;expansions &mdash; just a few accessories like metal coins.&#10;&#10;&mdash;description from the publisher&#10;&#10;	1	6	120	180	2.3315	{}	2025-10-18 13:05:11.450588	2025-10-18 18:31:35.012507	1
\.


--
-- Data for Name: characters; Type: TABLE DATA; Schema: public; Owner: lifeos
--

COPY public.characters (id, character_id, name, visual_description, physical_description, personality, reference_image_path, age, skin_tone, face_description, hair_description, body_description, tags, metadata, created_at, updated_at, user_id) FROM stdin;
1	cc68e0e0	Kylee	An attractive young adult woman with an oval face and light skin. She has shoulder-length wavy brown hair with subtle highlights and blue eyes. She appears to be of average height with a slender build. Her face is unmarked by distinctive features, presenting a clean, youthful appearance.	A young adult woman with an oval face, feminine features, and light skin tone with European characteristics. She has blue eyes and a slight smile. Her shoulder-length wavy brown hair has subtle highlights. She appears to be of average height with a slender build.	Hipster, cool	/app/data/characters/cc68e0e0_ref.png	young adult	light	Oval face with feminine features, blue eyes, and European characteristics. Slight smile.	Shoulder-length wavy brown hair with subtle highlights.	Average height with slender build.	[]	{}	2025-10-16 20:19:30.048984	2025-10-17 01:01:36.642662	1
2	e1f4fe53	Jenny	\N	A smiling young adult woman with a round face and light skin tone. She has blue eyes and short blonde hair styled in a layered pixie cut with side-swept bangs. Her build appears slender and she is of average height.	\N	/app/data/characters/e1f4fe53_ref.png	young adult	light	Round face with feminine features, blue eyes, and a warm smile. Noticeable cheekbones and a slightly pointed chin. No apparent ethnic features are clearly visible.	Short blonde hair, styled in a layered pixie cut with side-swept bangs. The texture appears to be fine and straight.	Average height with a slender build.	[]	{}	2025-10-16 18:10:40.467313	2025-10-17 01:40:48.404208	1
3	8bf67f72	Cassie	\N	A smiling young adult woman with an oval face, feminine features, light skin tone and blue eyes. Her long, wavy blonde hair is parted to the side. She has an average height and build.	\N	/app/data/characters/8bf67f72_ref.png	young adult	light	Oval face with feminine features and blue eyes. Noticeable smile. Appears to have European features. No distinctive marks.	Long, wavy blonde hair with highlights. Hair is parted to the side and falls to the shoulders.	Average height with an average build.	[]	{}	2025-10-16 20:18:25.038423	2025-10-17 01:39:31.306374	1
4	41c5726d	Joelle	\N	A young adult woman with light skin and an oval face, displaying feminine features and a warm smile. Her brown almond-shaped eyes are complemented by medium-length, wavy brown hair. She appears to be of average height with a slender to average build.	\N	/app/data/characters/41c5726d_ref.png	young adult	light	Oval face with feminine features, brown almond-shaped eyes, and a warm smile. Some have distinctive square glasses and thinner lips. Evidence of potential European ancestry.	Medium-length, wavy brown hair, often styled with loose curls or waves. Color varies from reddish brown to dark brown.	Appears to be of average height with a slender to average build.	[]	{}	2025-10-16 18:10:47.601157	2025-10-17 01:41:13.614427	1
5	e6ead260	Mckell	A young adult woman with an oval face and light skin tone. She has shoulder-length, straight brown hair with subtle auburn highlights and brown eyes. She appears to be of average height with an average build.	A young adult woman with an oval face, feminine features, and light skin tone with European characteristics. She has blue eyes and a slight smile. Her shoulder-length straight brown hair has a side part. She appears to be of average height with a slender build.	Sassy, friendly, cool	/app/data/characters/e6ead260_ref.png	young adult	light	Oval face with feminine features and blue eyes. European features with a slight smile.	Shoulder-length straight brown hair with a side part.	Average height with a slender build.	[]	{}	2025-10-16 23:23:07.500719	2025-10-17 00:57:43.337391	1
6	ed013856	Kaysha	A smiling young adult woman with an oval face and fair skin. She has short, wavy blonde hair with a side part and bangs, and blue eyes. She has a slender build and appears to be of average height. She has no distinctive features.	A young adult woman with fair skin and an oval face. She has blue eyes and European features, accentuated by high cheekbones and a warm smile. Her short, wavy blonde hair is styled in a bob with side-swept bangs. She has an average height and slender build.	Alternative, cheerful, perky	/app/data/characters/ed013856_ref.png	young adult	fair	Oval face with feminine features, blue eyes, and European features. High cheekbones, and a bright smile.	Short, wavy blonde hair, styled in a bob with side-swept bangs.	Average height with a slender build.	[]	{}	2025-10-16 20:19:21.417331	2025-10-17 01:01:46.342123	1
7	1a496619	Jaimee	\N	A middle-aged woman with a round face, feminine features, and light skin tone. She has brown eyes and appears to have European characteristics. She wears black framed glasses. Her shoulder length, wavy brown hair frames her face. She is of average height with an average build.	\N	/app/data/characters/1a496619_ref.png	middle-aged	light	Round face with feminine features, brown eyes, and European characteristics. Wears black framed glasses.	Shoulder length, wavy brown hair.	Average height, average build.	[]	{}	2025-10-16 18:10:47.454434	2025-10-17 01:40:57.23168	1
8	ac73052d	Vanessa	\N	A young adult woman with a round face and light skin tone. She has light brown eyes and freckles. Her medium length brown hair is styled differently in the images. She has an average height and a medium build. Appears to have European features.	\N	/app/data/characters/ac73052d_ref.png	young adult	light	Round face with feminine features, light brown eyes. Some freckles are visible. Appears to have European features.	Medium length brown hair, styles vary between straight and wavy.	Average height, medium build.	[]	{}	2025-10-16 18:10:47.530375	2025-10-17 01:41:05.303298	1
9	ed394873	Jessi	\N	A young adult woman with an oval face, feminine features, and light skin. She has brown eyes and a gentle smile. Her shoulder-length, straight, dark brown hair is neatly styled. She has an average height and slender build.	\N	/app/data/characters/ed394873_ref.png	young adult	light	Oval face with feminine features, brown eyes, and a straight nose. European features with a gentle smile.	Shoulder-length, straight, dark brown hair, neatly styled.	Average height and slender build.	[]	{}	2025-10-16 20:19:04.273898	2025-10-17 01:39:06.853369	1
10	1d191360	Kat	A blonde young woman with fair skin and an oval face. Her shoulder-length blonde hair is styled in soft waves. She has blue eyes with long eyelashes, an average build, and appears to be of average height. She has no visible distinctive features.	A young adult woman with an oval face, feminine features, and light skin tone with European characteristics. She has blue eyes. Her shoulder-length wavy blonde hair has dark roots. She appears to be of average height with a curvy build.	Glamorous, dramatic, Scottish	/app/data/characters/1d191360_ref.png	young adult	light	Oval face with feminine features, blue eyes, and European characteristics. Full lips and arched eyebrows.	Shoulder-length wavy blonde hair with dark roots.	Average height with curvy build.	[]	{}	2025-10-16 20:19:12.940108	2025-10-17 01:02:21.821922	1
11	1af92043	Tanya	A young adult woman with an oval face and light skin tone. She has short, wavy blonde hair and brown eyes. She appears to be of average height with a slender build. She has dimples that are visible when she smiles.	A young adult woman with an oval face and light skin tone, exhibiting feminine features. Her brown eyes complement her warm smile. She has shoulder-length blonde hair styled in soft waves. With an average height and slender build, she presents a professional and approachable demeanor.	Friendly, preppy, bright	/app/data/characters/1af92043_ref.png	young adult	light	Oval face with feminine features, brown eyes, and a warm smile. European characteristics are apparent. No distinctive features are particularly noticeable.	Shoulder-length blonde hair, styled in soft waves. The texture appears fine and slightly highlighted.	Appears to be of average height and slender build. Well-proportioned physique.	[]	{}	2025-10-16 20:19:40.672037	2025-10-17 01:01:12.147242	1
12	165d9c0c	Izzy	\N	A young adult female with a light complexion, an oval face, and blue eyes, possibly of European descent. Her shoulder-length reddish-brown hair is straight with subtle highlights. She appears to be of average height with a slender build.	\N	/app/data/characters/165d9c0c_ref.png	young adult	light	Oval face with feminine features, blue eyes, and possible European descent. Small nose, full lips. No distinctive features noted.	Shoulder-length straight reddish-brown hair with subtle highlights.	Average height with slender build.	[]	{}	2025-10-16 20:18:53.194168	2025-10-17 01:39:20.95222	1
13	e9f5d330	Lynelle	\N	This collage showcases a young adult woman with light skin, exhibiting various face shapes such as oval and round, and feminine features. Her eye color includes shades of blue and green, suggesting possible European features. Her hair ranges in color from blonde to brown, with lengths varying from short to shoulder-length and styles including straight and wavy textures. Her body build appears to be between slender and average in height.	\N	/app/data/characters/e9f5d330_ref.png	young adult	light	Various face shapes including oval and round, feminine features, predominantly blue and green eyes, possible European features.	Varying hair colors of blonde and brown, lengths range from short to shoulder-length, styles include straight and wavy.	Appears to be of average height, with a slender to average build.	[]	{}	2025-10-16 18:10:47.781273	2025-10-17 01:41:22.516421	1
\.


--
-- Data for Name: clothing_items; Type: TABLE DATA; Schema: public; Owner: lifeos
--

COPY public.clothing_items (id, item_id, category, item, fabric, color, details, source_image, preview_image_path, created_at, updated_at, user_id) FROM stdin;
1	5f10aca6-843e-4132-bc49-129be0d919b4	earrings	domed stud earrings	resin or enamel-coated metal posts with glossy finish	solid tangerine orange	Circular, button-style studs approximately 12–14 mm diameter. High-polish dome surface; posts and butterfly backs in silver-tone metal. Positioned to echo the orange accents in the outfit.	/app/uploads/temp/f95feaac-6eff-43a1-8956-d08435e4601d_cate.jpg	/output/clothing_items/5f10aca6-843e-4132-bc49-129be0d919b4_preview.png	2025-10-22 18:02:31.726601	2025-10-22 22:50:14.708919	1
2	67d9317d-5ee2-4453-9c58-e733f6da8737	neckwear	tubular neck gaiter/face covering	nylon-spandex jersey, double-layered, lightweight with high stretch and matte finish	black, uniform matte	Simple cylindrical knit tube worn pulled up over the lower face and neck. Edges are clean overlocked or coverstitched for comfort. Snug fit due to elastic recovery; no visible logos or hardware. Sits beneath the jacket collar without adding bulk.	/app/uploads/temp/127eb0b1-8736-4a0c-a6f0-4e1ea2923c38_punk.png	/output/clothing_items/67d9317d-5ee2-4453-9c58-e733f6da8737_preview.png	2025-10-22 17:35:31.480389	2025-10-22 22:50:14.711073	1
3	85d38a7e-d2a7-4eb8-9546-a83290aa233c	outerwear	oversized classic motorcycle jacket with asymmetrical front zip	heavy full-grain leather with pronounced natural pebble, semi-matte surface; firm hand with broken-in creasing	rich carbon black with subtle satin sheen	Boxy, deliberately oversized silhouette with broad shoulders and voluminous sleeves. Large notched lapels with edge topstitching; each lapel point secured by nickel snap studs. Off-center exposed metal zipper closure runs from wearer’s right hip toward left chest; heavy-gauge nickel zipper with wide black tape. Pockets include: left chest slanted zip pocket; two vertical side-entry zip pockets; and a small left-front coin pocket with single-snap flap. Hem finished with an integrated leather belt threaded through wide leather belt loops; belt features five grommeted holes and a square single-prong roller buckle in nickel, with the belt tail left hanging forward. Front panels and collar edges show double-needle topstitching; seams appear clean-turned. Sleeves end in plain hems with no visible cuff zips. Overall finish exhibits light wear creasing consistent with thick leather. Worn open enough to reveal the inner top’s crew neckline.	/app/uploads/temp/99e6f109-7d74-498d-8c19-8742b6985ecb_oversized-jacket.png	/output/clothing_items/85d38a7e-d2a7-4eb8-9546-a83290aa233c_preview.png	2025-10-22 22:06:45.641002	2025-10-22 22:50:14.712247	1
5	0dd6359e-676d-47ae-9e6b-b0c7697b8d1e	bottoms	high-rise leather micro mini skirt with thigh slit	aniline-finished lambskin leather, smooth grain, medium weight, bonded to lightweight tricot for stability; lined with stretch poly-satin	deep true black, semi-matte	Body-skimming straight silhouette hitting high on the thigh; clean waistband with internal facing; darts shaping at front and back; narrow left-front slit for ease; center-back invisible zipper with hook-and-eye; 5 mm clean-turned hem with edge topstitch; crisp pressed appearance. The skirt sits under the open moto jacket and over the corset’s waist.	/app/uploads/temp/95f20449-faec-415a-a9cb-ba8553920db3_eclectic-4.png	/output/clothing_items/0dd6359e-676d-47ae-9e6b-b0c7697b8d1e_preview.png	2025-10-22 22:05:31.241557	2025-10-22 22:50:14.714362	1
6	84eeeaf4-3476-407d-b1a5-01bbe5edd3cf	neckwear	delicate pendant necklace	fine gold-plated cable chain with a small polished black charm (stone or enamel) pendant	yellow gold chain with black pendant	short collarbone-length chain (~40–45 cm) with a single round pendant centered at the base of the neck; clasp not visible; chain disappears under the jacket collar; understated, minimal profile.	/app/uploads/temp/2751f088-8936-401b-aeae-1bbe18114345_2025-08-09-080939_00004_.png	/output/clothing_items/84eeeaf4-3476-407d-b1a5-01bbe5edd3cf_preview.png	2025-10-22 21:56:41.04881	2025-10-22 22:50:14.715393	1
7	8bd5697e-e379-499d-8c6b-33dce5489a90	neckwear	narrow leather choker	smooth cowhide strap, edge-painted; small metal hardware	matte black strap with polished nickel hardware	Approx. 10–12 mm wide leather band encircling neck; center front features a small domed rivet or button stud accent. Back closure presumed adjustable with a mini roller buckle or snap set, allowing precise fit. Strap edges beveled and lacquered; single keeper loop to secure tail if buckled. Sits snugly above the jacket’s neckline, adding a minimalist, hard-edged accent.	/app/uploads/temp/9460a775-7bbc-4aa0-be25-84f381f04e15_maria-outfit.png	/output/clothing_items/8bd5697e-e379-499d-8c6b-33dce5489a90_preview.png	2025-10-22 22:11:40.291728	2025-10-22 22:50:14.71639	1
172	38fdf228-09d3-4268-91bc-216ea7379395	handwear	forearm-length leather gloves	full-grain lamb nappa leather, smooth and supple with semi-matte sheen; silk lining	jet black	close, tailored fit extending to mid-forearm to slide beneath coat sleeves; classic three-point decorative topstitching on back of hand; turned, edge-stitched openings; thumb and finger gussets for articulation; light hidden elastic at wrist for grip; fine tonal stitching with narrow seam allowances; gentle wear creasing enhances texture.	/app/uploads/temp/e3d895c1-af91-4e9a-a449-3dccebb57093_fur-fox_cyberpunk_jenny_20250928135503.png	/output/clothing_items/38fdf228-09d3-4268-91bc-216ea7379395_preview.png	2025-10-23 00:47:06.7882	2025-10-23 00:55:41.152064	1
9	0305d4db-ba3b-4015-a6e7-cc24d138a916	footwear	ankle boots with low wedge	smooth full-grain leather upper with matte finish; molded rubber outsole	solid black, matte	Pull-on ankle-height boots with rounded toe and integrated low wedge sole for slight lift. Minimal seam architecture with a single quarter seam; elasticized hidden gore or internal stretch panel for entry (not externally visible). Topline sits just above the ankle; outsole features a slightly flared edge and shallow tread. Clean, utilitarian styling complements the streamlined pants.	/app/uploads/temp/127eb0b1-8736-4a0c-a6f0-4e1ea2923c38_punk.png	/output/clothing_items/0305d4db-ba3b-4015-a6e7-cc24d138a916_preview.png	2025-10-22 17:35:31.479858	2025-10-22 22:50:14.718331	1
19	1996b6b6-13b0-44e2-8cc5-2d3b828ce5de	belts	wide waist belt with prong buckle	coated leather strap with firm interlining for stability; smooth grain	black strap with polished silver-tone hardware	Belt threaded through exterior belt loops on the jacket; approximately 5–6 cm wide. Oversized rectangular single-prong buckle in polished nickel-plated alloy with matching metal grommet eyelets. Ends are skived and edge-painted; multiple holes allow tight cinch at natural waist, shaping the coat.	/app/uploads/temp/f95feaac-6eff-43a1-8956-d08435e4601d_cate.jpg	/output/clothing_items/1996b6b6-13b0-44e2-8cc5-2d3b828ce5de_preview.png	2025-10-22 18:02:31.722915	2025-10-22 22:50:14.727937	1
10	e2476d30-c395-486a-b0c3-c64a65687a90	outerwear	fitted zip‑front leather jacket	smooth-grain lambskin leather with semi‑aniline finish; midweight, supple hand; fully lined in black acetate or polyester satin	cool black with semi‑gloss sheen	Collarless neckline with a minimal 1–1.5 cm band stand; center‑front separating coil zipper (approx. No.5) on black tape with gunmetal slider and straight puller; body sculpted with front and back princess seams and side panels to a cinched waist; subtle peplum flare at the high hip; hem edge‑stitched 2–3 mm; two‑piece slim sleeves with set‑in armholes, plain cuffs without zips or vents; leather seams topstitched narrowly for reinforcement; lightly padded shoulders for structure; no external pockets visible; jacket worn zipped to the sternum, exposing the underlying white shirt at the neckline and overlapping the skirt waistband.	/app/uploads/temp/c2a8339a-fd52-4f04-bb4d-c7f3dcd9b322_lucy.png	/output/clothing_items/e2476d30-c395-486a-b0c3-c64a65687a90_preview.png	2025-10-22 18:04:31.013545	2025-10-22 22:50:14.719322	1
11	7615138c-642d-4dc8-8671-ea495d4e0dd2	bottoms	slim-fit jeans	stretch denim, cotton with small elastane content; right-hand twill, 11–12 oz, matte	dark indigo blue with cool cast and minimal variation	Slim straight-through-thigh silhouette tapering slightly to the ankle (hem not visible). Clean, non-distressed finish. Standard five-pocket jean construction with belt loops presumed; topstitching appears tonal-dark. Waist sits at a mid-rise, worn beneath the jacket’s belted hem.	/app/uploads/temp/99e6f109-7d74-498d-8c19-8742b6985ecb_oversized-jacket.png	/output/clothing_items/7615138c-642d-4dc8-8671-ea495d4e0dd2_preview.png	2025-10-22 22:06:45.645949	2025-10-22 22:50:14.720333	1
12	6f6724b3-bc40-4df2-80dc-5272f30e4ef3	handwear	wrist-length leather gloves	soft lambskin leather, unlined or thinly lined; semi-matte sheen	deep black	Close-fitting five-finger gloves with precise finger shaping and curved thumb gusset. Small keyhole vent and short slit at the wrist for entry, finished with binding. Edges are neatly stitched; gloves tuck slightly under the jacket sleeves for a seamless look.	/app/uploads/temp/f95feaac-6eff-43a1-8956-d08435e4601d_cate.jpg	/output/clothing_items/6f6724b3-bc40-4df2-80dc-5272f30e4ef3_preview.png	2025-10-22 18:02:31.725259	2025-10-22 22:50:14.72128	1
14	54889628-d76e-46cc-9f85-87fd8488ef2c	outerwear	short-length shawl-collar fur coat	natural mink fur on leather pelt backing; dense, plush pile with high luster; heavy weight; typical satin lining structure	warm cognac brown with caramel undertones and natural tonal variegation, glossy finish	Voluminous, oversized silhouette with broad rounded shawl collar that transitions into wide front facings. Open-front styling with no closures engaged; edges smoothly turned with hidden facings. Dropped shoulders and generously cut sleeves with ample ease; horizontal pelt-panel seaming pattern is subtly visible. Upper-thigh length with straight hem. Worn open over the dress, allowing the structured leather beneath to contrast against the plush texture. No exterior pockets or trim visible; pile appears evenly brushed and aligned.	/app/uploads/temp/73632130-f8de-4a6e-b677-c51dadd8edc6_fur-dress.png	/output/clothing_items/54889628-d76e-46cc-9f85-87fd8488ef2c_preview.png	2025-10-22 22:05:30.01879	2025-10-22 22:50:14.723288	1
15	15cb3aa4-45f2-4bb4-9d9f-97fe65d6c6f0	one_piece	second-skin catsuit	heavy-gauge stretch knit (nylon/elastane) with polyurethane coating; smooth, slick hand; medium weight with compressive recovery; subtle satin sheen	deep jet black, semi-gloss finish	streamlined one-piece with long legs and close body; likely high crew neckline concealed by the coat; minimal seam architecture—side seams and inseams only—with narrow topstitched allowances; concealed center-back zipper with clean finish; hems are narrow coverstitched and tucked smoothly into ankle boots; garment provides a continuous, contouring surface that reads as liquid against the voluminous fur outerwear.	/app/uploads/temp/55a6131b-c6af-496a-aa79-269d6d927ad1_cruella-outfit.jpg	/output/clothing_items/15cb3aa4-45f2-4bb4-9d9f-97fe65d6c6f0_preview.png	2025-10-22 22:03:32.916863	2025-10-22 22:50:14.724207	1
16	f1beb717-b64a-4633-9d3a-729a2aa98e9d	footwear	pointed-toe stiletto ankle boots	polished calfskin leather upper with leather lining and leather outsole; stacked heel core wrapped in matching leather	ink black with high-polish gloss	sleek ankle-height boot with elongated pointed toe and narrow 80–90 mm stiletto heel; clean vamp with minimal seamwork—single medial zipper likely concealed; top line sits under fur gaiters; outsole edge inked black; refined last for tight ankle fit; boots disappear beneath the catsuit hem for a continuous leg line.	/app/uploads/temp/55a6131b-c6af-496a-aa79-269d6d927ad1_cruella-outfit.jpg	/output/clothing_items/f1beb717-b64a-4633-9d3a-729a2aa98e9d_preview.png	2025-10-22 22:03:32.920648	2025-10-22 22:50:14.7251	1
17	3ff93ded-e194-444c-b32d-f060570eee39	outerwear	cropped moto-style leather jacket	smooth-grain cowhide leather, medium weight with semi-matte finish and subtle natural sheen	inky black with cool slate undertone	Open-front styling with broad notched lapels; lapel points secured by small round press-studs in silver-tone metal. Set-in sleeves worn pushed to the elbow, creating intentional ruched creasing; plain sleeve hems without visible zippers. Cropped length terminating at the high waist, allowing the belt of the layer beneath to be visible. Edge construction features clean turned edges with double-needle topstitching along lapels, front edges, shoulder seams, and sleeve seams in matching black thread. No exterior pockets visible; minimal hardware beyond lapel snaps. The jacket is worn unfastened so the neckline of the dress is fully exposed, and the leather’s denser hand provides a matte contrast to the glossier dress.	/app/uploads/temp/f160eee8-fa1b-4421-8087-a0df75c5f0a7_leather-berry.jpg	/output/clothing_items/3ff93ded-e194-444c-b32d-f060570eee39_preview.png	2025-10-22 18:40:54.193235	2025-10-22 22:50:14.726019	1
18	f0f6f17c-5e87-47f5-94c4-e994231f526d	belts	wide leather waist belt with square roller buckle	thick vegetable-tanned cowhide with smooth grain; suede underside; edge-painted and topstitched	matching cognac brown leather with antique brass buckle and eyelets	Threaded through the jacket’s external belt loops. 45–50 mm width; single-prong square roller buckle, five punched holes, and a leather keeper. Ends feature a tapered tip; double-needle topstitching in tonal thread. Functions to cinch the jacket at the waist, creating a defined hourglass profile over heavy shearling.	/app/uploads/temp/1304adde-2f23-4c6e-9411-260662c509ff_00104-2618162151 - Copy.png	\N	2025-10-22 21:55:46.302874	2025-10-22 22:50:14.72696	1
168	910a878d-c716-4605-bb43-d60b8bc076bd	bottoms	high-rise wet-look leggings	polyester/elastane interlock knit laminated with a thin polyurethane coating; heavy weight (approx. 300–330 gsm); slick, high-gloss surface with substantial recovery; cotton-blend gusset insert for comfort	jet black, mirror-gloss 'liquid' finish	Second-skin silhouette with ankle-length inseam; 60–70 mm contoured elasticized waistband (concealed under the tank) with soft brushed backing; inseam and outseam constructed with overlock + coverstitch for strength under stretch; single-piece front and back legs with minimal seam interruptions to preserve glossy surface; diamond gusset at crotch to reduce strain; hems secured with narrow twin-needle coverstitch; no pockets or external hardware; the coated surface exhibits characteristic reflective creasing at hip and knee under movement.	/app/uploads/temp/7dc3c673-4815-4c76-9d9c-c62162e33971_shapes.png	/output/clothing_items/910a878d-c716-4605-bb43-d60b8bc076bd_preview_20251023_044208.png	2025-10-23 00:47:06.783907	2025-10-23 04:42:18.098949	1
20	296a0eed-21ff-4493-93a7-83a39bddcb60	outerwear	asymmetric aviator shearling jacket with oversized shawl collar	full-grain sheepskin shearling; exterior nappa-finished leather with matte, lightly patinated surface; interior clipped wool pile; heavy weight with firm structure	rich cognac brown leather shell with natural ivory shearling; antique brass hardware	Hip-length, structured silhouette with dramatic exposed-shearling shawl collar and lapels. Off-center front closure using a heavy-gauge metal zipper (antique brass) that runs right of center; zipper tape tone-on-tone brown. Body built from curved panels with lapped shearling seams and double topstitching for reinforcement. Set-in sleeves with slight elbow shaping; cuffs are turned-back to expose ivory pile. Hem edge bound by exposed shearling. Two slanted hand pockets at waist closed by metal zippers with leather pull tabs. External belt loops integrated at waist to accept a wide belt; back features subtle shaping seams to contour the waist. Interior unlined (natural shearling), with edges skived and butted for minimal bulk. Decorative lapel pins attached: one leaf-motif and one small wing/crest, both antiqued brass, placed asymmetrically on the shearling lapels.	/app/uploads/temp/1304adde-2f23-4c6e-9411-260662c509ff_00104-2618162151 - Copy.png	/output/clothing_items/296a0eed-21ff-4493-93a7-83a39bddcb60_preview.png	2025-10-22 21:55:46.300903	2025-10-22 22:50:14.728937	1
21	c873254a-e63a-40c6-98ae-8a959c46afae	belts	structured leather waist belt with rectangular buckle	smooth vegetable-tanned leather strap with firm interlining; edge-painted and finely topstitched	jet black strap with polished gold-tone hardware	Approximately 35–40 mm width. Rectangular frame buckle with single prong and center bar; matching metal eyelets reinforce multiple adjustment holes. Squared tip. Threaded through the dress’s side belt loops and cinched at center front to secure the wrap and define the waist; stitching runs 2–3 mm from edges for crisp definition.	/app/uploads/temp/73632130-f8de-4a6e-b677-c51dadd8edc6_fur-dress.png	/output/clothing_items/c873254a-e63a-40c6-98ae-8a959c46afae_preview.png	2025-10-22 22:05:30.025074	2025-10-22 22:50:14.729979	1
22	147fd9d3-7ba1-49ca-bd1e-49d147eee920	outerwear	cropped collarless leather jacket with puff shoulders	full-grain lambskin leather, smooth aniline finish with semi-gloss sheen; medium weight with firm hand; fully lined in black acetate satin	deep jet black, glossy finish	Open-front, no visible closure; shrunken length ending just above the natural waist to reveal the corset top beneath. Slightly padded sleeve heads with gathered cap to create pronounced puffed-shoulder silhouette; slim two-piece sleeves styled pushed up, producing stacked creasing along the forearms. Front and back princess seams provide sculpted shaping; side seams slightly curved to contour the ribcage. Edge construction features turned leather facings with narrow 2 mm tonal topstitching; hem clean-finished. Sleeve heads stabilized with fusible interfacing; shoulder pads lightly structured. Lining bagged-out with hand-tacked points at hem and sleeve ends for mobility. No exterior pockets or epaulettes; hardware-free minimalist design that contrasts texturally with the high-shine bustier.	/app/uploads/temp/ac24757c-7ca2-4987-aef2-426c2c6dfafc_2025-09-02-053323_00002_.png	/output/clothing_items/147fd9d3-7ba1-49ca-bd1e-49d147eee920_preview.png	2025-10-22 22:00:06.153499	2025-10-22 22:50:14.730958	1
23	edf9c683-e6e1-4e07-8524-fec63344d8d7	hosiery	fur ankle gaiter cuffs	matching long-pile natural fur formed into tubular rings over elasticized woven tape; soft, lofty hand	cream to ivory, matte pile	paired circular cuffs worn at the lower calf/upper ankle; internal elastic keeps position while allowing stretch over footwear; nap runs horizontally around circumference; edges butted and whip-stitched to conceal join; sit just above boot toplines, creating a pronounced break between the sleek catsuit legs and the leather boots.	/app/uploads/temp/55a6131b-c6af-496a-aa79-269d6d927ad1_cruella-outfit.jpg	/output/clothing_items/edf9c683-e6e1-4e07-8524-fec63344d8d7_preview.png	2025-10-22 22:03:32.918797	2025-10-22 22:50:14.731928	1
25	4d217117-8815-4178-8c77-11e123849e66	tops	button‑front woven shirt	lightweight cotton poplin, possibly with a small elastane content; crisp hand with subtle mercerized sheen	optic white, matte to softly lustrous	Classic narrow point collar with collar stand; center placket with small buttons (only the upper opening visible); worn with the top buttons undone so the V of the placket shows above the jacket zipper; shirt is tucked beneath outer layers and not visible at hem; edges finished with fine topstitching typical of poplin shirting.	/app/uploads/temp/c2a8339a-fd52-4f04-bb4d-c7f3dcd9b322_lucy.png	/output/clothing_items/4d217117-8815-4178-8c77-11e123849e66_preview.png	2025-10-22 18:04:31.014991	2025-10-22 22:50:14.733865	1
26	bae9b094-d873-437a-baf3-f8d4f41f2398	bottoms	skinny jeans	midweight stretch denim (cotton with elastane) in right-hand twill; soft matte finish	solid true black, even dye with no distressing	High-stretch, body-contouring skinny silhouette to the ankle. Clean, unbroken legs with minimal seam bulk; standard five-pocket construction and zip fly presumed though not visible. Overlock-joined outseams with single-needle topstitching; hems appear turned and stitched for a minimal profile.	/app/uploads/temp/0fe0102d-c6c8-49e1-9143-efbeb2219df3_black-shearling.png	/output/clothing_items/bae9b094-d873-437a-baf3-f8d4f41f2398_preview.png	2025-10-22 22:02:50.461997	2025-10-22 22:50:14.734805	1
27	0e3d83c2-fe68-4a20-b3d1-133e2d2349e8	tops	overbust corset bustier with sweetheart neckline	silk-blend duchesse satin shell over a cotton coutil strength layer with spiral and flat steel boning; modesty panel in cotton twill	vivid crimson red with cool undertone and soft satin sheen	Structured, strapless overbust silhouette with contoured bust cups shaped by vertical seaming and internal boning channels; center-front steel busk closure with loop-and-post hardware, likely 26–28 cm; back lacing through nickel grommets with flat laces; waist sharply nipped via reinforced waist tape; hem and neckline bound with self-fabric binding; visible parallel topstitching on boning channels creates a corsetry panel effect. Worn open at the decolletage under a jacket.	/app/uploads/temp/95f20449-faec-415a-a9cb-ba8553920db3_eclectic-4.png	/output/clothing_items/0e3d83c2-fe68-4a20-b3d1-133e2d2349e8_preview.png	2025-10-22 22:05:31.240504	2025-10-22 22:50:14.735714	1
162	f1ea379d-a812-44b2-97e5-fa7d070bce79	overtops	Rinoa blue duster	medium‑weight rib knit, likely cotton/acrylic blend, soft hand with fluid drape	pastel periwinkle blue, matte	Sleeveless longline cardigan‑style vest extending to mid‑calf at back with elongated tails. Vertical rib structure provides stretch and lengthwise texture. Center front has a single self‑fabric tie at the bust, worn loosely knotted to keep the fronts parted. Front and armhole edges finished with narrow self‑rib binding; straight hem with clean overlocked/coverstitched finish. High side slits allow the front panels to swing open, revealing the skirt and shorts underneath.	/app/uploads/temp/daba4300-c3e1-43d3-b75f-da9c92514761_outfit_05.jpg	/output/clothing_items/f1ea379d-a812-44b2-97e5-fa7d070bce79_preview.png	2025-10-23 00:47:06.77621	2025-10-23 00:57:50.962024	1
29	e69a1eff-faf4-48d3-a16a-d453b388c1a6	tops	long-sleeve knit underlayer with extended rib cuffs	heavy 2x2 rib knit, cotton–wool blend with a touch of elastane for stretch, matte	forest green with cool undertone	only the elongated cuffs are visible, extending 4–5 cm past the leather sleeve openings; tubular knit cuff ends with clean bind-off (no thumbhole); functions as an inner sleeve layer that adds color contrast and warmth beneath the jacket and over the black base knit.	/app/uploads/temp/c13b378c-8b5c-4ca1-8a9b-e0d0ae2fd1d9_yt-jacket.jpg	/output/clothing_items/e69a1eff-faf4-48d3-a16a-d453b388c1a6_preview.png	2025-10-22 21:42:00.167884	2025-10-22 22:50:14.737502	1
30	ec39a3dc-50da-4fae-9c42-00d634a6c346	tops	crewneck jersey T-shirt	lightweight cotton jersey with slight elastane content; soft hand, matte surface	solid deep black	classic set-in crewneck construction with narrow rib-knit neckband; no visible graphics; only the neckline edge is visible above the jacket’s shearling collar; worn fully under the outerwear with clean, flat finish at the collar.	/app/uploads/temp/2751f088-8936-401b-aeae-1bbe18114345_2025-08-09-080939_00004_.png	/output/clothing_items/ec39a3dc-50da-4fae-9c42-00d634a6c346_preview.png	2025-10-22 21:56:41.047662	2025-10-22 22:50:14.738428	1
32	49a0d3bd-f534-4c58-b81f-cbfb7d151a17	bottoms	high-waisted pencil skirt in matching leather	genuine smooth-grain leather, medium weight with pliable hand; suede-backed or lightly lined for comfort and seam stability	matching cool slate charcoal grey, matte to low-sheen finish	Streamlined, body-skimming pencil silhouette with clean waistband hidden beneath the jacket. Front appears panelled with vertical seam shaping; single-needle topstitching keeps a minimal, tailored look. No pockets visible. Closure not visible from the front. Hem length not fully shown but cut straight; leather panels are smoothly pressed with no intentional distressing. Designed to coordinate seamlessly with the jacket for a suit-like set.	/app/uploads/temp/32fcf7e4-d6a1-408b-a163-684d37a805b6_2025-08-09-092552_00005_.png	/output/clothing_items/49a0d3bd-f534-4c58-b81f-cbfb7d151a17_preview.png	2025-10-22 21:53:37.738234	2025-10-22 22:50:14.74031	1
33	26025c76-3b99-437e-8b00-c125ddf01646	tops	cropped graphic tank	cotton-spandex jersey, medium weight, soft hand with moderate stretch and recovery; matte surface suitable for screen print	jet black ground with white screen-printed skull motif and 'PUNKS' text	Sleeveless tank with deep scoop neckline and fitted body, cut to a micro-crop length that exposes midriff. Neck and armholes finished with narrow self-fabric binding; hem is raw-cut or very narrow coverstitched to maintain a lightweight edge. Negative-ease fit hugs torso; graphic centered on front. Styled to sit beneath the cropped jacket with the hem visible above the waistband of the pants.	/app/uploads/temp/127eb0b1-8736-4a0c-a6f0-4e1ea2923c38_punk.png	/output/clothing_items/26025c76-3b99-437e-8b00-c125ddf01646_preview.png	2025-10-22 17:35:31.478564	2025-10-22 22:50:14.741218	1
34	b9419ff5-b213-4d8c-8781-816280ae61ea	tops	zip-front leather bustier corset	lambskin leather shell with subtle surface glaze; interior lined in cotton-sateen with a small percentage of elastane for comfort; rigid plastic/steel boning in channelled seams	black with mirror-like wet look	Strapless bustier with sweetheart neckline and molded, likely underwired cups. Center-front exposed metal zipper (nickel teeth, #5 gauge) running from neckline to hem; zipper tape black to match. Vertical paneling with boning channels at CF and princess lines to cinch and lift; narrow edge binding at top edge; hem finished with internal leather-faced facing. Cropped to high waist, leaving a narrow midriff gap between top and trousers. Tonal edge-stitching reinforces cup seams and zipper; interior seam allowances overlocked and taped at stress points for durability. Designed to sit flush against the torso with corsetry-inspired compression.	/app/uploads/temp/ac24757c-7ca2-4987-aef2-426c2c6dfafc_2025-09-02-053323_00002_.png	/output/clothing_items/b9419ff5-b213-4d8c-8781-816280ae61ea_preview.png	2025-10-22 22:00:06.154688	2025-10-22 22:50:14.742165	1
35	ad9f8e85-aa32-4175-96d5-343eb5a784f2	earrings	small hoop earrings	polished gold-plated brass	yellow gold metallic	minimal thin hoops approximately 16–18 mm outside diameter with round cross-section; hinge-and-clicker closure; smooth reflective finish; worn symmetrically at each ear.	/app/uploads/temp/2751f088-8936-401b-aeae-1bbe18114345_2025-08-09-080939_00004_.png	/output/clothing_items/ad9f8e85-aa32-4175-96d5-343eb5a784f2_preview.png	2025-10-22 21:56:41.048279	2025-10-22 22:50:14.743107	1
36	a564d378-83f3-4dfa-9cfe-45f1ba2454ed	footwear	knee-high leather boots	smooth calf leather upper with leather lining and stacked leather/rubber heel; medium stiffness, semi-matte finish	warm cognac brown	tall shaft reaching just below the knee with a straight top edge; streamlined construction with minimal visible seaming; rounded almond toe; snug calf fit; subtle creasing at the ankle from wear; closure not visible (likely medial zip) creating a clean exterior with no straps or buckles; color closely coordinates with the jacket.	/app/uploads/temp/2751f088-8936-401b-aeae-1bbe18114345_2025-08-09-080939_00004_.png	/output/clothing_items/a564d378-83f3-4dfa-9cfe-45f1ba2454ed_preview.png	2025-10-22 21:56:41.049334	2025-10-22 22:50:14.744026	1
37	821b2115-3d1c-45a2-a0a8-38bef50c6c82	outerwear	shearling-collar leather aviator jacket	full-grain cowhide leather with semi-aniline finish; genuine lamb shearling pile at collar and exposed front facing; heavy weight with structured hand and semi-matte luster	cognac brown body with ivory shearling and antique-gold hardware	waist-length bomber silhouette with roomy sleeves and slight drop at the shoulder; center-front metal zipper (large-tooth brass with rectangular pull) closed most of the way up; plush shearling collar turned out and continuing as an inner placket facing visible along the zipper; sleeves finished with clean leather hems (no rib knit visible); edges and major seams double topstitched in tonal brown heavy thread for reinforcement; body appears lightly padded/structured; texture contrast between smooth leather shell and lofty shearling is pronounced.	/app/uploads/temp/2751f088-8936-401b-aeae-1bbe18114345_2025-08-09-080939_00004_.png	/output/clothing_items/821b2115-3d1c-45a2-a0a8-38bef50c6c82_preview.png	2025-10-22 21:56:41.04687	2025-10-22 22:50:14.744979	1
38	75a3ec3a-fa41-4eb6-a765-b60cf16a084d	tops	scoop-neck tank top	cotton–elastane jersey, medium-weight, smooth hand, high stretch with matte finish	solid true black, matte	Close-to-body fit functioning as a base layer under the leather jacket. Front scoop neckline with narrow self-fabric binding; armholes finished with matching binding. Minimalist construction with side seams and likely double-needle coverstitch at hem (hem not visible beneath jacket). Neckline is open enough to be visible between the jacket’s lapels, providing a stark value contrast against the brown leather.	/app/uploads/temp/12ac69cd-4625-43d8-8aaa-d0e83728e218_widow2.png	/output/clothing_items/75a3ec3a-fa41-4eb6-a765-b60cf16a084d_preview.png	2025-10-22 22:12:59.011547	2025-10-22 22:50:14.745909	1
39	872a6d1f-9a5f-45e1-bd2c-4f555825147f	one_piece	sleeveless wrap-front leather mini dress	smooth, semi-matte leather (calf/lamb) with light surface sheen; medium weight with firm hand and structured drape; interior likely faced at edges for stability	ink black, semi-matte	Surplice bodice with left-over-right wrap forming a deep V neckline; worn over a turtleneck. Narrow, clean-finished armholes with edge topstitching. Contoured through the waist with vertical front panel seams/princess lines and single-needle topstitching that emphasize shaping. Straight mini-length skirt with turned-and-topstitched hem. Two slim belt loops at side seams manage a separate waist belt that secures the wrap. No pockets or visible closure hardware on the exterior; edges and seam allowances appear neatly pressed and topstitched for structure.	/app/uploads/temp/73632130-f8de-4a6e-b677-c51dadd8edc6_fur-dress.png	/output/clothing_items/872a6d1f-9a5f-45e1-bd2c-4f555825147f_preview.png	2025-10-22 22:05:30.021609	2025-10-22 22:50:14.746807	1
41	347a8f1e-f2a6-462f-836e-c53d83b91dfc	one_piece	long-sleeve corseted pencil dress with center-front button placket	smooth, semi-aniline lambskin leather, medium weight with firm body and glossy finish; interior bodice and skirt partially lined in lightweight satin twill; neckline and placket areas fused for stability; cups lightly padded and lined	vivid lipstick red with cool undertone and high-gloss sheen	Body-construction integrates a balconette/sweetheart neckline with molded three-piece bust cups and a slight V-notch at the center front. The bodice is corsetry-inspired with multiple vertical panel seams and stitched boning channels (6+ bones) running from underbust through the waist to the hip, creating a cinched, hourglass silhouette. Exaggerated leg-of-mutton sleeves are set with heavily gathered sleeve heads to produce volume at the upper arm; fullness tapers toward the wrist where the leather is gathered into a narrow turned hem without visible hardware. A continuous, narrow center-front placket extends from the neckline through the skirt, closed by a dense run of small, dome metal buttons/snap-studs in gold tone; placket is edge-stitched for reinforcement. The skirt follows a slim pencil line to mid-calf with vertical seams continuing from the bodice for visual elongation. A center-front slit begins below the knee and features controlled ruching along the slit channel to maintain tension and reveal; slit edges are stay-stitched and topstitched. All leather seams are butted and topstitched or lapped with double-needle stitch typical for leatherwork; edges are turned and edge-painted. Hem is clean, turned, and stitched. Overall fit is sculpted and compressive through torso and hips with dramatic sleeve volume, presenting a polished, structured evening silhouette.	/app/uploads/temp/60119aa3-a186-4f8f-9847-99fb687b4bb0_2025-09-17-213712_00001_.png	/output/clothing_items/347a8f1e-f2a6-462f-836e-c53d83b91dfc_preview.png	2025-10-22 22:01:24.248383	2025-10-22 22:50:14.748576	1
42	eed5545f-f079-449d-9db8-beeeb4080100	tops	crewneck t-shirt	midweight cotton jersey, soft hand, matte surface	solid deep black	Classic set-in construction with a 1x1 rib-knit collar band. No visible graphics or embellishment. Regular fit; hem and sleeves obscured by the outerwear. Neckline sits cleanly beneath the jacket’s lapels, providing a uniform black-on-black layer.	/app/uploads/temp/99e6f109-7d74-498d-8c19-8742b6985ecb_oversized-jacket.png	/output/clothing_items/eed5545f-f079-449d-9db8-beeeb4080100_preview.png	2025-10-22 22:06:45.644482	2025-10-22 22:50:14.749543	1
43	55a63256-f634-46aa-a0c2-c5fc941799a1	bottoms	high‑waisted leather pencil skirt	smooth lambskin leather, midweight with moderate stiffness and a polished surface; fully lined in stretch satin (acetate/spandex or similar)	cool black, semi‑gloss finish	Clean faced waist without a visible waistband; fitted through hips with shaping darts; straight, narrow pencil silhouette intended to reach around knee length (exact hem not shown); likely center‑back invisible zipper with a back vent for stride; minimal external topstitching for a sleek appearance; worn under the jacket so the waist seam is mostly concealed by the jacket’s peplum.	/app/uploads/temp/c2a8339a-fd52-4f04-bb4d-c7f3dcd9b322_lucy.png	/output/clothing_items/55a63256-f634-46aa-a0c2-c5fc941799a1_preview.png	2025-10-22 18:04:31.016519	2025-10-22 22:50:14.750527	1
44	5a47de65-0cfb-4591-a0ef-33dad9c5ba0e	outerwear	collarless leather zip jacket	mid-weight full-grain cowhide leather with fine pebble, matte finish, moderately stiff hand that has begun to break in	moss-olive taupe with a cool grey cast, matte	hip-length, clean round neckline without lapels; center-front metal zipper (approx. #5 gauge) on dark tape with an elongated pull; regular fit through body; panelled construction with symmetrical vertical seams and double-needle topstitching (3–4 mm) along body and sleeve seams; set-in long sleeves with plain turned leather hems (no zip gussets); straight bottom hem; hardware in antique nickel tone; worn partially zipped, allowing underlayers to show; no exterior pockets or epaulettes visible; leather shows light creasing consistent with wear.	/app/uploads/temp/c13b378c-8b5c-4ca1-8a9b-e0d0ae2fd1d9_yt-jacket.jpg	/output/clothing_items/5a47de65-0cfb-4591-a0ef-33dad9c5ba0e_preview.png	2025-10-22 21:42:00.166604	2025-10-22 22:50:14.751496	1
46	7a3c12fb-1f96-491b-9ace-3c4e62548693	handwear	minimal band ring	polished sterling silver	cool bright silver	Simple narrow band with rounded comfort-fit interior; mirror polish; worn alone without stacking to maintain a clean, utilitarian accent.	/app/uploads/temp/ac24757c-7ca2-4987-aef2-426c2c6dfafc_2025-09-02-053323_00002_.png	/output/clothing_items/7a3c12fb-1f96-491b-9ace-3c4e62548693_preview.png	2025-10-22 22:00:06.156831	2025-10-22 22:50:14.753342	1
47	e9aec31d-d652-453f-bfc8-28c8fed152f5	outerwear	tailored moto-style leather jacket with notch lapels and two-way zipper	genuine smooth-grain leather, semi-matte/semi-aniline finish, medium weight with soft but structured hand; likely fully lined in lightweight woven satin for ease and stability	cool slate charcoal grey with subtle satin sheen	Close-fitting, waist-shaped silhouette cut to high-hip length. Wide notched biker lapels with clean edge-stitching approximately 2–3 mm from the edge. Center-front two-way metal zipper (gunmetal teeth and sliders) allows opening from hem or neckline; worn partially unzipped to form a deep V. Vertical front princess seams contour the bust and continue to the hem; side panels carry vertical zip hand pockets with exposed gunmetal zippers and narrow leather tape. Set-in, two-piece long sleeves with elbow seam and zippered vents at the cuffs; zippers are short (about 8–10 cm) and finished with narrow leather guards. Single-needle topstitching along seams and edges; hem is clean-finished with turned facings. Minimal shoulder structure (no visible padding). Hardware uniformly gunmetal; overall surface is smooth, pressed, and free of distressing.	/app/uploads/temp/32fcf7e4-d6a1-408b-a163-684d37a805b6_2025-08-09-092552_00005_.png	/output/clothing_items/e9aec31d-d652-453f-bfc8-28c8fed152f5_preview.png	2025-10-22 21:53:37.736779	2025-10-22 22:50:14.754305	1
48	34e5b6b9-6a41-4be5-bc8d-e0e90890cd5d	neckwear	star-pendant leather choker	full-grain calf leather strap with polished stainless-steel hardware	matte jet black strap with bright silver-tone metal	Approx. 12–15 mm wide collar with edge-painted and single-needle topstitched perimeter; center-front five-point star pendant on a small jump ring; rear single-prong buckle closure with punched holes and a leather keeper; clean-finished underside; worn snug at the neck to frame the decolletage.	/app/uploads/temp/95f20449-faec-415a-a9cb-ba8553920db3_eclectic-4.png	/output/clothing_items/34e5b6b9-6a41-4be5-bc8d-e0e90890cd5d_preview.png	2025-10-22 22:05:31.238297	2025-10-22 22:50:14.755247	1
49	1c65a137-f2ef-4cff-bcbc-3c6431ebbb07	bags	leather side holster harness	full-grain leather straps with smooth finish; reinforced by rivets; sturdy, semi-rigid construction	dark chocolate brown leather with antiqued brass buckles, snaps, and D-rings	Attached at the right hip via a drop strap from the jacket belt, securing to a contoured sheath-style pouch. Features an adjustable strap with a small roller buckle, retention tab with snap, and stitched edge finishing. Hardware is antiqued to match the jacket’s metalwork; functional accessory sits slightly behind the side seam without interfering with the jacket’s belted closure.	/app/uploads/temp/1304adde-2f23-4c6e-9411-260662c509ff_00104-2618162151 - Copy.png	/output/clothing_items/1c65a137-f2ef-4cff-bcbc-3c6431ebbb07_preview.png	2025-10-22 21:55:46.303251	2025-10-22 22:50:14.756141	1
51	23844eb6-1df8-4de7-abaf-c6129ee8afaf	wristwear	slim chain bracelet	polished metal, likely 14k gold-plated brass	warm yellow gold	Delicate cable-link chain around the wrist with a small lobster-claw clasp; minimal hardware scale to avoid interference with jacket sleeve; high-polish finish providing subtle specular highlights.	/app/uploads/temp/ac24757c-7ca2-4987-aef2-426c2c6dfafc_2025-09-02-053323_00002_.png	/output/clothing_items/23844eb6-1df8-4de7-abaf-c6129ee8afaf_preview.png	2025-10-22 22:00:06.156199	2025-10-22 22:50:14.757976	1
50	eef5156b-2792-455f-9b07-561c1527d016	eyewear	Regular Black Glasses	polished cellulose acetate frame with embedded metal core; clear CR‑39 or polycarbonate lenses	gloss black frame with clear lenses	Full‑rim rectangular silhouette with subtly upswept outer corners; standard saddle bridge formed in acetate; integrated acetate nose pads; slim tapered temples with exposed silver‑tone three‑barrel hinges; lenses appear uncoated or with a light anti‑reflective finish.	/app/uploads/temp/c2a8339a-fd52-4f04-bb4d-c7f3dcd9b322_lucy.png	/output/clothing_items/eef5156b-2792-455f-9b07-561c1527d016_preview.png	2025-10-22 18:04:31.012095	2025-10-23 04:21:38.041412	1
52	d3d62d1f-da72-4ec1-866e-3c3d519f7e83	tops	button-front satin blouse with exaggerated point collar	silk-blend or polyester satin, medium-weight with soft drape and glossy face; collar fused for crisp structure	high-chroma safety orange, luminous satin finish	Long-sleeve tailored blouse worn under the jacket; extended spear collar points are layered over the leather lapels. Placket is center-front with tone-on-tone buttons; several top buttons are left undone to create a deep V neckline. The shirttail hem peeks slightly below the jacket. Seams likely French or overlocked with clean topstitch-minimal finish to keep a sleek surface.	/app/uploads/temp/f95feaac-6eff-43a1-8956-d08435e4601d_cate.jpg	/output/clothing_items/d3d62d1f-da72-4ec1-866e-3c3d519f7e83_preview.png	2025-10-22 18:02:31.723771	2025-10-22 22:50:14.758896	1
53	4d773077-76c7-4460-9acd-839e7fc44d40	one_piece	bodycon slip dress with scoop neckline	nylon/spandex jacquard jersey with 4-way stretch; medium weight, matte hand; tonal leopard motif knit into ground for subtle relief	black ground with charcoal-on-black tonal leopard pattern, matte finish	Close-fitting, stretchy sheath worn under the jacket; neckline is shallow scoop with clean-turned binding or narrow self-facing. Likely sleeveless with fine straps concealed beneath the jacket lapels. Dress appears to extend past the hip (hem out of frame), maintaining an uninterrupted bodycon column. Seams likely minimal—side seams with coverstitched allowances and a center-back seam optional for shaping. Hem likely twin-needle coverstitched for recovery. The matte, textured jacquard contrasts against the smooth sheen of the leather jacket, providing depth without distracting patterning.	/app/uploads/temp/9460a775-7bbc-4aa0-be25-84f381f04e15_maria-outfit.png	/output/clothing_items/4d773077-76c7-4460-9acd-839e7fc44d40_preview.png	2025-10-22 22:11:40.290392	2025-10-22 22:50:14.759842	1
55	291bd930-d19c-44e8-bb48-92f282e6438c	bottoms	high-rise skinny pants	power-stretch ponte knit or stretch twill, dense and opaque, firm recovery with matte surface	ink black, neutral undertone, matte	Second-skin silhouette from waist through thigh with clean, minimal front—no visible fly, pockets, or belt loops from the observed angle, suggesting a streamlined, possibly pull-on construction. Waist sits at or just below the natural waistline and is covered by the jacket hem and belt. Legs read as full length though hems are out of frame. Seams are kept to side and inseam lines for an uninterrupted appearance, emphasizing mobility and a sleek, tactical aesthetic.	/app/uploads/temp/12ac69cd-4625-43d8-8aaa-d0e83728e218_widow2.png	/output/clothing_items/291bd930-d19c-44e8-bb48-92f282e6438c_preview.png	2025-10-22 22:12:59.012878	2025-10-22 22:50:14.761727	1
56	f14fdfb2-543d-4992-9181-c474c66910c5	neckwear	strap choker	smooth leather band with soft backing	matte black	Approximately 1.5–2 cm wide; snug fit at the neck. Clean-edged strap with subtle edge paint; rear closure likely a small buckle or snap (not visible). Sits flush above the blouse collar line, adding graphic contrast.	/app/uploads/temp/f95feaac-6eff-43a1-8956-d08435e4601d_cate.jpg	/output/clothing_items/f14fdfb2-543d-4992-9181-c474c66910c5_preview.png	2025-10-22 18:02:31.724603	2025-10-22 22:50:14.762671	1
57	05b36678-b6ae-4628-89a0-f3607525c3c9	footwear	mid-calf lace-up combat boots with lug soles	full-grain leather upper with matte finish; heavy rubber lug outsole; metal eyelets and hardware	deep jet black	Round toe, mid-calf shaft height. Front lace-up closure with multiple metal eyelets; laces are tonal black. Thick, high-traction lug outsole with defined heel block and stitched welt appearance. Minimal surface embellishment; tonal stitching reinforces quarters and vamp. Back pull tabs likely present (not fully visible). Finish is clean and slightly polished, contrasting the grey leather set.	/app/uploads/temp/32fcf7e4-d6a1-408b-a163-684d37a805b6_2025-08-09-092552_00005_.png	/output/clothing_items/05b36678-b6ae-4628-89a0-f3607525c3c9_preview.png	2025-10-22 21:53:37.739488	2025-10-22 22:50:14.763578	1
58	033b39d1-4475-422f-bd20-5b2bd7898391	footwear	pointed-toe stiletto pumps	genuine suede leather upper with smooth leather outsole and leather-lined insole; velvety nap, matte	matte jet black	Classic closed-toe court shoe with low-cut vamp exposing the top of the foot. Slim stiletto heel approximately 8–9 cm; rigid heel counter and clean edge binding. No platform or embellishment; sharp toe box elongates the line. Suede nap appears uniformly brushed and well maintained.	/app/uploads/temp/73632130-f8de-4a6e-b677-c51dadd8edc6_fur-dress.png	/output/clothing_items/033b39d1-4475-422f-bd20-5b2bd7898391_preview.png	2025-10-22 22:05:30.026276	2025-10-22 22:50:14.764458	1
59	5fab07f7-af24-435e-8883-91e66de0a406	footwear	platform buckle combat boots	smooth calf leather upper with leather lining; lugged rubber outsole; metal buckles and zipper	matte black upper with black sole and bright silver buckles	Mid-calf height with round toe; thick platform and chunky lugged sole with stitched welt; internal medial-side metal zipper for entry; three wide strap bands around the shaft with rectangular roller buckles and keepers; backstay and vamp reinforced with double-row stitching; topline lightly padded and edge-turned; polished hardware coordinates with jacket zips. The boots visually anchor the mini skirt and add utilitarian weight to the look.	/app/uploads/temp/95f20449-faec-415a-a9cb-ba8553920db3_eclectic-4.png	/output/clothing_items/5fab07f7-af24-435e-8883-91e66de0a406_preview.png	2025-10-22 22:05:31.24594	2025-10-22 22:50:14.765336	1
60	8809f779-9f56-42c9-b9bd-e7eb4e39ef1a	bottoms	high-rise skinny leather pants with five-pocket jean styling	stretch lambskin bonded to cotton-elastane backing; smooth, semi-lustrous face with supple recovery; medium weight	inky black, semi-gloss	Classic jean-derived construction: contoured waistband with 7 belt loops, metal shank button at center front (gunmetal), and concealed zip fly (nickel teeth). Front scoop pockets kept minimal with thin leather facings; coin pocket likely internalized to reduce bulk; back pockets low-profile with clean top edges (no flaps). Tonal black topstitching throughout with double-needle seams at side and inseam; crotch seam bar-tacked for reinforcement. Close-to-body, ankle-length skinny silhouette; pressed without visible creases at thigh; waistband sits at or slightly above natural waist, aligning neatly under the cropped jacket hem.	/app/uploads/temp/ac24757c-7ca2-4987-aef2-426c2c6dfafc_2025-09-02-053323_00002_.png	/output/clothing_items/8809f779-9f56-42c9-b9bd-e7eb4e39ef1a_preview.png	2025-10-22 22:00:06.155508	2025-10-22 22:50:14.766281	1
61	3264827b-cb5c-4162-8321-86a88798dae3	outerwear	single-breasted tailored leather blazer	supple lambskin nappa leather, semi-aniline finish with a smooth grain; medium weight with soft hand and controlled drape; fully lined in black acetate satin; fusible canvas/interfacing at fronts, lapels, and hems for structure	deep jet black with cool undertone and subtle satin sheen	Structured, waist-shaped silhouette with lightly padded, set-in shoulders. Notch lapels of medium width with clean edge pick-stitch kept minimal. Single-breasted front with one-button stance at the natural waist; closure not engaged, presenting a deep V opening. Two hip-level flapped welt pockets aligned horizontally; no visible chest pocket. Princess-style front shaping seams concealed within the leather panels; front darts run from hem into bust area for contouring. Sleeves are full-length, slim, and ventless with clean-turned hems. Hem hits just below high hip, overlapping the skirt waistband line. All edges are turned and edge-stitched approximately 3 mm from fold for stability; interior seams taped and lining bagged with jump pleats at hem for mobility.	/app/uploads/temp/42114067-c64a-4716-a383-f7334b02cf64_business-suit_punk_kat_v2.png	/output/clothing_items/3264827b-cb5c-4162-8321-86a88798dae3_preview.png	2025-10-22 22:16:41.938456	2025-10-22 22:50:14.767231	1
62	43210c6c-1f7f-4934-9864-1eb18d04f238	bottoms	tailored straight-leg trousers	worsted wool twill with a fine diagonal rib; medium weight, crisp hand, pressed	dark navy with cool undertone, matte	Mid-rise waistband likely with belt loops (partially obscured by jacket). Flat front with sharp front creases; slant side pockets indicated at hips; back pockets not visible. Straight leg falls cleanly; hem out of frame. Trousers sit under the jacket hem, providing a structured contrast to the voluminous shearling.	/app/uploads/temp/1304adde-2f23-4c6e-9411-260662c509ff_00104-2618162151 - Copy.png	\N	2025-10-22 21:55:46.302493	2025-10-22 22:50:14.768199	1
63	37376169-8f5a-495b-abcb-f6ef6de5b46f	outerwear	oversized longhair fur cape-stole	Tibetan lamb (longhair) fur panels pieced together; full lining in heavy silk satin	mixed panels of cool silver-grey and warm tawny cognac with natural tonal variation; low-luster pile	Cape-like wrap with exaggerated shawl volume enveloping the shoulders and upper body; constructed from alternating color panels laid with the nap following the drape to maximize loft; hair length approx. 10–12 cm for a shaggy, cloud-like texture; no visible closures—intended to drape open; edges turned and blind-stitched to lining; interior has hand-felled seam allowances for comfort. Worn over the leather moto, creating a dramatic contrast of plush fur against smooth leather.	/app/uploads/temp/95f20449-faec-415a-a9cb-ba8553920db3_eclectic-4.png	/output/clothing_items/37376169-8f5a-495b-abcb-f6ef6de5b46f_preview.png	2025-10-22 22:05:31.244831	2025-10-22 22:50:14.769138	1
64	e1896c74-3843-42c4-a5f8-5dfa1a8d5b15	headwear	wide headband	satin-covered rigid band	bright orange with subtle sheen	Classic padded headband profile sitting crown-top; satin cover is smoothly stretched with clean turned-under edges at the ends. Serves as a chromatic match to the blouse and jacket lining.	/app/uploads/temp/f95feaac-6eff-43a1-8956-d08435e4601d_cate.jpg	/output/clothing_items/e1896c74-3843-42c4-a5f8-5dfa1a8d5b15_preview.png	2025-10-22 18:02:31.725945	2025-10-22 22:50:14.77006	1
66	7fa441c8-074a-409e-9458-68d4c39d6b8e	belts	wide waist belt	thick vegetable-tanned leather strap with smooth, slightly glossy coated surface	ebony black strap with matte gunmetal hardware	Approximately 60–70 mm width, positioned high at the waist/underbust to cinch the dress. Center-front rectangular frame buckle with single prong in gunmetal finish; belt tip is tapered and passes through the buckle with a low-profile keeper (not fully visible). Clean painted edges and single-row edge stitching in black. The belt compresses the dress fabric, creating a defined waist break beneath the open jacket.	/app/uploads/temp/f160eee8-fa1b-4421-8087-a0df75c5f0a7_leather-berry.jpg	/output/clothing_items/7fa441c8-074a-409e-9458-68d4c39d6b8e_preview.png	2025-10-22 18:40:54.195303	2025-10-22 22:50:14.771902	1
67	6adc7854-1e61-4edf-9ee6-887a2892b3c3	tops	fine-gauge turtleneck sweater	elastic jersey knit in a merino wool–nylon–elastane blend; soft hand, close recovery, matte surface; lightweight to medium	deep neutral black, matte	Double-layer folded turtleneck collar sitting close to the neck; slim, body-skimming fit. Long set-in sleeves largely covered by outer layers. Clean coverstitched hems and minimal bulk seams. Worn fully tucked beneath the leather wrap dress so only the collar and upper chest are visible, providing a sleek base layer and thermal contrast under the leather and fur.	/app/uploads/temp/73632130-f8de-4a6e-b677-c51dadd8edc6_fur-dress.png	/output/clothing_items/6adc7854-1e61-4edf-9ee6-887a2892b3c3_preview.png	2025-10-22 22:05:30.023274	2025-10-22 22:50:14.772806	1
69	179ecf8d-aa82-4598-aa91-c3a1649136e9	bottoms	high-waisted skinny pants	cotton-elastane stretch twill (denim-like), medium weight with smooth hand and firm recovery	deep oxblood burgundy, matte	Contoured high-rise waist with a close, second-skin fit through hip, thigh, and calf, ending at the ankle. Front fly indicated by a single waistband button and a concealed zipper; minimal topstitching in self color. Clean front without visible pocket bags; belt loops are minimal or omitted. Side seams and inseams likely overlocked with pressed-open finish; narrow turned hems at ankles. Worn without a belt, creating a sleek line under the cropped jacket.	/app/uploads/temp/127eb0b1-8736-4a0c-a6f0-4e1ea2923c38_punk.png	/output/clothing_items/179ecf8d-aa82-4598-aa91-c3a1649136e9_preview.png	2025-10-22 17:35:31.479292	2025-10-22 22:50:14.77467	1
70	b911ab4b-2d12-4924-8dc7-e646f839c3ca	outerwear	cropped moto jacket with quilted shoulders	lambskin leather, smooth semi-matte finish, medium weight with supple hand; lightly structured with fused interfacing in collar/lapels; body lined in lightweight polyester satin	true black, matte	Short biker silhouette ending at high waist. Asymmetric front closure with off-center metal zipper (gunmetal tone) left-to-right; wide notched lapels with snap-down points. Shoulder yokes feature parallel channel quilting for reinforcement; subtle padded layer beneath quilting. Set-in two-piece sleeves with elbow shaping; clean, plain cuffs. Hem finished with narrow turned edge and internal facing. Seams feature double topstitching typical of moto construction. Worn open to reveal cropped top beneath; no pocket openings visible on the front in this view.	/app/uploads/temp/127eb0b1-8736-4a0c-a6f0-4e1ea2923c38_punk.png	/output/clothing_items/b911ab4b-2d12-4924-8dc7-e646f839c3ca_preview.png	2025-10-22 17:35:31.477402	2025-10-22 22:50:14.775607	1
71	f8b34da8-a701-4f6a-ad88-4a43ac46e698	tops	ribbed crewneck sweater	medium-gauge wool-blend 1x1 rib knit, soft hand, good recovery, matte	deep black, neutral undertone	classic crew neckline with self rib band visible at the throat; slim insulating layer under the leather jacket; cuffs and hem concealed by outerwear; likely overlocked interior seams with rib band topstitched down; provides a dark base contrast to the jacket.	/app/uploads/temp/c13b378c-8b5c-4ca1-8a9b-e0d0ae2fd1d9_yt-jacket.jpg	/output/clothing_items/f8b34da8-a701-4f6a-ad88-4a43ac46e698_preview.png	2025-10-22 21:42:00.167389	2025-10-22 22:50:14.776495	1
72	6969eac5-8c63-4964-a984-176c02ad1b42	earrings	small round stud earrings	polished metal	warm yellow-gold tone	Minimalist circular studs with smooth dome face; standard post and butterfly clutch backs. Worn as a subtle accent with no pendant movement.	/app/uploads/temp/0fe0102d-c6c8-49e1-9143-efbeb2219df3_black-shearling.png	/output/clothing_items/6969eac5-8c63-4964-a984-176c02ad1b42_preview.png	2025-10-22 22:02:50.463681	2025-10-22 22:50:14.777406	1
73	e6ab7e74-c321-468d-b2de-320ba065ab66	tops	fitted rib-knit turtleneck sweater	extra-fine merino wool 1x1 rib knit; soft hand, medium weight, high elasticity, matte finish	deep midnight navy, nearly black	High roll turtleneck folded once, sitting snugly under the shearling collar. Fully-fashioned construction with fashioning marks at armholes; set-in sleeves; clean self-finished cuffs and hem with tubular bind-off. Close-to-body fit provides a smooth, insulating base layer beneath the jacket without visible bulk.	/app/uploads/temp/1304adde-2f23-4c6e-9411-260662c509ff_00104-2618162151 - Copy.png	/output/clothing_items/e6ab7e74-c321-468d-b2de-320ba065ab66_preview.png	2025-10-22 21:55:46.301775	2025-10-22 22:50:14.778344	1
28	6130e053-6e04-4748-b998-5fedb37e85f8	outerwear	double-breasted belted leather jacket	full-grain leather, smooth with fine natural grain; medium-weight with semi-structured hand and slight oil-waxed matte finish	deep chocolate brown with warm russet undertone, matte	Cropped, high-hip length silhouette tailored close to the body with pronounced waist suppression. Wide notched lapels with softly rolled break line; undercollar appears two-piece. Double-breasted crossover with two visible rows of dark gunmetal shank buttons; left-over-right overlap. Integrated leather belt at natural waist threaded through five narrow belt loops; single-prong rectangular buckle in antiqued brass, belt edge painted and edge-stitched. Front overlap lies flat, revealing the inner top at neckline. Two-piece set-in sleeves with elbow shaping; sleeve hems finished with clean turned edges and single-needle topstitching, no cuff zips visible. Body paneling includes front princess seams from armhole to hem and side seams, all edges topstitched 2–3 mm for reinforcement. Hem is straight with edge painting and tight topstitch. No exterior pocket openings visible from this angle. Leather shows subtle burnishing at stress points for a lightly worn patina.	/app/uploads/temp/12ac69cd-4625-43d8-8aaa-d0e83728e218_widow2.png	/output/clothing_items/6130e053-6e04-4748-b998-5fedb37e85f8_preview.png	2025-10-22 22:12:59.009767	2025-10-23 00:31:02.887895	1
8	4f5d7f3a-83b9-4bd6-9fa6-d5d808f19b6c	outerwear	classic asymmetrical moto jacket	semi-aniline lambskin leather, medium weight with subtle sheen; full lining in viscose twill	ink black with bright silver hardware	Cropped, fitted biker jacket with wide notched lapels secured by snap studs; off-center #8 metal zipper front left open; epaulet-free shoulder line for a cleaner look; two slanted waist pockets with metal zippers and leather welts; small ticket pocket with flap and snap on the right front; long set-in sleeves with zippered gusset cuffs; hem finished with internal facing and bar-tack reinforcements at stress points; all hardware polished nickel; double-needle topstitching along seams. Styled unzipped to reveal the red corset beneath and layered under a voluminous fur cape.	/app/uploads/temp/95f20449-faec-415a-a9cb-ba8553920db3_eclectic-4.png	/output/clothing_items/4f5d7f3a-83b9-4bd6-9fa6-d5d808f19b6c_preview.png	2025-10-22 22:05:31.242911	2025-10-23 00:32:38.653421	1
121	d5f6bd55-d1f8-420f-8d41-b97d5c57d7a8	outerwear	cropped leather moto jacket with long-hair fur collar	full-grain cowhide leather with semi-matte aniline finish; collar/shoulder trim in long-hair lamb fur; medium-weight, structured hand with slight sheen	deep jet black body with stark winter white fur trim	Waist-length moto cut worn open; set-in sleeves with smooth sleeve heads; clean edge-finished lapel area partially obscured by long-hair white fur panels that extend from neckline over the front shoulders; minimal visible hardware—black topstitching along seams and hem; interior likely unlined at collar where fur is attached with a tape-bound seam; jacket sits over a white tee allowing the hem of the tee to show; tailored close to the torso without bulk.	/app/uploads/temp/c9bb75ce-1437-4d49-b3c1-57c90d18e99a_squall.jpg	/output/clothing_items/d5f6bd55-d1f8-420f-8d41-b97d5c57d7a8_preview_20251023_012636.png	2025-10-23 00:47:06.725018	2025-10-23 01:26:44.660941	1
125	54d1c58d-774d-44f2-a979-f327430c003b	outerwear	Full-Length Mink Fur Coat	natural mink fur in let-out pelt construction; dense underfur with glossy guard hairs, heavy weight; body and sleeves fully lined in silk satin with light canvas interlining at fronts	variegated warm chestnut-to-tawny brown with dark espresso striations; high natural luster	ankle-grazing sweep and relaxed, oversized silhouette; rounded, slightly dropped shoulders with subtle padding; wide shawl collar rolling softly to the chest; long voluminous sleeves with optional turn-back fur cuffs; center-front concealed furrier hooks and thread eyes spaced about every 10–12 cm from neckline to hip; vertical handwarmer pockets at side seams with satin pocket bags; pelts oriented vertically to elongate the body, creating a gentle chevron at the chest where the collar joins; interior features bound armholes, a center-back ease pleat, and a petersham hanging loop; hem finished with blind catch-stitch and a weight chain for a straight, stable drop; seams neatly fell-stitched by furrier methods; surface shows water-beading that accentuates sheen.	/app/uploads/temp/e3d895c1-af91-4e9a-a449-3dccebb57093_fur-fox_cyberpunk_jenny_20250928135503.png	/output/clothing_items/54d1c58d-774d-44f2-a979-f327430c003b_preview_20251023_012630.png	2025-10-23 00:47:06.729737	2025-10-23 03:34:00.375154	1
156	df828cb5-baa6-4b8c-ba7f-9ff5b47517c5	outerwear	Xena Leather Military Outfit	supple calf/lamb leather, smooth-grain, semi-aniline coated; medium-heavy weight with firm, molded hand and low stretch; matte-satin luster; interior not visible	near-black espresso brown, cool cast, with high-contrast polished brass hardware and red shoulder tabs	Tailored, body-contouring silhouette with light-structured shoulders and set-in sleeves. High stand collar with a narrow throat tab secured by a single brass shank button. Front constructed as a left-wrapping panel crossing diagonally from right shoulder to left waist; outer placket displays a vertical column of domed brass shank buttons bearing star insignia, with a staggered parallel row continuing below—decorative while a concealed underlap secures the actual closure. Distinctive sculptural seam sweeps from right chest to left side seam, emphasized by neat, narrow topstitching; additional panel seams contour the torso. No exterior pockets or vents visible. Hem sits at high-hip length with clean, turned edges. Epaulettes feature leather shoulder straps over red cloth tabs, each fastened with brass star buttons; shoulder heads are crisp without gathered ease. Sleeves are plain-ended without cuff vents or ornament. Hardware is polished yellow-brass, uniformly scaled; all edges are precisely topstitched, giving a militaristic, disciplined finish.	/app/uploads/temp/3670b846-ee55-4e14-b283-d3c74ff03eda_outfit_03.jpg	/output/clothing_items/df828cb5-baa6-4b8c-ba7f-9ff5b47517c5_preview.png	2025-10-23 00:47:06.769122	2025-10-23 03:41:27.938839	1
196	50d702d3-142e-4d75-aa00-a77cf78825b6	outerwear	double-breasted maxi coat-dress with exaggerated square shoulders	smooth nappa leather, semi-aniline finish, medium-to-heavy weight with firm, slightly pliable hand and subtle satin sheen	jet black with semi-gloss luster	Floor-length column silhouette with minimal waist shaping and a straight, clean hem. Notched collar with medium-width lapels; edges neatly edge-stitched (~3 mm). Double-breasted front with a 2x3 button configuration using tonal matte black buttons; corresponding machine keyhole buttonholes on the opposite placket; inner placket visually clean with no exposed hardware. Signature sculptural shoulder architecture: oversized rectangular shoulder extensions integrated into a broad yoke, creating planar wings that extend laterally well beyond the natural shoulder line; visibly padded/structured to hold shape. Set-in, fitted sleeves cut to three-quarter/bracelet length without vents or cuffs; sleeve cap smoothly eased with no puckering. Body constructed from large leather panels with visible horizontal seam joins at upper torso and lower skirt; single-needle topstitching along panel joins for reinforcement and visual definition. No external pockets, belt, or belt loops visible. Surfaces appear crisply pressed and unwrinkled, emphasizing the rigid, architectural profile.	/app/uploads/temp/0326259f-604f-4f22-a4d7-14287d4caf84_trenchcoat-extreme_out2_jenny_20251007_210233.png	\N	2025-10-23 04:46:33.986833	2025-10-23 04:46:33.986835	\N
96	187cc0f3-7b09-4445-961b-f9f4d826e490	outerwear	extreme-oversized leather down puffer jacket with high funnel collar	supple nappa leather shell with glossy, coated finish; heavy loft down/feather insulation in oversized baffles; smooth woven nylon taffeta lining	jet black with a wet-look sheen	Sculptural, ballooned silhouette with very large pillow baffles across body and sleeves; exaggerated padded funnel collar stands high around the neck; center-front black molded plastic zipper on wide tape, stitched close to the teeth with single-needle topstitching; no external storm flap; sleeves appear dropped and integrated into the body volume to emphasize roundness; cuff openings are tucked inside the last baffle suggesting hidden elastic or internal knit cuffs; side seams are clean with no visible pocket welts, implying concealed side-entry pockets set into baffle seams; hem sits at mid-hip with evenly distributed loft, no visible drawcord toggles; all quilting seams slightly rounded from fill pressure, edges clean with no piping; overall fit is ultra-oversized, enveloping and highly padded, creating a near-spherical profile.	/app/uploads/temp/8a2e0569-f3d3-4f10-8736-c42b0ad320f6_ChatGPT Image Mar 28, 2025, 09_09_19 PM.png	/output/clothing_items/187cc0f3-7b09-4445-961b-f9f4d826e490_preview_20251023_012732.png	2025-10-23 00:47:06.693845	2025-10-23 01:27:40.836894	1
115	8a4cfa6b-7bf3-40ab-9157-ddd7f74c0eb4	outerwear	oversized zip-front leather jacket	smooth cowhide leather, semi-aniline finish with subtle sheen; medium-weight with firm hand and structured drape	deep jet black, satin-matte luster	Relaxed, drop-shoulder silhouette with extended sleeve length; exposed center-front metal zipper in silver tone; minimal collar treatment (collarless or low band—neckline largely obscured); set-in sleeves with visible panel seams and double-needle topstitching throughout; plain turned-and-stitched cuffs and hem; no visible external branding; worn fully zipped creating a sleek front; leather paneling adds rigidity while allowing slight break at elbows; jacket overlays all other layers and backpack straps sit over the shoulders.	/app/uploads/temp/a33110d7-8b9e-4873-94db-94d679671a32_outfit_32.jpg	/output/clothing_items/8a4cfa6b-7bf3-40ab-9157-ddd7f74c0eb4_preview_20251023_012741.png	2025-10-23 00:47:06.717827	2025-10-23 01:27:48.331525	1
91	296a161b-f9a4-4e64-80ea-1ce6ed4dab82	earrings	small hoop earrings	solid 14k yellow gold, polished surface	warm yellow gold, high polish	Minimalist sleeper-style hoops worn at the lobes; approx. 12–14 mm outer diameter with 1.5–2 mm wire gauge; continuous hinged closure with invisible joint; no texture, stones, or pendants; mirror-finish polish.	/app/uploads/temp/7dc3c673-4815-4c76-9d9c-c62162e33971_shapes.png	/output/clothing_items/296a161b-f9a4-4e64-80ea-1ce6ed4dab82_preview_20251023_013050.png	2025-10-23 00:47:06.688654	2025-10-23 01:30:57.296287	1
45	efa6cd09-edf4-4872-bd44-1fadadb76a4c	outerwear	Cate Archer Orange-Lined Leather Trenchcoat	smooth full-grain leather, semi-aniline finish, medium-weight with structured hand; fully lined in satin/acetate	jet black exterior with vivid tangerine orange lining	Tailored, body-contouring silhouette built from multi-panel construction with front and back princess seams and a shaped center-back seam. Broad notch lapels with edge pick-stitch effect and firm fusible interfacing for roll. Two-piece set-in sleeves; sleeve hems are turned back to intentionally reveal the orange satin lining as a contrast cuff. No exterior pockets visible. Front presents a clean single-breasted wrap with no visible buttons; closure emphasis is the waist belt. All major seams topstitched in matching black thread. Hem appears hip-to-thigh length. Lining in bright orange satin extends into the facing and sleeve hems, creating high-contrast pops at collar and cuffs. Pressed and sharply finished edges for a polished look.	/app/uploads/temp/f95feaac-6eff-43a1-8956-d08435e4601d_cate.jpg	/output/clothing_items/efa6cd09-edf4-4872-bd44-1fadadb76a4c_preview.png	2025-10-22 18:02:31.721484	2025-10-23 03:34:46.076154	1
151	e0db974f-5c30-4930-86af-80df5e6618f2	outerwear	Brown Shearling Aviator Jacket, Oversized	double-face sheepskin with sueded exterior and dense curly shearling pile interior; heavy weight with stiff, insulated hand; matte finish	charcoal espresso brown shell with natural ivory shearling	Boxy hip-length silhouette with dropped shoulders and thick padded look. Tall shearling stand collar; collar, front placket, hem, and cuff edges finished with turned-out shearling. Off-center heavy-gauge nickel zipper closure running from hem to neck; zipper tape tone-on-tone dark brown. Additional vertical seam with exposed metal zipper on right front used as a design line/vent. Two vertical side-entry welt pockets integrated into front panels. Panel seams are bound with leather tape and twin-needle topstitched for reinforcement. Hem and cuffs feature broad shearling facings that roll outward 3–4 cm. Worn partially unzipped to reveal inner layer; overall condition crisp, minimally worn.	/app/uploads/temp/f80333a9-8e62-44f2-82f8-e592fbdb4e51_outfit_16.jpg	/output/clothing_items/e0db974f-5c30-4930-86af-80df5e6618f2_preview.png	2025-10-23 00:47:06.762747	2025-10-23 04:17:41.090927	1
197	30351a05-0084-491f-85ed-62e486a97fea	headwear	narrow-brim cloche hat with ribbon band and floral pin	blocked wool-felt body with matte surface; grosgrain ribbon band; felt flower applique	maize yellow crown with camel-tan brim; brick-red band; white flower with scarlet center	Rounded, low-dome crown blocked in one piece; short downturned brim approximately 4–5 cm with clean cut edge; 20 mm grosgrain band encircling crown, seam positioned at back; left-side floral accent formed from layered white felt petals and a red circular center resembling a button; proportionally shallow crown height for a close fit; no visible ventilation eyelets or stitching; interior sweatband not visible; overall crisp, pressed finish.	/app/uploads/temp/69bcd139-ffaa-4bcd-ba87-c5acba6f2569_2025-10-22_23-05-15.png	\N	2025-10-23 05:06:18.394419	2025-10-23 05:06:18.394421	\N
146	70958bcd-9d9b-4e0b-95a4-68701bcdccbb	outerwear	waist-length moto jacket with band collar	genuine leather with smooth semi-aniline finish; medium weight; firm structure with slight suppleness; low-sheen surface; fully lined woven lining	cool ink black, semi-matte	Contoured, body-sculpting silhouette built from multiple curved panels and princess seams; short stand/band collar that zips up to the throat; center-front metal zipper with narrow leather facing and 3–4 mm edge topstitching; set-in sleeves with articulated elbow shaping and narrow zipped cuffs with micro-gussets; hem sits at the high hip and is clean-finished; no exterior pocketing visible; hardware in dark gunmetal; edges neatly topstitched for durability; overlaps a structured corset beneath, allowing the jacket to remain partially open at the neckline while maintaining a sleek, armored appearance.	/app/uploads/temp/c55d3721-1ce1-456f-aba4-e9146d269e72_selene__underworld___6_by_stormborncat_det4s36-pre.jpg	/output/clothing_items/70958bcd-9d9b-4e0b-95a4-68701bcdccbb_preview.png	2025-10-23 00:47:06.757148	2025-10-23 01:12:46.90276	1
105	f9e5a429-f720-498c-8b06-ee655e448575	outerwear	cropped asymmetric moto jacket	supple lambskin leather with natural grain, medium weight, matte finish, lightly broken-in hand; likely full woven lining for stability	deep espresso brown, low-sheen	Waist-length moto cut with slightly cropped proportion; asymmetric metal zipper closure running left-to-right across the chest, medium-gauge nickel teeth with matching puller; soft notched lapels collapsed toward the chest, lapel and front edges cleanly edge-stitched; set-in long sleeves with moderate ease at the sleeve cap; hem finished with an integrated self-leather belt threaded through leather belt loops, featuring multiple evenly spaced gunmetal eyelets and a rectangular single-prong buckle; one small utility pouch mounted at the right front of the hem belt, flap secured by snap or concealed stud (pouch stitched to belt carrier); panels shaped with princess-style seams from shoulder toward hem for a close but non-restrictive fit; interior likely bagged-out lining in black acetate or similar with light shoulder reinforcement; overall silhouette fitted through the torso, relaxed at sleeves to accommodate layering over a slick bodysuit.	/app/uploads/temp/1d88a234-4f7c-4588-b444-0c3bcd1e08b8_outfit_06.jpg	/output/clothing_items/f9e5a429-f720-498c-8b06-ee655e448575_preview_20251023_012736.png	2025-10-23 00:47:06.706266	2025-10-23 01:27:45.310117	1
166	37091233-b4c7-449b-9c26-46c22fb24d3d	outerwear	Red Leather Coatdress	genuine smooth nappa leather, medium-heavy weight with semi-aniline finish; supple hand, subtle satin sheen; fully lined in smooth rayon/bemberg twill with fused interfacing in collar and front facings	deep oxblood/burgundy with cool maroon undertone, semi-gloss finish	Tailored, body-contouring silhouette achieved via front and back princess seams and multi-panel construction; full-length two-way separating metal zipper at center front in silver-toned nickel with matched tape, top stop at mid-chest creating a deep V; oversized winged/convertible collar that folds back into broad lapels; dramatic gigot sleeves with substantial cap ease and upper-arm fullness, tapering to the wrist; sleeve openings finished with integrated black rib-knit storm cuffs set inside the leather shell; horizontal panel joins around lower skirt for length extension; front zipper terminates above hem leaving a short walking opening; rear hem features an inset inverted box pleat/godet for stride and subtle flare; clean turned edges with fine single-needle topstitching (~3–4 mm) along center front, collar, and seamlines; no external pockets; seams appear taped and neatly pressed for a sculpted, streamlined appearance.	/app/uploads/temp/305a4194-f611-47a3-a609-3720c8456263_red-baggy_mirror-ots_jenny_20250928140341.png	/output/clothing_items/37091233-b4c7-449b-9c26-46c22fb24d3d_preview.png	2025-10-23 00:47:06.781633	2025-10-23 03:35:31.474686	1
54	c9fda71b-cc41-4038-aae6-f3485002a4e4	outerwear	Maria Red Leather Suit	supple lambskin leather, semi-aniline finish with subtle sheen; medium weight with light interlining for structure; fully lined in smooth woven acetate or Bemberg for glide	deep raspberry-magenta with cool berry undertone, semi-matte luster; tonal shading along seams from pressing	Slim, cropped silhouette ending at high hip. Wide, classic notched lapels with fused canvas interfacing for crisp roll; lapel edge and front edges finished with 2–3 mm edge-stitch plus 6 mm decorative topstitching along all major seams. Single-breasted front worn open; closure is primarily a self-fabric waist belt anchored at side seams and threaded through stitched-on belt carriers positioned above hip level. Belt features a centered leather tab with a single collar-stud and two antique-brass D-rings for cinching; belt width approx. 35–40 mm. Front body shaped with princess seams from shoulder through hem and vertical bust darts to contour. Two hip pockets with narrow rectangular flaps (likely jetted entry concealed under flaps) set symmetrically. Set-in two-piece sleeves cut to three-quarter length; sleeve hem is clean-faced and lightly turned, giving a subtle cuff effect, with vertical elbow seam for articulation. Back paneling likely mirrors front princess seams; no visible back vent due to cropped length. Inside: fully bagged lining with hand-tacked shoulder points, bound armhole seam allowances visible from lining side; light shoulder padding to maintain line. Hardware in warm antique brass; all edges inked and burnished. The jacket overlaps a dark underlayer, allowing belt and lapel shape to be clearly defined.	/app/uploads/temp/9460a775-7bbc-4aa0-be25-84f381f04e15_maria-outfit.png	/output/clothing_items/c9fda71b-cc41-4038-aae6-f3485002a4e4_preview.png	2025-10-22 22:11:40.289097	2025-10-23 03:37:02.981789	1
198	0cbfe36f-c8f3-4285-a733-6d78cf3f010e	one_piece	ankle-length polka-dot housedress with oversized Peter Pan collar	light- to mid-weight cotton poplin, plain-weave, matte handle with soft drape; collar in crisp cotton broadcloth	powder blue ground with evenly spaced ivory polka dots; collar bright optic white	Pullover construction with round neckline finished by a two-piece, overscaled Peter Pan collar in white, collar edges clean-turned and topstitched; long set-in sleeves without cuffs, finished with narrow turned-under hems; body cut in a relaxed T-shape with straight side seams and minimal shaping, no waist seam or darts; hem falls to ankle with small side seam vents for stride; straight bottom hem with double-needle topstitching; polka-dot print repeat regular on a grid (~20–30 mm dots) across body and sleeves; no visible pockets, plackets, or closures; seams appear plain-joined with overlock or clean-finish inside (not visible), exterior presents a smooth, unstructured silhouette characteristic of a nightgown/caftan; garment pressed flat with no intentional distressing.	/app/uploads/temp/69bcd139-ffaa-4bcd-ba87-c5acba6f2569_2025-10-22_23-05-15.png	\N	2025-10-23 05:06:18.398799	2025-10-23 05:06:18.3988	\N
138	20534242-ef32-4fc7-a7fa-f72f3d51bd87	outerwear	Double-breasted Belted Leather Trenchcoat	top-grain lambskin leather with semi-aniline finish; midweight, supple hand with natural grain; semi-matte luster and visible patina from wear	charcoal navy-blue with cool undertone and slightly varied high-point shine	Structured trench with notched lapels and a double-breasted front; two parallel rows of large flat 4-hole matte-black buttons (upper pairs visible), set on reinforced button stands. Self-fabric belt threaded through side belt loops, tied in a front square knot to cinch the waist; belt ends cut straight with edge-stitching. Multi-panel body with vertical seaming and consistent 5 mm edge/topstitching along front edges, lapels, seams, and pocket zones; no epaulettes or cuff straps visible. Long two-piece set-in sleeves. Side pockets not visible from angle. Hem length appears mid-thigh to above-knee (exact finish obscured). Worn closed and tightly belted, creating a sculpted, cinched silhouette; leather shows creasing at elbows and belt area indicating natural break-in.	/app/uploads/temp/304fa8ba-430e-4af6-a566-8eb4351d8af5_outfit_02.jpg	/output/clothing_items/20534242-ef32-4fc7-a7fa-f72f3d51bd87_preview.png	2025-10-23 00:47:06.746147	2025-10-23 03:37:48.244808	1
100	75c9d2df-0af7-4014-a176-fcfedb4d80c5	outerwear	Long Black Luxurious Shearling Coat	genuine sheepskin shearling; nappa-finished leather exterior with long-pile lamb shearling facings; heavy weight, dense hand, semi-matte surface with subtle natural sheen	deep jet black leather with matching black high-pile shearling	Single-breasted construction with a clean fly front; closures not visible, consistent with concealed snaps or hook-and-eye tape positioned along center front. Dramatic shawl collar and wide turnback cuffs cut in long-pile shearling for maximal loft (approx. 60–80 mm). Tailored through the torso with vertical panel seams and subtle flare to a mid‑calf hem; double-needle topstitching along seamlines for reinforcement. Sleeves are full length with slight ease at the cap, finished in plush shearling cuffs. Front edges appear leather-bound beneath the fur facing. Vertical paneling suggests integrated side-entry pockets located along the hip seams (openings are visually minimal). Interior is full shearling pile for insulation; exterior seam allowances pressed and topstitched flat for bulk control. Weight and drape create a structured A-line silhouette that envelopes the underlying layers.	/app/uploads/temp/5ede93fe-4cd3-4977-90f7-37c5a534c446_outfit_30.jpg	/output/clothing_items/75c9d2df-0af7-4014-a176-fcfedb4d80c5_preview_20251023_012734.png	2025-10-23 00:47:06.698983	2025-10-23 04:21:19.066147	1
181	54b811c2-bab2-4791-86eb-5faa25111929	one_piece	white ball gown	silk or high-quality polyester satin underdress with matte luster; internal cotton coutil or sturdy satin foundation; multi-layer soft nylon tulle/net overskirt; crinoline/organza petticoat for volume; likely rigilene or spiral steel boning in bodice	bridal ivory white with a cool undertone, subtle sparkle from fine beading	Fitted, corseted bodice with sweetheart neckline and light ruching across the bust; princess seams and underbust shaping; internal grosgrain waist stay; center-back invisible zipper with hook-and-eye at top; defined waist seam with a slightly dropped/basque suggestion; right-front waist adorned with a gathered rosette/appliqué cluster; voluminous skirt built from multiple gathered tulle layers over a satin foundation, creating a soft clouded silhouette; tulle edges appear raw-cut while the satin underskirt likely finished with 25–40 mm horsehair braid to maintain flare; interior seams clean-finished or bound; overall silhouette is hourglass-to-ball-gown, fitted through torso with dramatic fullness below the waist.	/app/uploads/temp/8cb75651-d91b-46ef-8cba-ba9ee9613c29_outfit_15.jpg	/output/clothing_items/54b811c2-bab2-4791-86eb-5faa25111929_preview.png	2025-10-23 00:47:06.799222	2025-10-23 01:15:54.769671	1
114	29aff18c-043c-46fb-8ec9-718d017d64c9	outerwear	oversized leather puffer jacket with funnel collar	soft nappa leather shell, semi-gloss finish; down/feather insulated quilting; lightweight woven nylon lining	carbon black, satin luster	Hip-length puffer with generous volume but slimmer than the companion jacket; large horizontal baffles on body and sleeves; tall padded funnel collar framing the neck; center-front black molded zipper with matching black tape and clean topstitching; no storm flap; subtle side-entry welt pockets are integrated along the baffle lines at the waist; set-in sleeves with rounded, cushioned profile and concealed elasticized cuffs; hem finished cleanly without visible cords, maintaining a smooth inflated outline; quilting lines consistent in width for a uniform loft; overall styling is streamlined yet plush, with glossy leather reflecting light on the raised baffle surfaces.	/app/uploads/temp/8a2e0569-f3d3-4f10-8736-c42b0ad320f6_ChatGPT Image Mar 28, 2025, 09_09_19 PM.png	/output/clothing_items/29aff18c-043c-46fb-8ec9-718d017d64c9_preview_20251023_012739.png	2025-10-23 00:47:06.716024	2025-10-23 01:27:48.384675	1
120	7bcf06a3-952a-4609-b9c4-9caac5cb0623	tops	crewneck t-shirt	cotton single-jersey knit, medium weight, matte, soft hand	optic white	Classic ribbed crew neck with narrow binding; short sleeves hidden under jacket; flat-locked or overlocked interior seams; straight hem tucked beneath the waist belts; slim fit providing a clean base layer under the leather jacket.	/app/uploads/temp/c9bb75ce-1437-4d49-b3c1-57c90d18e99a_squall.jpg	\N	2025-10-23 00:47:06.724037	2025-10-23 00:49:15.960975	1
180	ac4946b0-7ab8-4e71-99ef-da27487160d3	tops	button-front silk blouse	lightweight silk crepe de chine with matte hand and fluid drape	deep matte black	Classic soft point collar; hidden or narrow placket with tonal small buttons, top few left unfastened to create a V neckline inside the blazer. Long sleeves concealed by outerwear. Shirt body tucked into trousers; fine rolled hem and clean overlocked internal seams typical of silk shirting. Relaxed, drapey fit that contrasts the structure of the leather blazer.	/app/uploads/temp/aa48a22c-c3a1-4034-b30b-076f617f3ca8_outfit_08.jpg	/output/clothing_items/ac4946b0-7ab8-4e71-99ef-da27487160d3_preview.png	2025-10-23 00:47:06.798233	2025-10-23 01:17:11.629491	1
184	5cc49285-3326-4da9-a346-4d952b49b97b	outerwear	kimono-sleeve wrap raincoat	medium-heavy cotton twill laminated with a glossy polyurethane waterproof film; slick hand, structured drape, high surface sheen; likely seam-sealed construction typical of rainwear	jet black with cool blue undertone; high-gloss, wet-reflective finish	Collarless, V-neck wrap-front duster length with asymmetric overlap; wide grown-on kimono sleeves with dropped shoulder and generous bicep volume; sleeves finished with deep single-fold hems. Front edges finished with wide self-fabric facings and neat single-needle topstitching approx. 5 mm from edge. Waist shaped by a self belt; no visible buttons or snaps, relying on wrap tension. Hip-level side-seam pockets are concealed with vertical entries; openings are clean and reinforced with bar tacks. Side seams straight with minimal waist suppression; center-back seam for length control and grain stability. Hem falls mid-calf with straight edge and blind-stitched finish; weighty drape encourages vertical water run-off. All exterior seams visually clean and flat, consistent with interior tape-sealed or bound seams on rainwear for water resistance. Overall silhouette: oversized through shoulders and sleeves, cinch-capable at waist, elongated and fluid under precipitation.	/app/uploads/temp/4c1c2ea1-8b2b-4ca0-b14d-71999b073b43_leather-kimono_cyberpunk_mckell_20250928144306.png	\N	2025-10-23 01:30:00.498281	2025-10-23 01:30:00.498283	\N
65	5cc3e8fc-9bcd-4e30-bd67-0b440e53709f	outerwear	Cruella DeVille Fur Coat	natural long-pile fur pelts let-out and pieced into wide vertical channels; leather hide backing; fully bagged lining in heavy silk satin; front edges lightly interfaced for support	warm cream/ecru exterior with high-loft matte pile; contrast lining in saturated crimson red, high-sheen satin	dramatic wrap-style coat cut to a cocoon silhouette; sweeping shawl collar built from double-width fur facings rolling to expose plush edge; exaggerated dolman/cocoon sleeves with very deep armholes and generous turn-back cuffs revealing red satin at the sleeve barrels; front hangs open—no buttons visible—likely hidden fur hooks and thread eyes along center-front for optional closure; hem rounded and heavily padded to maintain volume; side seams shifted forward to preserve back fullness; pelts groomed and nap-aligned for continuous flow from collar through body; edges invisibly hand-felled to the bagged silk-satin lining; shoulder line dropped; no exterior pockets observed; red lining flashes at front opening and cuffs, emphasizing movement over the black base layer.	/app/uploads/temp/55a6131b-c6af-496a-aa79-269d6d927ad1_cruella-outfit.jpg	/output/clothing_items/5cc3e8fc-9bcd-4e30-bd67-0b440e53709f_preview.png	2025-10-22 22:03:32.915335	2025-10-23 03:41:53.391912	1
185	652b24f7-0105-4c10-8a76-93703965960a	belts	self-fabric wrap sash	matching laminated cotton twill with polyurethane face; double-layered with light fusible support; smooth, semi-rigid hand	matching jet black, high-gloss	Long rectangular sash approximately 5–6 cm in width; wrapped around the waist and tied to secure the coat; edges clean-turned and edge-stitched; passes through narrow self-fabric belt carriers positioned at the side seams slightly above the natural waist; no buckle or hardware.	/app/uploads/temp/4c1c2ea1-8b2b-4ca0-b14d-71999b073b43_leather-kimono_cyberpunk_mckell_20250928144306.png	\N	2025-10-23 01:30:00.503856	2025-10-23 01:30:00.503858	\N
79	ec2b6dfd-9872-46bf-8efe-10c8d6374ead	headwear	Leather Military Cap	smooth full-grain leather with semi-aniline finish; medium firmness with subtle satin sheen; stiffened visor with internal board	inky black with cool undertone; polished gold badge accent	Structured field cap with a shallow, slightly sloped crown and stitched perimeter band; short, squared visor bound at edge and double topstitched. A tonal leather chin strap runs across the front, secured by small tab keepers. Center front carries a domed metal insignia—gold sunburst with a red star—mounted above the strap. Crown appears panelled with darted shaping and tonal edge piping; internal sweatband not visible. Hat sits aligned with the jacket, presenting a rigid, uniform look.	/app/uploads/temp/3670b846-ee55-4e14-b283-d3c74ff03eda_outfit_03.jpg	/output/clothing_items/ec2b6dfd-9872-46bf-8efe-10c8d6374ead_preview_20251023_013033.png	2025-10-23 00:47:06.674558	2025-10-23 03:37:27.424848	1
4	7b5c6c8e-bfae-407b-9575-85581d5265b2	handwear	Long Leather Opera Gloves	supple kidskin nappa leather, unlined or thin silk jersey lined at palm; smooth semi-gloss finish with fine grain	pure black, satin luster	extends above the elbow to mid-upper arm; narrow, form-fitting cut with fourchettes and triangular quirks for articulation; turned and stitched hems at top openings; no closures—entry via stretch and glove cut	/app/uploads/temp/55a6131b-c6af-496a-aa79-269d6d927ad1_cruella-outfit.jpg	/output/clothing_items/7b5c6c8e-bfae-407b-9575-85581d5265b2_preview_20251023_040958.png	2025-10-22 22:03:32.921865	2025-10-23 04:10:05.426837	1
130	c3cf387a-4fcd-44cf-b2e4-294a00f2995f	outerwear	belted four-pocket leather field motorcycle jacket	full-grain cowhide leather with semi-aniline finish; medium-heavy weight, smooth hand with subtle sheen; matching leather facing and binding at edges	warm cognac/caramel brown with slightly darker edge burnish	Structured, hip-length field jacket patterned with multi-panel construction and heavy twin-needle topstitching. Band collar with an adjustable throat-latch tab; collar and latch closed by metal snaps. Center-front metal zipper closure with a wide storm placket secured by snaps; zipper appears nickel-finish. Four symmetrical patch pockets with box pleats and straight flaps, each flap closed with metal snaps; upper left pocket bears a small crest badge. Reinforced shoulder and elbow patches with curved seam shaping. Set-in sleeves with articulated elbow seaming; plain cuffs. Self-fabric belt threaded through five external belt loops; belt closes at center front over the placket to cinch the waist. Jacket presents a close, tailored fit when belted; hem sits over the hips. Leather is clean and well-conditioned with light natural creasing, no distressing.	/app/uploads/temp/4c18c321-20a9-4e70-8021-c3a53c53bfdb_outfit_07.jpg	/output/clothing_items/c3cf387a-4fcd-44cf-b2e4-294a00f2995f_preview.png	2025-10-23 00:47:06.735298	2025-10-23 01:19:24.536917	1
139	3b901b68-c19b-4a2c-8201-944a5f616484	bottoms	stretch leggings	nylon–spandex double-knit jersey with high elastane content, opaque and matte	solid jet black	High-rise elasticated waistband (not visible) with flatlock seaming typical of active leggings; body-hugging fit; no visible pockets or external hardware; only a narrow vertical glimpse is visible below the open coat fronts.	/app/uploads/temp/0f0fbf36-46db-4904-bf71-d3a08f94c32e_outfit_18.jpg	/output/clothing_items/3b901b68-c19b-4a2c-8201-944a5f616484_preview_20251023_013207.png	2025-10-23 00:47:06.747099	2025-10-23 01:32:17.379019	1
40	4ae3a661-a2e0-4629-9cd8-563eea216247	one_piece	Strapless Black Leather Dress	supple lambskin leather, semi-aniline with high-gloss finish; medium-heavy weight with firm hand and limited stretch; smooth interior backing	jet black with blue-black highlights from the polished surface	Deep scooped, sweetheart-leaning neckline with a clean folded-and-stitched edge; sculpted bust area shaped by internal contouring and vertical paneling (princess-style shaping implied by tension lines). High waist/empire emphasis, over which a separate belt is worn. Ultra-fitted silhouette from torso through hips into an ankle-length pencil/column skirt; no slit visible, producing pronounced horizontal drag lines and compression folds across the hips and thighs characteristic of tight leather. Multiple long vertical panel seams indicated on the skirt to accommodate shaping; seams are topstitched narrowly in self color. Worn beneath the moto jacket so that the neckline and upper bodice are framed by the lapels.	/app/uploads/temp/f160eee8-fa1b-4421-8087-a0df75c5f0a7_leather-berry.jpg	/output/clothing_items/4ae3a661-a2e0-4629-9cd8-563eea216247_preview.png	2025-10-22 18:40:54.194607	2025-10-23 04:17:24.284838	1
31	90593337-5d62-45cb-9576-64d98070b9ce	outerwear	Black Shearling Aviator Jacket, Oversized	heavy full-grain pebbled leather shell with dense shearling pile lining and facings; semi-matte finish, firm hand, structured drape	deep matte black leather with matching black shearling	Hip-length, boxy oversized silhouette with set-in sleeves and articulated elbow seams. Wide notched lapels and oversize collar faced in exposed shearling; twin throat-latch straps at collar with grommeted holes and roller buckles. Asymmetric front closure with medium-gauge polished nickel zipper; zipper tape set on leather facing with visible topstitching. Left chest features a slanted decorative zipper; vertical zip hand pocket on the right with leather welt; pocket entries bar-tacked for reinforcement. Sleeve cuffs finished with leather tab adjusters, grommets, and roller buckles; hem features side waist-adjuster straps with matching buckles and grommets. All major seams double topstitched; edges turned with shearling peek at front edges, cuffs, and hem. Hardware in silver-tone nickel; interior fully shearling-lined for insulation and structure.	/app/uploads/temp/0fe0102d-c6c8-49e1-9143-efbeb2219df3_black-shearling.png	/output/clothing_items/90593337-5d62-45cb-9576-64d98070b9ce_preview.png	2025-10-22 22:02:50.458598	2025-10-23 04:20:05.60555	1
189	899d23d0-009b-4d48-a69c-95a8b9039841	outerwear	oversized shearling aviator jacket with asymmetrical zip	double-face sheepskin shearling; suede exterior with dense wool pile interior; heavy weight, matte hand; leather facing at edges	deep espresso brown suede with natural ivory shearling pile; matte finish with cool silver-toned hardware	Wide notched shearling collar and oversized lapels exposing the cream pile; off-center front closure using a heavy-gauge nickel zipper on leather tape; two vertical hand pockets with leather-bound openings and nickel zippers; exaggerated turn-back cuffs showing shearling pile; hem finished with exposed shearling facing and side adjuster tabs with rectangular nickel sliders; paneled body with double-needle seam topstitching and reinforced shoulder/armhole seams; drop-shoulder, cocoon silhouette with ample ease; interior is the native shearling—no separate lining—edges bound with leather; all hardware and zipper teeth in bright nickel; overall crisp, undistressed suede with structured drape from the shearling weight.	/app/uploads/temp/e89c6f6e-fae7-4bca-a928-92647af9450f_shearling-oversized_out2_jenny_20251007_210046.png	\N	2025-10-23 04:26:28.083258	2025-10-23 04:26:28.083262	\N
190	d35109ce-0823-47c2-b0d7-5612e29e3613	tops	chunky ribbed crewneck sweater	wool or wool-rich blend in heavy-gauge rib knit (approx. 2x2); lofty, warm hand with dry matte surface	burnt orange/rust tone with warm undertone; uniform dye, matte	Classic crew neckline finished with narrower 1x1 rib collar; long sleeves and hem terminated in wide rib cuffs and waistband for recovery; fully-fashioned shoulder shaping with linked seams; vertical rib orientation provides gentle body-contouring while remaining relaxed; clean construction with overlocked internal seams and no visible embellishment; pressed flat with no distressing.	/app/uploads/temp/e89c6f6e-fae7-4bca-a928-92647af9450f_shearling-oversized_out2_jenny_20251007_210046.png	\N	2025-10-23 04:26:28.089421	2025-10-23 04:26:28.089429	\N
191	84453fd0-628c-462f-be22-e0c262c04f7d	bottoms	mid-rise skinny jeans	cotton denim with slight elastane stretch; right-hand twill; medium weight with firm hand and slight surface sheen from wear	mid-indigo blue with cool undertone; classic golden-tan contrast topstitching; subtle uniform wash	Five-pocket construction with curved front scoop pockets and right coin pocket reinforced by copper rivets; back yoke (not visible from front) standard to skinny silhouette; front zip fly and single metal shank button at waistband in antique brass; belt loops evenly spaced around waistband; inseams chain-stitched; side seams single-needle; narrow double-turned hems finishing at the ankle; close fit through hip, thigh, and calf with clean pressed appearance.	/app/uploads/temp/e89c6f6e-fae7-4bca-a928-92647af9450f_shearling-oversized_out2_jenny_20251007_210046.png	\N	2025-10-23 04:26:28.092669	2025-10-23 04:26:28.092671	\N
137	0f9e5e5c-9dc9-4c2e-99b1-f831952d338c	bottoms	wide-leg tailored trousers	wool-blend suiting twill, smooth face, medium weight with fluid drape	matte carbon black	Full-length wide leg that falls straight and roomy, pooling slightly within the trench’s opening. Waistband and closure obscured by outerwear; no visible pleats. No pocket bags or belt loops visible; legs appear unbroken by creases, emphasizing a clean columnar line. The trousers move freely beneath the coat without catching, indicating a soft-hand fabric.	/app/uploads/temp/c8e969c9-f398-4dc8-b375-a467eacc0650_trenchcoat-extreme_street-pose_izzy_20250923125855.png	/output/clothing_items/0f9e5e5c-9dc9-4c2e-99b1-f831952d338c_preview_20251023_013208.png	2025-10-23 00:47:06.744803	2025-10-23 01:32:20.775131	1
78	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	Fitted Leather Gloves	nappa leather, fine grain, soft hand with subtle sheen	true black, semi-matte	Wrist-length gloves with close, tailored fit; smooth back without decorative points; turned-edge hems. Gloves are worn inside the trench sleeves, creating a continuous black surface with no gap at the wrist. Seams appear finely stitched along the finger edges for a sleek profile.	/app/uploads/temp/c8e969c9-f398-4dc8-b375-a467eacc0650_trenchcoat-extreme_street-pose_izzy_20250923125855.png	/output/clothing_items/fa8faacf-1ac6-4b06-a91b-def31062dede_preview.png	2025-10-23 00:47:06.673492	2025-10-23 03:33:06.015758	1
186	46dc2acf-6ed5-4a19-b14f-0a3a571a8e07	headwear	fold-over rib knit beanie	medium-gauge wool–acrylic blend in 1x1 rib knit; soft hand, dry matte surface, moderate elasticity	solid charcoal black, matte	classic cuffed beanie with doubled fold-over brim; fully fashioned crown with evenly spaced decrease lines converging at the apex; clean bind-off edge; no labels or embellishments visible; snug, close-to-head silhouette designed to maintain structure without slouching.	/app/uploads/temp/41be3e00-f309-4837-ad3f-33335876b08a_beanie-outfit_heroic_jenny_20251007_212123.png	\N	2025-10-23 04:23:36.172788	2025-10-23 04:23:36.172789	\N
187	e83bb610-de5e-4d8e-823e-74b9ad238f2c	outerwear	oversized cropped quilted leather jacket with snap front	full-grain nappa leather with soft semi-aniline finish; medium-heavy weight with supple hand and slight natural sheen; quilted over low-loft batting for loft and insulation	warm burnt cognac brown with subtle tonal variation and natural creasing, semi-matte sheen	boxy, cropped silhouette with exaggerated sculpted shoulders and voluminous sleeves; collarless round neckline finished with narrow leather facing and edge stitching; center-front placket with five tonal matte snaps (leather-covered caps) set on a reinforced stay; mixed quilting scheme—diamond quilting across body panels and curved/arched channel quilting radiating from the shoulder into sleeves for articulation; paneled shoulder construction with curved raglan-style seams and internal padding to amplify width; long straight cuffs finished with turned back facing and twin-needle topstitch; wide waist panel/hem band with internal stabilizer to prevent collapse; vertical and angular style lines on front act as quilting boundaries and shaping, with double topstitch throughout major seams; no exterior pockets or vents visible; interior not exposed, edges suggest fully lined body and sleeves with neatly bound armhole seams; leather shows gentle natural wrinkling consistent with soft nappa; overall engineered to sit cropped at the high waist while maintaining pronounced, armor-like volume.	/app/uploads/temp/41be3e00-f309-4837-ad3f-33335876b08a_beanie-outfit_heroic_jenny_20251007_212123.png	\N	2025-10-23 04:23:36.177288	2025-10-23 04:23:36.177289	\N
188	2e436c59-5838-4061-9d77-c5eb4ccf0f97	bottoms	high-rise leather leggings	smooth lamb nappa leather bonded to stretch jersey backing for recovery; medium weight with semi-gloss finish and sleek hand	deep espresso brown, uniform tone, satin-matte luster	close-fitting, second-skin silhouette from high waist through ankle; clean contoured waistband without visible belt loops or topstitch; no exterior pockets or visible fly; minimal seaming limited to inner and outer leg seams with fine-gauge edge stitching; construction suggests concealed side or back entry not visible from front; carefully pressed with uninterrupted surface for a streamlined look.	/app/uploads/temp/41be3e00-f309-4837-ad3f-33335876b08a_beanie-outfit_heroic_jenny_20251007_212123.png	\N	2025-10-23 04:23:36.179736	2025-10-23 04:23:36.179737	\N
193	11f9d8f0-67d8-4b8a-8863-1c0e405a841c	outerwear	double-breasted maxi coat-dress with exaggerated square shoulders	smooth nappa leather, semi-aniline finish, medium-to-heavy weight with firm, slightly pliable hand and subtle satin sheen	jet black with semi-gloss luster	Floor-length column silhouette with minimal waist shaping and a straight, clean hem. Notched collar with medium-width lapels; edges neatly edge-stitched (~3 mm). Double-breasted front with a 2x3 button configuration using tonal matte black buttons; corresponding machine keyhole buttonholes on the opposite placket; inner placket visually clean with no exposed hardware. Signature sculptural shoulder architecture: oversized rectangular shoulder extensions integrated into a broad yoke, creating planar wings that extend laterally well beyond the natural shoulder line; visibly padded/structured to hold shape. Set-in, fitted sleeves cut to three-quarter/bracelet length without vents or cuffs; sleeve cap smoothly eased with no puckering. Body constructed from large leather panels with visible horizontal seam joins at upper torso and lower skirt; single-needle topstitching along panel joins for reinforcement and visual definition. No external pockets, belt, or belt loops visible. Surfaces appear crisply pressed and unwrinkled, emphasizing the rigid, architectural profile.	/app/uploads/temp/2f81b6c5-cdd9-4e05-9b8f-be0330c68cd1_trenchcoat-extreme_out2_jenny_20251007_210233.png	\N	2025-10-23 04:27:47.851844	2025-10-23 04:27:47.851847	\N
68	19f5601c-25bc-46f3-8d78-aca07513ced8	headwear	Russian Fur Hat	full-pelt natural fur with dense long pile over leather hide; softly padded and fully lined in heavy silk satin with a grosgrain internal sweatband; light, lofty hand with brushed finish	buttery ivory-cream with warm beige undertone, matte pile	tall cylindrical pillbox profile with softly rounded crown; pelts nap-matched and seamed vertically, seams hand-skimmed to hide joins; brimless edge is turned and slip-stitched to lining; stabilized with lightweight buckram and haircloth interfacing at the lower band to retain structure; no external embellishment; coordinates with coat fur.	/app/uploads/temp/55a6131b-c6af-496a-aa79-269d6d927ad1_cruella-outfit.jpg	/output/clothing_items/19f5601c-25bc-46f3-8d78-aca07513ced8_preview.png	2025-10-22 22:03:32.913227	2025-10-23 03:32:03.044737	1
81	4499f26b-508f-4dfa-abc0-540eaf554023	handwear	Yellow Rogue Gloves	natural rubber latex, smooth dipped construction, high-gloss finish	vivid marigold yellow, wet-look shine	Chemically bonded (no visible stitching) with molded fingers and anatomical thumb; extended cuffs; cuffs rolled outward to form a rigid self-cuff that adds structure and a slight flare; ultra-tight fit with minimal wrinkling at the palm and wrist due to the material’s elasticity	/app/uploads/temp/1d88a234-4f7c-4588-b444-0c3bcd1e08b8_outfit_06.jpg	/output/clothing_items/4499f26b-508f-4dfa-abc0-540eaf554023_preview_20251023_041653.png	2025-10-23 00:47:06.677101	2025-10-23 04:17:00.805596	1
192	88cf5209-8ff9-4bb2-9fa6-041d8f83e511	footwear	ankle-height leather boots with block heel	smooth calf leather upper; leather stacked heel; hard-wearing rubber or leather outsole; lightly polished surface	deep chocolate brown with semi-gloss finish; tonal edge dye and stitching	Almond toe last with clean one-piece vamp; shaft to just above the ankle with minimal visible seamwork; low-to-mid stacked block heel (~35–45 mm); no visible external hardware on lateral side, presenting a sleek profile; top line slightly curved; welted-looking edge with neat, fine-gauge stitching; soles finished cleanly with dark edge ink; overall structured yet supple with refined polish.	/app/uploads/temp/e89c6f6e-fae7-4bca-a928-92647af9450f_shearling-oversized_out2_jenny_20251007_210046.png	\N	2025-10-23 04:26:28.095922	2025-10-23 04:26:28.095923	\N
177	4b6c8a4a-07eb-4e17-8a70-5f30a557b2af	footwear	lace‑up combat ankle boots	matte black leather upper with rubber lug outsole	matte jet black	Round toe, 6–7 eyelet lacing with black cotton laces, minimal stacked heel. Padded collar and stitched welt; utilitarian styling. Boots are worn tightly laced and slightly burnished at stress points. Paired with black socks that peek above the collar.	/app/uploads/temp/daba4300-c3e1-43d3-b75f-da9c92514761_outfit_05.jpg	/output/clothing_items/4b6c8a4a-07eb-4e17-8a70-5f30a557b2af_preview.png	2025-10-23 00:47:06.794286	2025-10-23 01:17:42.864778	1
76	32695434-a1b5-4294-bda6-5c2d3c672f6e	handwear	stacked gold band rings	solid yellow gold	bright yellow gold, mirror polish	Two smooth bands worn together on one finger; one slightly domed comfort-fit band (approx. 3–4 mm) and one narrower companion band (approx. 2–3 mm). No stones or engravings; the minimalist metal coordinates with the hoop earrings and is visible when the hand is raised.	/app/uploads/temp/aa48a22c-c3a1-4034-b30b-076f617f3ca8_outfit_08.jpg	/output/clothing_items/32695434-a1b5-4294-bda6-5c2d3c672f6e_preview.png	2025-10-23 00:47:06.67086	2025-10-23 01:20:16.845571	1
176	8f337fe8-02ba-47f9-a6aa-b3dfa6c39c38	eyewear	rectangular acetate sunglasses	glossy cellulose acetate frame with polycarbonate lenses	black frame with smoke grey lenses	Mid-rectangular silhouette with moderate-thickness temples and integrated nose bridge; worn pushed up on the head like a headband; hinges appear standard metal with visible rivet heads at the front corners.	/app/uploads/temp/a33110d7-8b9e-4873-94db-94d679671a32_outfit_32.jpg	/output/clothing_items/8f337fe8-02ba-47f9-a6aa-b3dfa6c39c38_preview_20251023_013038.png	2025-10-23 00:47:06.792383	2025-10-23 01:30:46.474603	1
74	af74bafe-5cec-4778-8dac-fac0a08de0c1	tops	classic button-up shirt with point collar	cotton poplin, tightly woven, crisp hand, matte surface; medium-light weight	solid deep black, matte	Standard point collar worn fully closed; collar leaf sits neatly under the trench lapels. Visible top button fastened; rest of placket concealed by the coat. Long sleeves are present but entirely covered by the outerwear. Clean, pressed appearance with no visible pocketing or ornament; hem and side seams not visible due to layering.	/app/uploads/temp/c8e969c9-f398-4dc8-b375-a467eacc0650_trenchcoat-extreme_street-pose_izzy_20250923125855.png	\N	2025-10-23 00:47:06.665695	2025-10-23 00:49:15.960975	1
107	88e2124d-8b5a-4f79-8fd1-640422c12d20	earrings	true wireless earbuds	molded ABS/PC plastic with glossy finish and silicone ear tips	clean optic white	Minimal stem-style in-ear earbuds seated in both ears; smooth, flush profile functioning as ear-worn tech accessory; no visible wires or additional hardware.	/app/uploads/temp/a33110d7-8b9e-4873-94db-94d679671a32_outfit_32.jpg	/output/clothing_items/88e2124d-8b5a-4f79-8fd1-640422c12d20_preview_20251023_013046.png	2025-10-23 00:47:06.709005	2025-10-23 01:30:57.235323	1
106	ef3c9fd1-2938-4d96-83f9-c6f6e7230099	neckwear	delicate pendant necklace	fine jewelry chain in metal with polished finish	yellow gold	Thin cable chain resting at the base of the neck with a small charm-style pendant centered on the collarbone; discreet spring-ring or lobster clasp at back (not visible); minimalistic scale designed to sit cleanly above the trench’s neckline, adding a subtle metallic accent without competing with the belt hardware.	/app/uploads/temp/b5d28f51-2a5d-425d-b0b2-9e121b13dfbe_outfit_01.jpg	/output/clothing_items/ef3c9fd1-2938-4d96-83f9-c6f6e7230099_preview_20251023_013108.png	2025-10-23 00:47:06.708022	2025-10-23 01:31:16.681513	1
24	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	Leather Business Skirt, High-Waisted	lambskin nappa leather matching the blazer; semi-aniline, smooth, semi-gloss surface; lined in black stretch polyester satin for comfort and glide	jet black, uniform tone with satin luster	Close-fitted pencil silhouette cut to a midi/over-knee length, presenting a sleek columnar line. Clean-faced waist without external waistband, sitting high under the blazer. Panel construction with front and back darts for hip shaping; seams subtly topstitched for reinforcement without decorative contrast. Center-back invisible zipper closure and a center-back vent for stride ease. Hem is clean-turned and stitched from inside for an uninterrupted exterior finish; lining is anchored at the vent and hem to prevent roll-out.	/app/uploads/temp/42114067-c64a-4716-a383-f7334b02cf64_business-suit_punk_kat_v2.png	/output/clothing_items/2adbc096-894a-43de-89fe-90e7c9332764_preview.png	2025-10-22 22:16:41.939841	2025-10-23 03:33:21.000313	1
178	c19ff0b6-0a88-44e8-b6d5-cb4b95650829	neckwear	square silk neckerchief tied at throat	silk twill, medium weight with crisp hand and subtle luster, hand-rolled edges	burnt sienna/rust ground with deep black border	Small square folded on the bias and tied in a short kerchief knot at center front	/app/uploads/temp/77a6d071-59b3-4f43-9fd5-9d61586948d2_outfit_10.jpg	/output/clothing_items/c19ff0b6-0a88-44e8-b6d5-cb4b95650829_preview_20251023_041021.png	2025-10-23 00:47:06.795942	2025-10-23 04:10:29.525562	1
194	5e2048b7-5c60-4714-b85b-e315baa0165b	one_piece	cold-shoulder crewneck leather maxi dress	supple nappa leather with smooth, fine grain; chrome-tanned, medium weight with soft hand and controlled, structured drape; lightly polished surface	jet black with a cool undertone and semi-matte satin luster	Close, sculpted bodice with a high crew neckline finished in narrow self-leather binding and single-needle edge-stitching. Cold-shoulder architecture formed by oval cutouts centered over each shoulder; edges are clean-turned and topstitched for stability. Short upper-arm sleeve panels extend from front to back, creating the exposed-shoulder void; sleeve hems are narrowly turned with neat single-needle stitching. Visible seam architecture includes shoulder and armscye seams with clean topstitching; subtle shaping through the bust achieved via curved paneling/darts. The lower portion resolves into a full-length A-line skirt engineered from multiple gored panels; vertical panel seams are double-stitched for strength and definition, producing soft, glossy folds in the leather. Hem is narrow-turned and uniformly topstitched. Overall silhouette: semi-fitted through torso, releasing into a long, fluid flare. Finish is smooth and pressed with no distressing or abrasion.	/app/uploads/temp/47bbd997-7d8a-49c6-9693-2f5ae6555959_dress-gloves_portrait-intimate_tanya_20251007_234140.png	\N	2025-10-23 04:38:49.211448	2025-10-23 04:38:49.21145	\N
77	16413e54-fc7f-4aef-af26-c75ddea147f0	footwear	biker ankle boots with lug sole	full-grain leather upper; thick rubber commando outsole; matte finish	matte black with silver-tone hardware	Round toe, ankle-height shaft; double strap configuration—one across the instep and one at the collar—both with roller buckles and multiple metal eyelets; decorative grommet detailing on straps; heavy lug outsole with low block heel and blacked edges; robust construction and stitched edge line emphasize utility styling while complementing the moto jacket hardware.	/app/uploads/temp/c5cea7ae-e366-447c-9005-3f5e51975261_tae-outfit_heroic_kaysha_20250926121425.png	\N	2025-10-23 00:47:06.672349	2025-10-23 00:49:15.960975	1
82	3fc05e05-63d3-4abf-a673-185c437dcd1a	bottoms	slim-fit leather trousers	smooth-finish cowhide leather with light glaze; backed with thin tricot for comfort and stability	solid black with subtle satin luster	Mid-rise waist with belt loops; front fly closure with hidden metal zipper and single waistband snap or button; slim straight leg molded to the body; tonal topstitching along side seams and rise; minimal pocket bulk to keep the silhouette fitted; waistband supports layered belts and a hip chain.	/app/uploads/temp/c9bb75ce-1437-4d49-b3c1-57c90d18e99a_squall.jpg	\N	2025-10-23 00:47:06.678118	2025-10-23 00:49:15.960975	1
84	7d67bc68-6b48-4f08-a45b-68d0bcc2ee99	bottoms	slim-fit stretch denim jeans	cotton/elastane denim in right-hand twill; mid-weight with moderate stretch and smooth surface	medium indigo blue with cool undertone and subtle uniform wash; matte finish	Classic five-pocket construction—two front curved pockets with coin pocket and two back patch pockets (rear not visible but implied by standard block). Zip fly with metal button at waistband; contrast tobacco topstitching and bar tacks at stress points. Mid-rise, slim through thigh and calf; legs are neatly tucked into tall boots for a clean line.	/app/uploads/temp/4c18c321-20a9-4e70-8021-c3a53c53bfdb_outfit_07.jpg	\N	2025-10-23 00:47:06.680515	2025-10-23 00:49:15.960975	1
95	d62b2137-3968-4119-bdbc-d4aa3a97a17f	footwear	pull-on ankle boots with low block heel	full-grain leather upper with lightly waxed matte finish; leather sock lining; rubber outsole	solid matte black	Minimal round-toe last with 25–30 mm low block heel; short ankle shaft sitting just above the malleolus; clean vamp without cap or broguing; side quarters constructed with hidden elastic gore panels for pull-on entry (no visible zippers); stitched welt look with single-row black thread; edges inked and burnished; outsole exhibits slightly raised profile at toe and heel for durability; pairs cleanly with the leggings’ ankle-length hem.	/app/uploads/temp/7dc3c673-4815-4c76-9d9c-c62162e33971_shapes.png	\N	2025-10-23 00:47:06.692323	2025-10-23 00:49:15.960975	1
108	af816cfb-0e0d-49d1-8227-48f6ab607f98	belts	double layered leather belts	full-grain vegetable-tanned leather straps with edge burnish; hardware in nickel-plated steel	dark chestnut brown with natural patina; silver-tone hardware	Two independent straps worn low on the waist, slightly offset and crossing; each features a square roller buckle, multiple punched eyelets, and keeper loops; threaded through trouser belt loops; the stacked belts add weight and shape at the waist and secure a separate wallet/hip chain.	/app/uploads/temp/c9bb75ce-1437-4d49-b3c1-57c90d18e99a_squall.jpg	\N	2025-10-23 00:47:06.710202	2025-10-23 00:49:15.960975	1
75	4b138359-1122-4670-b035-c7b9080de935	bags	crossbody bag with wide webbing strap	dense cotton canvas webbing strap; firm, flat weave with soft hand and minimal sheen	vivid scarlet red strap	Strap width approximately 40–50 mm, worn diagonally from left shoulder to right hip. Strap shows folded end with box-and-cross reinforcement stitching near the shoulder area; hardware and bag body are out of frame.	/app/uploads/temp/3425368e-7e3f-4d00-9c57-c5641553aaea_outfit_31.jpg	/output/clothing_items/4b138359-1122-4670-b035-c7b9080de935_preview.png	2025-10-23 00:47:06.6683	2025-10-23 01:21:21.302197	1
83	fa06eba3-7a72-4f19-abef-2e1a5ff95bc8	neckwear	pendant necklace with ring charm	oxidized sterling-silver curb chain and machined ring pendant	antiqued silver with subtle darkened patina in crevices	Mid-length chain worn over the tee and under the open jacket; medium-gauge curb links; pendant composed of a smooth metal ring accompanied by a small charm; no clasp visible due to styling—piece is held aloft by the wearer in the image, demonstrating free movement and chain drape.	/app/uploads/temp/c9bb75ce-1437-4d49-b3c1-57c90d18e99a_squall.jpg	/output/clothing_items/fa06eba3-7a72-4f19-abef-2e1a5ff95bc8_preview_20251023_013110.png	2025-10-23 00:47:06.679572	2025-10-23 01:31:17.807759	1
80	c89c369c-b516-487a-9aa5-4ff22ac3d1e8	headwear	metal hair barrette clip	polished metal with enamel-coated surface	gunmetal with black enamel	Small decorative barrette positioned on the side of the head to secure hair; spring-hinged clasp construction with smooth rounded edges. Minimalist glossy finish with a compact silhouette.	/app/uploads/temp/f80333a9-8e62-44f2-82f8-e592fbdb4e51_outfit_16.jpg	/output/clothing_items/c89c369c-b516-487a-9aa5-4ff22ac3d1e8_preview_20251023_013031.png	2025-10-23 00:47:06.675994	2025-10-23 01:30:37.06258	1
86	6f764188-c3af-4bee-b619-4a346fc08a1b	tops	fine-gauge crewneck knit top	lightweight jersey knit, soft hand, matte surface (cotton or viscose fiber profile)	solid deep black, matte	Close-fitting crew neckline with narrow rib binding; acts as a base layer under the shearling jacket with only the collar area visible. Clean finish with no visible graphics or embellishment; sleeves and torso fully covered by outerwear.	/app/uploads/temp/1fea3491-b89a-4456-8969-1397edd74a35_outfit_24.jpg	\N	2025-10-23 00:47:06.682575	2025-10-23 00:49:15.960975	1
89	ce1d7890-0588-4038-880d-34ffd89dbdb0	tops	long-sleeve crewneck T-shirt	cotton-rich jersey with a small amount of elastane; medium weight; heathered texture; matte	cool slate grey heather	Classic crew neckline finished with self-fabric rib binding; set-in sleeves with slight cling; double-needle coverstitching at cuffs and bottom hem; smooth, lightly draped hand; worn as the sole layer for the second wearer and visible at sleeves and chest.	/app/uploads/temp/0f0fbf36-46db-4904-bf71-d3a08f94c32e_outfit_18.jpg	\N	2025-10-23 00:47:06.685499	2025-10-23 00:49:15.960975	1
90	6364f3b5-4545-4d2d-b3b7-c6e3282006b0	belts	attached self belt for leather jacket	matching cowhide leather strap with stitched edges and interfacing for firmness	cognac brown to match jacket with slightly darker edge paint	Approximately 4 cm width, five punched eyelets; rectangular single-prong buckle in antique brass finish with keeper loop. Threaded through exterior belt loops sewn to the jacket body; worn fastened to cinch the jacket waist over the zipper and snap placket.	/app/uploads/temp/4c18c321-20a9-4e70-8021-c3a53c53bfdb_outfit_07.jpg	\N	2025-10-23 00:47:06.687095	2025-10-23 00:49:15.960975	1
92	abd6f0e0-d89a-4063-925c-b7a72a0f1d06	bottoms	tailored straight-leg trousers	medium-weight wool-blend suiting in a tight twill weave; dry hand with crisp press retention; likely half-lined to knee	matching cocoa brown, matte finish	Mid-to-high rise waistband with internal curtain and blind pick-stitching; front zip fly with hook-and-bar closure. Straight leg with subtle pressed center creases (implied through drape). Side seams clean; pockets not visible but typical slant side pockets and back welt pockets assumed from tailoring logic. Length extends full to shoe level though footwear is not visible. Silhouette reads streamlined and elongated, coordinating tonally with the blazer.	/app/uploads/temp/aa48a22c-c3a1-4034-b30b-076f617f3ca8_outfit_08.jpg	\N	2025-10-23 00:47:06.689609	2025-10-23 00:49:15.960975	1
93	2c09f9b9-1c37-4e68-8d63-e36cad4cfe10	bottoms	slim leather trousers	smooth genuine leather with subtle luster; midweight with soft, pliable hand and body-conforming drape	deep black, glossy under light	Close-fitting, straight-to-slim leg cut; clean front with minimal visible seaming; light creasing along knees and shins indicative of supple leather; hem length extends into footwear area (not visible). Closure and pocketing are concealed by the outerwear, but the silhouette reads as a streamlined, tailored leather pant layered beneath the trench.	/app/uploads/temp/b5d28f51-2a5d-425d-b0b2-9e121b13dfbe_outfit_01.jpg	\N	2025-10-23 00:47:06.690503	2025-10-23 00:49:15.960975	1
88	c5b20de2-0b0c-4077-b4f6-752afa2dde6f	outerwear	oversized shearling aviator jacket	sheepskin shearling with full-grain leather face; heavy weight, matte finish with subtle natural grain; plush wool pile lining throughout, including collar and facings	matte black leather body with natural ivory shearling pile	Hip-length, boxy silhouette with dropped shoulders and ample ease; extra-wide shirt-style shearling collar. Center-front metal zipper (single slider, antique-brass tone) on a narrow leather tape, zipped to mid-chest. Turn-back cuffs reveal 20–25 mm of ivory pile. Slanted side-entry welt hand pockets at hips with leather welts. Characteristic shearling panel construction with butted seams and twin-needle topstitching along sleeve and body panels; visible leather throat-latch tab on left chest with punched metal eyelets for a buckle closure across the collar (buckle side not visible). Straight hem; lightly broken-in creasing at sleeves and body. Worn as the top layer over a knit sweatshirt, the dense matte leather contrasts with the soft high-loft pile at collar and cuffs.	/app/uploads/temp/3425368e-7e3f-4d00-9c57-c5641553aaea_outfit_31.jpg	/output/clothing_items/c5b20de2-0b0c-4077-b4f6-752afa2dde6f_preview_20251023_012730.png	2025-10-23 00:47:06.684549	2025-10-23 01:27:37.990523	1
109	ea9da5e7-8c65-46e2-bbe8-3f0e87815a78	neckwear	delicate pendant necklace	fine metal chain and cast medallion, likely sterling‑tone	polished cool silver	Thin cable chain of choker-to-short length with a small round medallion pendant centered at the chest. Clasp not visible; pendant sits above the tank’s V neckline and under the duster and jacket.	/app/uploads/temp/daba4300-c3e1-43d3-b75f-da9c92514761_outfit_05.jpg	/output/clothing_items/ea9da5e7-8c65-46e2-bbe8-3f0e87815a78_preview_20251023_013104.png	2025-10-23 00:47:06.711183	2025-10-23 01:31:10.841325	1
94	90cc4fa2-deac-43a2-9f49-d4d4e53040bc	neckwear	paisley bandana scarf	lightweight cotton plain-weave, crisp hand	vivid scarlet red ground with white and black classic paisley print	Square scarf with narrow rolled or overlocked edges; currently hand-carried rather than tied; adds a high-contrast accent against the monochrome outerwear.	/app/uploads/temp/a33110d7-8b9e-4873-94db-94d679671a32_outfit_32.jpg	/output/clothing_items/90cc4fa2-deac-43a2-9f49-d4d4e53040bc_preview_20251023_013110.png	2025-10-23 00:47:06.691405	2025-10-23 01:31:18.899442	1
87	af6ecbbf-7753-4aab-a756-12e8ada84282	one_piece	high-gloss stretch catsuit	natural latex rubber sheeting approximately 0.4–0.6 mm with glued seams; slick, elastic, high-recovery; mirror gloss surface	emerald green ground with canary yellow contrast panel glimpsed at center torso/hip	Second-skin fit with full-length sleeves visible under the jacket; seamless appearance on arms indicates bonded construction rather than stitched; torso shows a yellow chevron/center panel peeking beneath the jacket and above the belt, suggesting front color-blocking typical of performance catsuits; neckline obscured by jacket but garment reads as a continuous unitard; hem and edges are rolled/trimmed latex bands to prevent curling; the latex’s high slip allows the outer leather to glide over it, creating pronounced contrast between glossy latex and matte leather; intended silhouette is sculpted and compressive, emphasizing clean, uninterrupted lines.	/app/uploads/temp/1d88a234-4f7c-4588-b444-0c3bcd1e08b8_outfit_06.jpg	/output/clothing_items/af6ecbbf-7753-4aab-a756-12e8ada84282_preview_20251023_013157.png	2025-10-23 00:47:06.683537	2025-10-23 01:32:05.631907	1
97	0f519716-0f63-4857-9c3d-189b910b7015	tops	mock-neck rib-knit sweater	fine-gauge ribbed jersey knit, likely wool or wool-blend; soft hand, elastic recovery; matte	jet black	Close-to-body fit with a short mock neck that sits just below the jacket collar. Long sleeves with narrow rib cuffs extending beyond the jacket sleeves at the wrists. Clean tubular knit construction with minimal seams; no visible logos or surface decoration. Serves as a heat-retaining base layer under the shearling jacket.	/app/uploads/temp/f80333a9-8e62-44f2-82f8-e592fbdb4e51_outfit_16.jpg	\N	2025-10-23 00:47:06.695171	2025-10-23 00:49:15.960975	1
99	b6783aa9-ab7a-4598-a607-59c55e1fd868	hosiery	crew socks	cotton‑blend rib knit with elastane for stretch	matte black	Classic ribbed leg, ankle height just above the boot collar; snug fit with elasticized cuff to prevent slippage.	/app/uploads/temp/daba4300-c3e1-43d3-b75f-da9c92514761_outfit_05.jpg	\N	2025-10-23 00:47:06.697389	2025-10-23 00:49:15.960975	1
101	71d07506-19ed-4ed7-9341-900a4a486496	tops	crewneck jersey top (partially visible)	lightweight cotton–modal stretch jersey with smooth hand and soft drape	black ground with tiny red and pink ditsy floral print glimpsed at neckline	Mostly concealed under outerwear; narrow rib or self-fabric neckband with coverstitched finish visible at the opening. Close-to-body fit suggested by flat lie under jacket; clean, unembellished construction with overlocked interior seams typical of jersey tops.	/app/uploads/temp/0fe0102d-c6c8-49e1-9143-efbeb2219df3_black-shearling.png	\N	2025-10-23 00:47:06.699871	2025-10-23 00:49:15.960975	1
102	a5dcf6f1-9c93-476a-96e6-1a5555cc45ad	bottoms	high‑waisted A‑line mini skirt with front placket	lightweight denim/chambray twill, cotton with slight structure	washed slate‑blue with cool undertone	Clean waistband and slight A‑line flare ending mid‑thigh. Center‑front full placket with four evenly spaced brass shank buttons; worn buttoned. No belt loops or pockets visible. Hem appears double‑turned and single‑needle stitched. Sits at the natural waist, layered over black cycling shorts that extend below the hem.	/app/uploads/temp/daba4300-c3e1-43d3-b75f-da9c92514761_outfit_05.jpg	\N	2025-10-23 00:47:06.700793	2025-10-23 00:49:15.960975	1
103	5add0242-d98c-45aa-9a7a-e2cc038e99d6	bottoms	high-waisted A-line mini skirt	medium-weight wool-blend crepe with slight stretch; matte surface; stable body and crisp hand	rich cranberry red, cool undertone	Above-knee length with gentle A-line flare; clean faced waist (no external waistband) with two symmetrical front release darts for shaping; smooth front with no visible closures; neatly pressed 3 cm turn-up hem finished with blind stitching; fits at or slightly above the natural waist, providing a structured silhouette that contrasts against the cropped jacket.	/app/uploads/temp/c5cea7ae-e366-447c-9005-3f5e51975261_tae-outfit_heroic_kaysha_20250926121425.png	\N	2025-10-23 00:47:06.701727	2025-10-23 00:49:15.960975	1
104	da88a39f-0bbb-4914-ab66-2b9db934cf90	tops	V‑neck jersey tank top	stretch cotton-modal jersey, fine gauge, smooth hand	solid matte black	Sleeveless close‑to‑body fit with a deep V neckline. Self‑binding at neckline and armholes; hem tucked into the skirt. Provides a flat, minimal base layer beneath the duster and jacket.	/app/uploads/temp/daba4300-c3e1-43d3-b75f-da9c92514761_outfit_05.jpg	\N	2025-10-23 00:47:06.705109	2025-10-23 00:49:15.960975	1
98	f7ab03ee-f750-402e-9577-7e563b9de897	neckwear	fine chain pendant necklace	18k yellow gold cable chain with bezel-set round dark gemstone cabochon	warm yellow gold with near-black stone	delicate 1–1.2 mm link gauge chain at short length sitting high on chest within coat’s neckline; small 6–8 mm circular pendant centered; spring-ring clasp at back; minimal movement and no additional charms.	/app/uploads/temp/e3d895c1-af91-4e9a-a449-3dccebb57093_fur-fox_cyberpunk_jenny_20250928135503.png	/output/clothing_items/f7ab03ee-f750-402e-9577-7e563b9de897_preview_20251023_013116.png	2025-10-23 00:47:06.696122	2025-10-23 01:31:26.831462	1
116	59fba5ea-cbd9-42a3-bcc9-a9f4ed05a33d	bottoms	slim tapered stretch jeans	cotton-elastane denim, compact right-hand twill, medium weight with slight give	inky charcoal-navy wash, low sheen	Mid-rise with tapered leg; minimalist presentation with tonal stitching; standard zip fly and waistband with belt loops; pocketing not visible from the angle but standard five-pocket proportions are suggested by seam placement; hems cropped out of frame; the slim silhouette balances the bulky puffer jacket worn over it, with the jacket hem overlapping the waistband.	/app/uploads/temp/8a2e0569-f3d3-4f10-8736-c42b0ad320f6_ChatGPT Image Mar 28, 2025, 09_09_19 PM.png	\N	2025-10-23 00:47:06.719222	2025-10-23 00:49:15.960975	1
112	7c8ccb70-6bd4-44b5-9acb-7cfce4eef5f9	bags	oversized padded intrecciato leather clutch	soft nappa leather woven into wide, padded lattice strips with foam interlining; unlined or thinly lined interior	ink black with soft satin-matte sheen	Rectangular pillow-like pouch held under the arm/hand. Hand-braided basket weave with squared cells; edges turned and stitched. Hidden top magnetic or frame-style closure maintains a clean exterior with no visible hardware. No strap present; purely handheld. The padded weave provides dimensional texture contrasting the smooth leather blazer.	/app/uploads/temp/aa48a22c-c3a1-4034-b30b-076f617f3ca8_outfit_08.jpg	/output/clothing_items/7c8ccb70-6bd4-44b5-9acb-7cfce4eef5f9_preview.png	2025-10-23 00:47:06.714026	2025-10-23 01:20:30.504629	1
145	b1cb499b-21bd-4132-a96e-ed7cad8788ec	headwear	vintage-style open-face motorcycle helmet	fiberglass/ABS composite shell with glossy lacquer; EPS foam impact liner; brushed suede-like comfort padding at cheeks; synthetic leather edge binding	ivory/eggshell white shell with vertical red and green racing stripes; black trim	Classic open-face silhouette with a rounded dome. Chrome-look rim and black lower gasket. Vertical twin racing stripes centered from crown to brow. Exposed cheek pads in tan suede finish. Retention uses a standard D-ring chin strap with keeper; strap in black webbing. No face shield fitted; accommodates goggles. Finish is highly polished and free of distressing.	/app/uploads/temp/4c18c321-20a9-4e70-8021-c3a53c53bfdb_outfit_07.jpg	/output/clothing_items/b1cb499b-21bd-4132-a96e-ed7cad8788ec_preview_20251023_013028.png	2025-10-23 00:47:06.755057	2025-10-23 01:30:37.955948	1
110	6c504f1f-f1d0-4061-94a4-5155aa4d5c3d	earrings	gold-tone drop earrings	polished gold-tone metal with small articulated elements	yellow gold, high polish	Delicate short-drop design: a small stud or hook connects to a dangling tear-shaped charm/ball element. Approx. 20–30 mm overall drop. Smooth, reflective finish; minimal hardware visible from the front. Worn as a symmetric pair and kept clear of fabric layers.	/app/uploads/temp/868e72c4-75f2-42f4-9d06-d46b8b3c83dc_outfit_12.jpg	/output/clothing_items/6c504f1f-f1d0-4061-94a4-5155aa4d5c3d_preview_20251023_013044.png	2025-10-23 00:47:06.712107	2025-10-23 01:30:50.922742	1
111	ac8e4413-0b48-4b35-8140-62153aa5cf82	earrings	small hoop earrings	solid 14k yellow gold, polished	warm yellow gold high polish	Minimal close-to-lobe hoops, approximately 12–15 mm diameter, rounded cross-section, hinged click-top closure. Clean, unadorned finish complements the tailored ensemble.	/app/uploads/temp/aa48a22c-c3a1-4034-b30b-076f617f3ca8_outfit_08.jpg	/output/clothing_items/ac8e4413-0b48-4b35-8140-62153aa5cf82_preview_20251023_013042.png	2025-10-23 00:47:06.71303	2025-10-23 01:30:51.600174	1
113	9649bca4-c62c-45db-8da5-c1cfc465d15f	one_piece	oversized quilted wool-bouclé mascot jumpsuit	high‑loft bouclé wool knit shell densely padded with needle‑punched wool batting; fully lined in smooth cotton sateen; matte, plush hand with spongy resilience and heavy overall weight	warm ivory with diffuse blush‑pink and pale sage cast; completely matte	Full‑body one‑piece engineered to form a spherical, cloudlike silhouette using concentric baffle quilting and tufted pods that wrap the torso and sleeves as continuous volumes. Round face aperture finished with self‑fabric binding and clean edge. Integrated sleeves terminate in narrow internal rib cuffs that grip the wrists while remaining hidden within the fleece mass. Center‑back concealed two‑way nylon coil zipper with inner placket for comfort; zipper top secured with a small hook‑and‑bar. Interior seams are overlocked with cotton tape binding at stress points and bartacks at arm openings. Weight is supported by internal adjustable webbing shoulder harness; no exterior pockets or trim. Hem volume drops to mid‑calf, overlapping and partially obscuring footwear. Surface is lightly brushed to enhance loft and reads as clustered rosettes across the body.	/app/uploads/temp/17886008-4de4-486c-beaa-f584ab6ef5e9_wool_coat_2_by_0pik_0ort_d9j01y0-414w-2x.png	/output/clothing_items/9649bca4-c62c-45db-8da5-c1cfc465d15f_preview_20251023_013155.png	2025-10-23 00:47:06.71505	2025-10-23 01:32:07.170942	1
117	2bc7fe85-ab94-483a-ac79-ed55ef35e4f9	bottoms	fleece jogger sweatpants	cotton–polyester fleece with brushed interior and smooth face	warm taupe brown, matte	Relaxed tapered leg; slanted side-seam pockets; wide ribbed waistband with internal drawcord (drawcord not visible); likely ribbed cuffs at ankles though out of frame; overlocked interior seams with coverstitching at pocket openings; creasing at thigh from wear; right hand inserted into pocket.	/app/uploads/temp/0f0fbf36-46db-4904-bf71-d3a08f94c32e_outfit_18.jpg	/output/clothing_items/2bc7fe85-ab94-483a-ac79-ed55ef35e4f9_preview_20251023_013213.png	2025-10-23 00:47:06.720178	2025-10-23 01:32:21.650693	1
119	cd8b4bbd-86fa-4187-866d-492f6d9f8de6	tops	fitted crewneck long-sleeve jersey top	fine-gauge cotton or cotton-modal jersey; lightweight, smooth hand, matte finish with slight natural stretch	true black, matte	Classic crew neckline finished with narrow self-fabric binding; set-in sleeves; slim close-to-body fit to layer cleanly under heavy outerwear. Construction likely uses overlocked side seams and coverstitched hems; neckline sits just inside the coat’s collar, providing a uniform black ground beneath the shearling.	/app/uploads/temp/5ede93fe-4cd3-4977-90f7-37c5a534c446_outfit_30.jpg	\N	2025-10-23 00:47:06.722315	2025-10-23 00:49:15.960975	1
118	c3f43ff6-710e-4127-8ae9-67b8e96e6907	outerwear	oversized shearling aviator jacket	suede-finished leather shell with full-pile genuine shearling lining; heavyweight, dense, matte suede hand with plush interior; quilt-stitched shearling at undercollar	weathered warm taupe-brown shell with natural ivory shearling trim, matte finish	Boxy, slightly cropped silhouette ending at the high hip. Extra-wide convertible collar fully faced in ivory shearling; undercollar features diamond quilting for structure. Center-front heavy-gauge metal zipper (antique silver tone) set on leather tape; zipper stops at hem with visible shearling facings at the placket. Two-piece voluminous sleeves with low dropped shoulder; deep turn-back shearling cuffs approximately 7–9 cm high. Straight hem finished with a shearling-facing band around the perimeter. Panel construction with broad seam allowances and double topstitching along body and sleeve seams for reinforcement. No external straps or belts visible; pocket openings not exposed on the visible panels. Suede exhibits soft patina and subtle tonal variation consistent with brushed finish.	/app/uploads/temp/1fea3491-b89a-4456-8969-1397edd74a35_outfit_24.jpg	/output/clothing_items/c3f43ff6-710e-4127-8ae9-67b8e96e6907_preview_20251023_012639.png	2025-10-23 00:47:06.721133	2025-10-23 01:26:47.359	1
123	69925246-dfaf-49cd-bbdf-e8458ab694b5	neckwear	O-ring leather choker	smooth vegetable-tanned leather strap, approximately 2 cm wide, with polished metal hardware	matte black strap with bright silver ring	Centered polished round O-ring (approx. 4 cm diameter) fixed with riveted tabs; edges of strap painted and burnished; worn snug at the neck so the ring sits directly at center front, echoing the jacket’s metal accents.	/app/uploads/temp/c5cea7ae-e366-447c-9005-3f5e51975261_tae-outfit_heroic_kaysha_20250926121425.png	/output/clothing_items/69925246-dfaf-49cd-bbdf-e8458ab694b5_preview_20251023_013102.png	2025-10-23 00:47:06.726938	2025-10-23 01:31:10.923051	1
128	e1f00fcc-11d2-4963-858e-e0c255967fad	belts	utility waist belt with attached pouch	full-grain leather strap with reinforced edge paint; hardware in blackened nickel	dark chocolate brown strap with gunmetal hardware	Threaded through external belt loops at the hem of the moto jacket; 35–40 mm width strap with perimeter edge-stitching; single-prong rectangular buckle with keeper; multi-hole punching with metal eyelets for durability; small gusseted leather pouch fixed near right front hip, secured to the belt by stitched-on carrier and snap-flap closure, adding a tactical note while also weighting the jacket hem; belt cinches the jacket creating a slightly nipped waist and stabilizing the cropped silhouette.	/app/uploads/temp/1d88a234-4f7c-4588-b444-0c3bcd1e08b8_outfit_06.jpg	\N	2025-10-23 00:47:06.732979	2025-10-23 00:49:15.960975	1
134	c3a180f3-7ce9-492f-91aa-84c7395fe28f	belts	logo-buckle leather waist belt	firm full-grain leather strap with painted and burnished edges; smooth face, matte to semi-matte finish	black strap with warm gold-tone hardware	Medium width (approx. 35–40 mm) strap worn over the trench at the natural waist; features a large interlocking double-G monogram buckle in polished/brushed gold-tone metal; single prong and multiple punched holes for adjustment; belt overlays the coat without passing through loops, sharply defining the coat’s waist and adding a metallic focal point.	/app/uploads/temp/b5d28f51-2a5d-425d-b0b2-9e121b13dfbe_outfit_01.jpg	\N	2025-10-23 00:47:06.740436	2025-10-23 00:49:15.960975	1
127	a564252a-dd78-40c9-aabb-0620370eccdf	bags	medium technical backpack	durable woven nylon (Cordura-like) with light padding and webbing reinforcement; matte texture	solid black	Two padded, adjustable shoulder straps with black acetal sliders and keeper loops; body likely dual-compartment with top zipper access; soft-structured with subtle volume; backpack straps are routed under the leather jacket collar area and over the shoulders, compressing the jacket and creating slight drape at the back.	/app/uploads/temp/a33110d7-8b9e-4873-94db-94d679671a32_outfit_32.jpg	/output/clothing_items/a564252a-dd78-40c9-aabb-0620370eccdf_preview.png	2025-10-23 00:47:06.731659	2025-10-23 01:20:27.161698	1
126	371de43a-ce4d-4a83-b0b6-a02cda1c329f	outerwear	asymmetrical moto jacket with exaggerated shoulders	top-grain cowhide leather with semi-aniline, high-sheen finish; medium-heavy weight; smooth hand; fully lined in satin-weave acetate with light shoulder and front interfacing	jet black with glossy luster; bright silver-tone hardware	Classic Perfecto construction left open; wide notched lapels secured by snap studs; asymmetrical 8–10 mm nickel zipper tape running from right hem to left shoulder; right slanted chest welt pocket with zipper; two lower slanted zip pockets; small left waist coin pocket with snapped flap; epaulets on shoulders with capped snaps; set-in two-piece sleeves with zippered vent cuffs; cropped, boxy body ending around high hip; lightly padded/shaped shoulders characteristic of late-80s styling; heavy double-needle topstitching along seams and edges; back yoke and two-piece back panels; belt loops at hem with a removable waist belt and roller buckle (belt not fastened); the jacket sits over a strapless gown, framing the sweetheart neckline and creating a glossy–matte texture contrast.	/app/uploads/temp/8cb75651-d91b-46ef-8cba-ba9ee9613c29_outfit_15.jpg	/output/clothing_items/371de43a-ce4d-4a83-b0b6-a02cda1c329f_preview_20251023_012628.png	2025-10-23 00:47:06.730706	2025-10-23 01:26:36.849232	1
131	90e47363-9ccb-496a-9514-47f57a1e6522	neckwear	beaded choker necklace	round glass or semi-precious beads strung on coated beading wire with small metal spacer beads	dark garnet red beads with gunmetal/silver-toned spacers	Short collarbone-length strand sitting at the base of the neck; evenly spaced spherical beads with subtle luster; secured with a small metal clasp (barrel or lobster type) centered at the back; worn inside the coat neckline for a refined focal point.	/app/uploads/temp/305a4194-f611-47a3-a609-3720c8456263_red-baggy_mirror-ots_jenny_20250928140341.png	/output/clothing_items/90e47363-9ccb-496a-9514-47f57a1e6522_preview_20251023_013059.png	2025-10-23 00:47:06.73722	2025-10-23 01:31:08.013305	1
133	a842ea63-03b4-4f51-b23b-e93416fd1865	bottoms	mid-rise straight-leg jeans	medium-weight cotton denim in right-hand twill; rigid hand with minimal stretch; ring-spun yarn character	medium indigo blue with cool undertone and subtle stonewashed variation; matte	Classic five-pocket construction with belt loops and waistband visible at the high hip; fly front with metal zipper and top button (hardware not fully visible). Contrast topstitching along waistband and pocket edges; straight-leg block with regular seat. Worn under the jacket with hem and lower leg out of frame.	/app/uploads/temp/1fea3491-b89a-4456-8969-1397edd74a35_outfit_24.jpg	/output/clothing_items/a842ea63-03b4-4f51-b23b-e93416fd1865_preview_20251023_013212.png	2025-10-23 00:47:06.739509	2025-10-23 01:32:23.520703	1
132	9781aa2b-f3e0-4620-8a3a-a582ac24c941	bottoms	mid‑thigh cycling shorts with side zipper detail	compression stretch knit (nylon/elastane), smooth with matte finish	solid black with contrasting white zipper tape	Close‑fit, elasticated waistband concealed under the skirt. Right leg features a vertical exposed zipper detail with white tape and a small silver teardrop pull that hangs near the hem; decorative/vent styling. Clean cover‑stitched hems; shorts extend a few inches below the skirt for deliberate layered exposure.	/app/uploads/temp/daba4300-c3e1-43d3-b75f-da9c92514761_outfit_05.jpg	/output/clothing_items/9781aa2b-f3e0-4620-8a3a-a582ac24c941_preview_20251023_013223.png	2025-10-23 00:47:06.738548	2025-10-23 01:32:31.252487	1
129	362e6e6a-93d1-4946-85bb-3b4ef683348c	neckwear	Plain Long Scarf	fine-gauge wool knit with a softly brushed surface; lightweight, supple drape; matte	deep jet black	Narrow-width scarf wrapped once to create a compact, protective neck bundle. Clean, non-fringed edges. The bulk sits inside the jacket neckline, building a raised collar effect. Ends are fully tucked so no tails are visible, yielding a neat, utilitarian styling.	/app/uploads/temp/868e72c4-75f2-42f4-9d06-d46b8b3c83dc_outfit_12.jpg	/output/clothing_items/362e6e6a-93d1-4946-85bb-3b4ef683348c_preview_20251023_013100.png	2025-10-23 00:47:06.733955	2025-10-23 04:21:26.708001	1
136	a9b6429e-6538-4ef1-a4d1-593896c9457c	tops	long-sleeve mock-neck knit top	fine-gauge cotton-spandex jersey, lightweight with smooth hand and matte surface	deep solid black, matte	Close-fitting base layer with a short mock neck standing approximately 3–4 cm; clean coverstitched neckline and seam finishes. Worn fully under the trench coat, only neckline and small collar area visible; provides sleek, minimal foundation contrasting the textured leather.	/app/uploads/temp/304fa8ba-430e-4af6-a566-8eb4351d8af5_outfit_02.jpg	\N	2025-10-23 00:47:06.742748	2025-10-23 00:49:15.960975	1
141	bc86b9d9-4727-4198-806f-cd6985adb8fc	footwear	split‑toe hoof boots	molded full‑grain leather upper with stiffened toe box and counter; smooth leather lining; rubber outsole; semi‑gloss finish	ink black with a satin sheen	Sculpted front forms a pronounced cloven split toe to resemble hooves. Close‑fitting shaft disappears beneath the jumpsuit hem. Concealed inside‑ankle zipper with black oxidized metal pull; low stacked heel and slightly rounded edges. Cemented construction with clean top‑line and minimal seam count for a sleek, costume‑grade profile; outsole lightly textured for traction.	/app/uploads/temp/17886008-4de4-486c-beaa-f584ab6ef5e9_wool_coat_2_by_0pik_0ort_d9j01y0-414w-2x.png	\N	2025-10-23 00:47:06.748962	2025-10-23 00:49:15.960975	1
142	7e8af54f-369b-47b5-9918-1dcabe354ba9	belts	waist-mounted wallet chain	solid steel curb chain, medium gauge	bright polished silver	Clipped from a front belt loop across the hip; heavy curb links with swivel clasps; drapes diagonally and interacts with the double belts, adding metallic contrast against the black leather.	/app/uploads/temp/c9bb75ce-1437-4d49-b3c1-57c90d18e99a_squall.jpg	\N	2025-10-23 00:47:06.749933	2025-10-23 00:49:15.960975	1
144	30bdaaca-066a-4a92-ab6b-b0fe58c5b76b	headwear	rib-knit beret	wool-blend chunky rib knit; soft hand; matte surface; medium-gauge elasticity	onyx black	Classic beret silhouette with a full, gently slouched crown and a wide, double-layer ribbed headband that grips the head securely. Fully-fashioned shaping lines at the crown; clean bound edge; no visible branding or embellishment.	/app/uploads/temp/868e72c4-75f2-42f4-9d06-d46b8b3c83dc_outfit_12.jpg	/output/clothing_items/30bdaaca-066a-4a92-ab6b-b0fe58c5b76b_preview_20251023_044134.png	2025-10-23 00:47:06.753203	2025-10-23 04:41:43.860185	1
140	ee663ec9-0087-4845-86e4-db5de2505176	handwear	wrist-length leather gloves	fine nappa leather, smooth and pliant with soft matte sheen; lightweight with close-fitting stretch from glove cut rather than elastic	jet black	Classic slim glove pattern reaching just past the wrist; clean, uninterrupted exterior with no visible vents, points, or perforations. Seam construction appears turned with minimal edge bulk; hems are neatly finished and pressed flat. The gloves fit snugly under the jacket sleeves, maintaining a seamless, uniform presentation.	/app/uploads/temp/3670b846-ee55-4e14-b283-d3c74ff03eda_outfit_03.jpg	/output/clothing_items/ee663ec9-0087-4845-86e4-db5de2505176_preview.png	2025-10-23 00:47:06.748049	2025-10-23 01:20:11.400538	1
175	0aab167a-db39-4072-b32f-86ec743c242e	bags	leather shoulder bag (strap visible)	smooth full-grain leather strap with edge painting and tonal topstitching; firm hand	dark chocolate brown	Wide flat strap worn on the right shoulder, descending diagonally. Strap attaches to the unseen bag body with metal loops; hardware appears dark nickel. Strap width approximately 3–4 cm; single-row stitching near both edges. Bag body remains off-frame, no flap or closure details visible.	/app/uploads/temp/f80333a9-8e62-44f2-82f8-e592fbdb4e51_outfit_16.jpg	/output/clothing_items/0aab167a-db39-4072-b32f-86ec743c242e_preview.png	2025-10-23 00:47:06.791034	2025-10-23 01:20:27.592472	1
143	89698a2f-fe8f-4f32-93c0-d3373c0add91	bottoms	skinny-fit stretch denim jeans	cotton-dominant stretch denim with elastane, dense twill weave, medium weight, lightly polished surface	very dark indigo-black wash with matte finish	Close-fitting, tapered leg; classic five-pocket construction (front curved pockets with coin pocket and back patch pockets not visible but implied by standard cut); clean waistband with belt loops; zip fly with metal shank button; tonal black/charcoal topstitching along seams; hem not fully visible but appears clean and narrow; worn under the voluminous puffer with waistband covered by the jacket’s hem, emphasizing contrast between slim leg and oversized outerwear.	/app/uploads/temp/8a2e0569-f3d3-4f10-8736-c42b0ad320f6_ChatGPT Image Mar 28, 2025, 09_09_19 PM.png	/output/clothing_items/89698a2f-fe8f-4f32-93c0-d3373c0add91_preview_20251023_013205.png	2025-10-23 00:47:06.752235	2025-10-23 01:32:13.324168	1
135	3d4dc11e-1d45-4e47-9151-8366a40120f8	outerwear	Black Shearling Moto Jacket	full-grain leather body with dense lamb shearling collar; semi-aniline finish; medium-heavy weight with firm hand and subtle luster	matte jet black body with deep espresso brown collar	Asymmetric off-center metal zipper front (large-gauge nickel teeth) set from right hem to left shoulder; wide notched lapels faced in shearling and secured with nickel snap studs; single snap-flap coin pocket on the left front panel; structured, cropped hem hitting at high waist with 3 mm twin-needle topstitching; set-in long sleeves with plain cuffs; clean edge paint on all leather edges; panelled construction for shaping through torso; worn partially zipped so the lapels sit open, creating a deep V that showcases the neckwear and contrasts the plush collar against the smooth leather body.	/app/uploads/temp/c5cea7ae-e366-447c-9005-3f5e51975261_tae-outfit_heroic_kaysha_20250926121425.png	/output/clothing_items/3d4dc11e-1d45-4e47-9151-8366a40120f8_preview.png	2025-10-23 00:47:06.741778	2025-10-23 04:16:22.244015	1
147	f6002426-1370-4311-baba-a0f460716fa0	tops	close-fit jersey camisole	cotton–spandex jersey, lightweight with smooth hand and moderate stretch; matte	solid black, matte	Minimalist base layer with straight/square neckline bound in self-fabric; body-hugging fit worn beneath the leather coatdress; only the neckline edge is visible within the coat’s V opening, providing dark contrast.	/app/uploads/temp/305a4194-f611-47a3-a609-3720c8456263_red-baggy_mirror-ots_jenny_20250928140341.png	\N	2025-10-23 00:47:06.758147	2025-10-23 00:49:15.960975	1
149	008cda4e-5cb7-4f84-9402-0750ea12a543	footwear	thigh-high heeled boots	polished calfskin leather upper with slight stretch backing; leather insole and lining; stacked leather stiletto heel; leather outsole with rubber forepart	deep black with glossy polish	over-the-knee shaft extending to mid-thigh, slim and leg-hugging; almond-point toe; high stiletto heel approximately 9–10 cm; concealed medial zipper from arch to below knee for entry; clean single back seam and bound topline for a sleek profile; minimal topstitching; lower shafts and feet visible beneath the long coat hem, surfaces slick with moisture and reflecting light.	/app/uploads/temp/e3d895c1-af91-4e9a-a449-3dccebb57093_fur-fox_cyberpunk_jenny_20250928135503.png	\N	2025-10-23 00:47:06.760849	2025-10-23 00:49:15.960975	1
152	0e9cacdf-27be-4564-80f0-b1dba509902d	footwear	knee-high equestrian riding boots	smooth calf leather with polished finish; likely leather lining and leather or rubber outsole	dark chocolate brown with subtle gloss	Straight-cut shafts reaching just below the knee with clean topline; minimal seams and no visible external hardware. Almond-round toe and low stacked heel suitable for riding controls. Shafts fitted closely over the jeans; entry appears via an inner side zipper concealed by clean stitching or pull-on construction. Leather shows gentle crease at the vamp consistent with wear, otherwise well-polished.	/app/uploads/temp/4c18c321-20a9-4e70-8021-c3a53c53bfdb_outfit_07.jpg	\N	2025-10-23 00:47:06.764101	2025-10-23 00:49:15.960975	1
150	4ebeb0f4-cd08-4fe6-841a-c50e49101ca9	outerwear	cropped leather moto jacket with oversized shearling collar	supple full-grain leather body with lightly padded, channel‑quilted leather sleeves; genuine sheepskin shearling collar; smooth woven lining likely satin weight	matte deep black body with warm ivory shearling collar	Boxy, cropped silhouette ending near the natural waist. Extra‑wide shearling shawl collar/lapels drape over shoulders, creating high-pile texture contrast to the matte leather. Set‑in sleeves feature horizontal channel quilting from shoulder to cuff. Front appears to close with a center zip (silver hardware) but is worn open; no pockets visible. Clean edge topstitching throughout; sleeve cuffs plain without zips. Leather panels shaped with seam lines along sides; collar and front edges finished with turn-back facings.	/app/uploads/temp/daba4300-c3e1-43d3-b75f-da9c92514761_outfit_05.jpg	/output/clothing_items/4ebeb0f4-cd08-4fe6-841a-c50e49101ca9_preview.png	2025-10-23 00:47:06.761778	2025-10-23 01:12:24.419619	1
154	6e163e1d-6e84-4bc1-b22d-576567c15d9f	outerwear	two-tone café racer motorcycle jacket	full-grain leather with smooth semi-aniline finish; heavy, structured hand with slight natural sheen	ivory buttercream main panels with jet black sleeves, collar, and trim; sleeve patches in orange, white, and black	waist-length, structured moto silhouette with a narrow stand collar featuring a single-snap throat tab; center-front heavy-gauge silver-tone metal zipper extending to the neck with leather-faced placket; set-in sleeves in contrasting black leather, showing subtle break-in creasing; double-needle topstitching throughout for reinforcement; visible stacked sleeve insignia—an embroidered rectangular Harley-Davidson shield patch and a cross-form badge—both merrowed-edge and machine-topstitched onto the upper arm; clean hem finish typical of leather construction with turned edges; overall boxy, slightly oversized fit across the shoulders; jacket worn fully zipped, sleeves folded across the front emphasizing the stiff, protective build.	/app/uploads/temp/39735250-ffd3-4043-aa47-eaf22af04e3f_outfit_28.jpg	/output/clothing_items/6e163e1d-6e84-4bc1-b22d-576567c15d9f_preview.png	2025-10-23 00:47:06.766414	2025-10-23 01:14:18.910818	1
148	5e3c9a1c-cb2c-4f16-8b33-09f23d68eb2f	belts	self belt for leather coat	matching cowhide leather, firm hand with smooth surface	matching ink black, matte	Approx. 35–40 mm width; rectangular single-prong frame buckle in dark gunmetal; single leather keeper; edges painted and burnished; threaded through five external belt loops on the coat and cinched to emphasize the waist over the closed zipper.	/app/uploads/temp/77a6d071-59b3-4f43-9fd5-9d61586948d2_outfit_10.jpg	/output/clothing_items/5e3c9a1c-cb2c-4f16-8b33-09f23d68eb2f_preview_20251023_013242.png	2025-10-23 00:47:06.759514	2025-10-23 01:32:55.065816	1
153	159bc4e4-a082-4a89-9a1e-7aafa0b92de2	handwear	classic leather dress gloves	smooth lambskin leather; light polish; soft, pliable weight	inky black with subtle sheen	Wrist-length, close-fitted glove with fine edge topstitching and a short palm-side vent for entry. Minimal external seaming for a sleek profile; fingers shaped with fine grain alignment to reduce wrinkling. Likely thin lining for comfort.	/app/uploads/temp/868e72c4-75f2-42f4-9d06-d46b8b3c83dc_outfit_12.jpg	/output/clothing_items/159bc4e4-a082-4a89-9a1e-7aafa0b92de2_preview_20251023_012501.png	2025-10-23 00:47:06.765055	2025-10-23 01:25:10.817502	1
159	0e808125-1171-45cf-936e-a7e1a1b48a52	tops	sleeveless scoop-neck stretch tank	72% polyamide / 28% elastane circular-knit jersey, medium-weight (approx. 250–280 gsm) with sateen sheen and smooth hand; four-way stretch; self-fabric binding at edges	inky carbon black with cool undertone, satin luster	Classic tank cut with wide shoulder straps and deep scoop neckline; neckline and armholes finished with 12–15 mm self-fabric binding, coverstitched; side seams slightly shaped through the waist; hem extends over the high-rise waistband of the bottoms and is finished with a 20 mm turned-and-coverstitched hem using a twin-needle; no closures; interior seams overlocked; negative-ease, body-con compression fit that smooths and molds to the torso; clean, unadorned surface free of logos or topstitching.	/app/uploads/temp/7dc3c673-4815-4c76-9d9c-c62162e33971_shapes.png	\N	2025-10-23 00:47:06.772377	2025-10-23 00:49:15.960975	1
160	5358b882-7799-47ef-ba54-137d36bc8531	tops	fine-gauge crewneck sweater	merino-wool jersey knit; lightweight, smooth hand; matte	true black	Classic slim-to-regular fit crewneck with narrow ribbed neckline and clean overlocked interior seams (not visible). Mostly obscured by the leather jacket; a small portion at the neck is covered by the scarf. Sleeves and hem are concealed by outerwear, functioning as a tonal base layer to the all-black accessories.	/app/uploads/temp/868e72c4-75f2-42f4-9d06-d46b8b3c83dc_outfit_12.jpg	\N	2025-10-23 00:47:06.773779	2025-10-23 00:49:15.960975	1
163	da8eb2be-e900-4a24-bcab-b3ec6714aa30	hosiery	opaque tights	microfiber nylon/elastane circular knit, 80–100 denier; soft hand; matte	solid deep black, uniform matte	Even, non-sheer coverage from waist to toe; fine, flat knit with minimal sheen to absorb light; no reinforced areas visible beneath footwear; provides a continuous dark leg line that visually grounds the brighter skirt.	/app/uploads/temp/c5cea7ae-e366-447c-9005-3f5e51975261_tae-outfit_heroic_kaysha_20250926121425.png	\N	2025-10-23 00:47:06.777257	2025-10-23 00:49:15.960975	1
157	3917aee8-0f13-4381-9e93-b24a2595936f	handwear	full-finger leather riding glove (right hand visible)	soft-grain leather with padded reinforcement at knuckles and palm; matte finish; light internal lining	solid black, matte	Ergonomically pre-curved fingers with darting for articulation; short cuff length ending just past the wrist, finished with a clean turned edge; tonal topstitching throughout; protective knuckle panel and palm padding for grip control; glove interfaces seamlessly with the jacket sleeve, with the cuff tucked beneath the zipped cuff opening to minimize bulk.	/app/uploads/temp/c55d3721-1ce1-456f-aba4-e9146d269e72_selene__underworld___6_by_stormborncat_det4s36-pre.jpg	/output/clothing_items/3917aee8-0f13-4381-9e93-b24a2595936f_preview.png	2025-10-23 00:47:06.770204	2025-10-23 01:07:49.075041	1
165	45e2d81b-deca-4450-a7d1-dbd4fd7aae72	handwear	fitted leather gloves	soft-grain lambskin leather, unembossed, lightly glazed; thin lining likely in silk or acetate for ease	inky black, semi-gloss	Close-fitting, wrist-length gloves with three-point top stitching and articulated finger seams; short vent at the wrist for entry; clean turned edges; the right glove visible gripping the necklace showcases fine grain and supple structure, complementing the jacket’s leather.	/app/uploads/temp/c9bb75ce-1437-4d49-b3c1-57c90d18e99a_squall.jpg	/output/clothing_items/45e2d81b-deca-4450-a7d1-dbd4fd7aae72_preview.png	2025-10-23 00:47:06.780659	2025-10-23 01:20:08.45167	1
158	30c81d92-6b0a-4b3f-af6c-99479d43db93	bags	small suede baguette shoulder bag	genuine calf suede with short nap; structured but soft hand; metal hardware	dusty mauve-rose with warm undertone; matte suede with slight shading	Compact rectangular baguette silhouette worn high under the shoulder. Single short shoulder strap in matching suede adorned with a line of small dome studs in warm antiqued gold; strap attached via stitched side tabs. Top zip closure with metal teeth and slider; softly structured body with minimal gusset depth so it tucks neatly against the coat.	/app/uploads/temp/5ede93fe-4cd3-4977-90f7-37c5a534c446_outfit_30.jpg	/output/clothing_items/30c81d92-6b0a-4b3f-af6c-99479d43db93_preview.png	2025-10-23 00:47:06.771123	2025-10-23 01:20:28.143396	1
161	31b74cbd-2545-48f4-9515-ac6acf1a02a9	bottoms	wide-leg full-length trousers	heavy suiting crepe or soft twill, wool-blend; fluid drape with weight; matte surface	deep solid black	Relaxed, long inseam creating slight puddling at the shoe line. Continuous wide leg from hip to hem with no taper; un-cuffed plain hem. Waistband and closure not visible beneath the jacket. No visible pressing crease; appearance is softly draped. Pockets and interior finishing not exposed.	/app/uploads/temp/f80333a9-8e62-44f2-82f8-e592fbdb4e51_outfit_16.jpg	/output/clothing_items/31b74cbd-2545-48f4-9515-ac6acf1a02a9_preview_20251023_013203.png	2025-10-23 00:47:06.774752	2025-10-23 01:32:12.494014	1
164	b285b00b-618e-4cd2-8628-856ec65f1c1a	tops	crewneck fleece sweatshirt (underlayer)	cotton-blend fleece-back jersey with rib-knit trim; medium weight, soft hand, brushed interior	deep navy blue, matte	Relaxed fit; standard set-in sleeves. Coverstitched seam construction at cuff attachment; no graphics or surface embellishment visible..	/app/uploads/temp/3425368e-7e3f-4d00-9c57-c5641553aaea_outfit_31.jpg	/output/clothing_items/b285b00b-618e-4cd2-8628-856ec65f1c1a_preview_20251023_042051.png	2025-10-23 00:47:06.778629	2025-10-23 04:21:00.324258	1
167	d10deaee-674e-4b41-8d1f-6333f426e6fd	footwear	ankle leather boots with lug sole	smooth corrected-grain leather upper; molded rubber outsole with aggressive lugs	ink black upper with black outsole	Round toe, low block heel (approx. 30–35 mm) and thick lugged rubber sole for traction. Stitched welt visible at the junction of upper and sole. Ankle-high shaft disappears under the flared trench hem; trousers meet the boot top without bunching. Finish is clean and unscuffed, giving a utilitarian yet refined appearance.	/app/uploads/temp/c8e969c9-f398-4dc8-b375-a467eacc0650_trenchcoat-extreme_street-pose_izzy_20250923125855.png	\N	2025-10-23 00:47:06.782568	2025-10-23 00:49:15.960975	1
170	b77b5484-6925-4734-a099-75ae9b50ff5f	tops	long-sleeve fine-gauge knit top	merino wool jersey, lightweight with soft hand and slight natural sheen	charcoal black, matte	Close-fitting base layer worn fully under the leather coat; high crew/short mock neckline peeks minimally at the throat beneath the scarf; no visible placket or embellishment; hem and cuffs not visible due to outerwear coverage.	/app/uploads/temp/77a6d071-59b3-4f43-9fd5-9d61586948d2_outfit_10.jpg	\N	2025-10-23 00:47:06.785954	2025-10-23 00:49:15.960975	1
171	90143002-520a-4947-a80c-4db25469f694	tops	sheer mesh long-sleeve layering top	stretch nylon-spandex mesh, fine gauge, lightweight, semi-transparent with soft elastic recovery	warm beige ground with dark brown and black abstract/organic print, matte finish	Slim, body-skimming fit; narrow overlocked hems at sleeve openings; likely crew neckline with elastic binding (neckline concealed by outerwear); sleeves extend past wrist and peek from the leather cuff, providing a translucent printed edge contrast to the jacket.	/app/uploads/temp/a33110d7-8b9e-4873-94db-94d679671a32_outfit_32.jpg	\N	2025-10-23 00:47:06.786922	2025-10-23 00:49:15.960975	1
169	092e1f40-38d3-42bd-895a-c31560eefebd	outerwear	double-breasted leather trench coat	smooth genuine leather (nappa-like), semi-gloss finish, midweight with supple hand; likely backed with lightweight woven lining for comfort and structure	jet black with a polished, satin-like sheen	Thigh-length trench silhouette with broad notched lapels; double-breasted front with two parallel rows of round, leather-covered buttons (approximately 8–10 total) placed high to low; clean front edges with close edge-stitching; set-in sleeves with plain cuff (no straps); vertical hip pockets with narrow welts, positioned slightly forward for hand entry; panel construction with subtle topstitching that defines the placket and front seams; straight hem; worn closed and cinched externally by a separate belt to emphasize the waist; leather surface appears well-pressed with natural creasing at flex points, presenting a sleek, structured drape.	/app/uploads/temp/b5d28f51-2a5d-425d-b0b2-9e121b13dfbe_outfit_01.jpg	/output/clothing_items/092e1f40-38d3-42bd-895a-c31560eefebd_preview.png	2025-10-23 00:47:06.784857	2025-10-23 01:13:23.503215	1
183	bf2180ca-cdc8-4eac-864c-e8b798c6f066	tops	structured leather bustier corset	vegetable-tanned leather with molded panels and embossed surface motif; stiff hand; matte to low-satin luster; internal stability from woven coutil-like lining and boning channels	deep black with subtle tonal embossing	Corset-style bustier with a gently scooped sweetheart neckline and elongated waist that tapers to cinch the midsection; multi-panel construction with vertical seaming that functions as boning channels for strong shaping; center-front features a raised, embossed graphic motif adding armor-like texture; clean, uninterrupted front without visible closures in frame; edges are skived and turned with fine topstitching; worn under the moto jacket, its neckline and front panels are visible and align with the jacket’s opening to create a layered, tactical aesthetic.	/app/uploads/temp/c55d3721-1ce1-456f-aba4-e9146d269e72_selene__underworld___6_by_stormborncat_det4s36-pre.jpg	/output/clothing_items/bf2180ca-cdc8-4eac-864c-e8b798c6f066_preview.png	2025-10-23 00:47:06.802983	2025-10-23 00:52:25.158469	1
182	43eb6fcd-a2b7-43d4-9b3e-04a653d6953b	outerwear	long double-breasted leather trench coat with wide notch lapels	full-grain leather, smooth face with semi-matte luster; medium-heavy weight with structured drape; edge topstitching	jet black with cool undertone, satin-sheen finish	Calf-length silhouette cut with a gently flared hem for sweep. Six-button double-breasted front; matte black 4-hole buttons, mid-torso fastened leaving lower skirt open for movement. Broad notch lapels with 5 mm edge topstitching; crisp roll. Set-in sleeves with plain, unstrapped cuffs; sleeve hems finished with turned edges and single-needle topstitch. Paneled body with vertical seaming for shaping; clean front without visible pockets. Front overlap covers a button-up shirt beneath; leather skirt parts at center to reveal the inner layers and boots. Overall fit is tailored at the shoulders and chest, relaxing into an A-line sweep; leather retains a firm hand and keeps sharp edges.	/app/uploads/temp/c8e969c9-f398-4dc8-b375-a467eacc0650_trenchcoat-extreme_street-pose_izzy_20250923125855.png	/output/clothing_items/43eb6fcd-a2b7-43d4-9b3e-04a653d6953b_preview.png	2025-10-23 00:47:06.801252	2025-10-23 00:53:00.455845	1
122	be88cc3f-050d-4269-ae68-325c4e6f6111	outerwear	oversized leather flight jacket with zip front	full-grain cowhide leather, semi-aniline finish; heavyweight with smooth grain and light satin luster	espresso brown with near-black cast; semi-gloss patina on stress points	Hip-length, relaxed/boxy silhouette with generous ease through chest and sleeves. Center-front metal zipper (antique-brass tone coil and pull) worn one-third closed, revealing the black scarf. Short stand collar formed by the zipped facing; edges finished with turned leather and topstitching. Set-in sleeves with articulated seaming and double-needle topstitch at all structural seams (shoulder, armscye, side panels). Cuffs feature narrow tab extensions with single metal snap adjusters; no rib knit. Front hand pockets are slanted vertical welts with zip closures trimmed in leather; pocket bags hidden. Hem is straight with clean turned edge and perimeter topstitching. Leather displays natural creasing at elbows and placket indicating wear-in; surfaces uniformly dyed with subtle tonal variation. Layering interaction: scarf fills the collar area, gloves tuck cleanly into sleeve openings, and the jacket’s volume reads oversized relative to inner layers.	/app/uploads/temp/868e72c4-75f2-42f4-9d06-d46b8b3c83dc_outfit_12.jpg	/output/clothing_items/be88cc3f-050d-4269-ae68-325c4e6f6111_preview_20251023_012634.png	2025-10-23 00:47:06.725995	2025-10-23 01:26:42.815242	1
124	33d8c16f-379f-4a17-b3e8-82a9671925a6	outerwear	Medium Leather Trenchcoat with Asymmetric Zip	midweight cowhide leather, smooth grain with semi-matte aniline finish; fully lined in satin acetate	ink black with a faint olive undertone, low sheen	Single-breasted construction with a center-front metal zipper (gunmetal finish) running from hem to throat; convertible shirt-style collar with pointed tips and edge topstitching; lightly structured shoulders with buttoned leather epaulettes; set-in sleeves with clean, unstrapped cuffs; front and back princess panels and multi-piece body seams for shaping, all seams double-needle topstitched; two slanted hip pockets with narrow welt entries closed by metal coil zippers; straight hem at upper thigh; belt loops at natural waist; interior facings and fused interfacing at fronts and collar for stability; leather shows subtle creasing/patina consistent with wear.	/app/uploads/temp/77a6d071-59b3-4f43-9fd5-9d61586948d2_outfit_10.jpg	/output/clothing_items/33d8c16f-379f-4a17-b3e8-82a9671925a6_preview_20251023_012632.png	2025-10-23 00:47:06.728736	2025-10-23 03:33:45.35074	1
85	45ffdb1e-f95e-4bf2-a69f-f49b33a8c436	outerwear	Brown Leather Blazer	supple calfskin leather with a semi-matte finish; medium weight with lightly structured hand; fully lined in smooth viscose satin; light fusible interfacing at fronts and lapels	rich cocoa brown with warm undertone, subtle natural leather luster	Notch lapels with crisp edge-stitching (~3 mm). Two-button front stance with dark horn/resin buttons; top button fastened. Hip-level jetted pockets with flaps; pocket mouths edge-stitched for stability. Set-in sleeves with lightly padded shoulders; sleeve hems finished with three kissing cuff buttons (non-functional). Front shaping via vertical darts from hem to bust and side seams; back constructed with center seam and a single back vent for mobility. Hem hits at low hip, semi-relaxed tailored silhouette. Leather surface is clean and evenly grained; panels joined with tight topstitched seams. Worn over a black blouse with the blazer partially closed.	/app/uploads/temp/aa48a22c-c3a1-4034-b30b-076f617f3ca8_outfit_08.jpg	/output/clothing_items/45ffdb1e-f95e-4bf2-a69f-f49b33a8c436_preview_20251023_012625.png	2025-10-23 00:47:06.681555	2025-10-23 04:19:45.664175	1
195	34797385-20ee-4602-b403-5e80dcdb8ffb	handwear	opera-length leather gloves	thin nappa leather, lightweight with high elasticity and second-skin hand; smooth, fine grain and soft sheen	matching jet black, semi-matte	Extended length reaching above the elbow with clean, minimal profile. Traditional glove construction using separate fourchettes between fingers and a thumb gusset for mobility; narrow side seams are finely topstitched. Opening edge is clean-turned without vents, closures, or decorative hardware; glove relies on negative ease for secure fit. Seams are pressed flat for a sleek, couture finish.	/app/uploads/temp/47bbd997-7d8a-49c6-9693-2f5ae6555959_dress-gloves_portrait-intimate_tanya_20251007_234140.png	\N	2025-10-23 04:38:49.215983	2025-10-23 04:38:49.215984	\N
\.


--
-- Data for Name: compositions; Type: TABLE DATA; Schema: public; Owner: lifeos
--

COPY public.compositions (id, composition_id, name, subject, presets, created_at, updated_at, user_id) FROM stdin;
\.


--
-- Data for Name: favorites; Type: TABLE DATA; Schema: public; Owner: lifeos
--

COPY public.favorites (id, user_id, category, preset_id, created_at) FROM stdin;
\.


--
-- Data for Name: image_entity_relationships; Type: TABLE DATA; Schema: public; Owner: lifeos
--

COPY public.image_entity_relationships (id, image_id, entity_type, entity_id, role, created_at) FROM stdin;
1	87b90798-8b58-4380-a423-e7635a2865a6	clothing_item	37091233-b4c7-449b-9c26-46c22fb24d3d	outerwear	2025-10-23 02:41:58.517197
2	87b90798-8b58-4380-a423-e7635a2865a6	preset	8616cd79-2818-4d79-808e-6765e9ace69f	visual_style	2025-10-23 02:41:58.517198
3	d4041ef8-b33b-4166-9707-3411adbcade8	clothing_item	37091233-b4c7-449b-9c26-46c22fb24d3d	outerwear	2025-10-23 02:43:07.304878
4	d4041ef8-b33b-4166-9707-3411adbcade8	clothing_item	91dc5582-712f-4fe7-9478-badeb24a6ca4	outerwear	2025-10-23 02:43:07.304879
5	d4041ef8-b33b-4166-9707-3411adbcade8	preset	8616cd79-2818-4d79-808e-6765e9ace69f	visual_style	2025-10-23 02:43:07.304879
6	3e7cd6d9-ec36-4af4-bf46-e9486ae6e7c6	clothing_item	37091233-b4c7-449b-9c26-46c22fb24d3d	outerwear	2025-10-23 02:43:23.552354
7	3e7cd6d9-ec36-4af4-bf46-e9486ae6e7c6	clothing_item	91dc5582-712f-4fe7-9478-badeb24a6ca4	outerwear	2025-10-23 02:43:23.552355
8	3e7cd6d9-ec36-4af4-bf46-e9486ae6e7c6	preset	e0602b0b-5c24-4be6-941c-e1c671bcc718	visual_style	2025-10-23 02:43:23.552356
9	32b97c66-f197-4b80-b775-a64665ae9e6a	clothing_item	37091233-b4c7-449b-9c26-46c22fb24d3d	outerwear	2025-10-23 02:43:48.481678
10	32b97c66-f197-4b80-b775-a64665ae9e6a	preset	e0602b0b-5c24-4be6-941c-e1c671bcc718	visual_style	2025-10-23 02:43:48.481679
11	2153290f-cd58-4e09-ae72-97397e9ed681	clothing_item	37091233-b4c7-449b-9c26-46c22fb24d3d	outerwear	2025-10-23 02:44:06.75378
12	2153290f-cd58-4e09-ae72-97397e9ed681	preset	e0602b0b-5c24-4be6-941c-e1c671bcc718	visual_style	2025-10-23 02:44:06.753781
13	2153290f-cd58-4e09-ae72-97397e9ed681	preset	60abaaba-808c-4283-90c0-5520c61a6699	expression	2025-10-23 02:44:06.753782
14	c5fa69fb-199c-45d0-bc68-3818ac15805a	clothing_item	37091233-b4c7-449b-9c26-46c22fb24d3d	outerwear	2025-10-23 02:44:18.848558
15	c5fa69fb-199c-45d0-bc68-3818ac15805a	preset	e0602b0b-5c24-4be6-941c-e1c671bcc718	visual_style	2025-10-23 02:44:18.848559
16	c5fa69fb-199c-45d0-bc68-3818ac15805a	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 02:44:18.848559
17	93480946-202e-411b-b828-e6cdb4e192b3	clothing_item	37091233-b4c7-449b-9c26-46c22fb24d3d	outerwear	2025-10-23 02:44:39.755517
18	93480946-202e-411b-b828-e6cdb4e192b3	preset	e0602b0b-5c24-4be6-941c-e1c671bcc718	visual_style	2025-10-23 02:44:39.755518
19	93480946-202e-411b-b828-e6cdb4e192b3	preset	f9708937-d36a-4d99-a7e3-f54fd7377957	expression	2025-10-23 02:44:39.755518
20	95172adf-37b3-46cb-9a93-8254f91bd872	clothing_item	b9419ff5-b213-4d8c-8781-816280ae61ea	tops	2025-10-23 02:45:51.467148
21	95172adf-37b3-46cb-9a93-8254f91bd872	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:45:51.467149
22	95172adf-37b3-46cb-9a93-8254f91bd872	preset	e0602b0b-5c24-4be6-941c-e1c671bcc718	visual_style	2025-10-23 02:45:51.467149
23	95172adf-37b3-46cb-9a93-8254f91bd872	preset	f9708937-d36a-4d99-a7e3-f54fd7377957	expression	2025-10-23 02:45:51.467149
24	b591eea0-3677-4e5f-b7ac-97f44a240c59	clothing_item	3264827b-cb5c-4162-8321-86a88798dae3	outerwear	2025-10-23 02:46:46.005732
25	b591eea0-3677-4e5f-b7ac-97f44a240c59	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:46:46.005733
26	b591eea0-3677-4e5f-b7ac-97f44a240c59	preset	e0602b0b-5c24-4be6-941c-e1c671bcc718	visual_style	2025-10-23 02:46:46.005733
27	b591eea0-3677-4e5f-b7ac-97f44a240c59	preset	f9708937-d36a-4d99-a7e3-f54fd7377957	expression	2025-10-23 02:46:46.005733
28	259a988e-200b-4ba4-a280-1a62c6526169	clothing_item	c9fda71b-cc41-4038-aae6-f3485002a4e4	outerwear	2025-10-23 02:47:05.807845
29	259a988e-200b-4ba4-a280-1a62c6526169	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:47:05.807846
30	259a988e-200b-4ba4-a280-1a62c6526169	preset	e0602b0b-5c24-4be6-941c-e1c671bcc718	visual_style	2025-10-23 02:47:05.807846
31	259a988e-200b-4ba4-a280-1a62c6526169	preset	f9708937-d36a-4d99-a7e3-f54fd7377957	expression	2025-10-23 02:47:05.807846
32	e3cb82b8-4a9b-4e79-b3b5-728d8e8445da	clothing_item	c9fda71b-cc41-4038-aae6-f3485002a4e4	outerwear	2025-10-23 02:48:08.494067
33	e3cb82b8-4a9b-4e79-b3b5-728d8e8445da	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:48:08.494068
34	e3cb82b8-4a9b-4e79-b3b5-728d8e8445da	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:48:08.494069
35	e3cb82b8-4a9b-4e79-b3b5-728d8e8445da	preset	e0602b0b-5c24-4be6-941c-e1c671bcc718	visual_style	2025-10-23 02:48:08.494069
36	e3cb82b8-4a9b-4e79-b3b5-728d8e8445da	preset	f9708937-d36a-4d99-a7e3-f54fd7377957	expression	2025-10-23 02:48:08.494069
37	631b2a4c-24df-4b2f-bca8-a8e5e277f816	clothing_item	c9fda71b-cc41-4038-aae6-f3485002a4e4	outerwear	2025-10-23 02:48:27.822248
38	631b2a4c-24df-4b2f-bca8-a8e5e277f816	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:48:27.822249
39	631b2a4c-24df-4b2f-bca8-a8e5e277f816	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:48:27.822249
40	631b2a4c-24df-4b2f-bca8-a8e5e277f816	preset	76c9f438-1078-4cf5-9c5f-ba2587416d7c	visual_style	2025-10-23 02:48:27.822249
41	631b2a4c-24df-4b2f-bca8-a8e5e277f816	preset	f9708937-d36a-4d99-a7e3-f54fd7377957	expression	2025-10-23 02:48:27.822249
42	a93d4bbd-59bc-4b11-99fd-6172fec308c8	clothing_item	c9fda71b-cc41-4038-aae6-f3485002a4e4	outerwear	2025-10-23 02:48:49.912014
43	a93d4bbd-59bc-4b11-99fd-6172fec308c8	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:48:49.912015
44	a93d4bbd-59bc-4b11-99fd-6172fec308c8	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:48:49.912016
45	a93d4bbd-59bc-4b11-99fd-6172fec308c8	preset	05c91f91-f582-470f-a007-69b0db2f16a3	visual_style	2025-10-23 02:48:49.912016
46	a93d4bbd-59bc-4b11-99fd-6172fec308c8	preset	f9708937-d36a-4d99-a7e3-f54fd7377957	expression	2025-10-23 02:48:49.912016
47	261d09a9-7b75-4fe2-b324-634cba4db003	clothing_item	c9fda71b-cc41-4038-aae6-f3485002a4e4	outerwear	2025-10-23 02:49:06.194486
48	261d09a9-7b75-4fe2-b324-634cba4db003	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:49:06.194487
49	261d09a9-7b75-4fe2-b324-634cba4db003	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:49:06.194487
50	261d09a9-7b75-4fe2-b324-634cba4db003	preset	3018a4b3-4c5a-467f-af71-2aa5498b063a	visual_style	2025-10-23 02:49:06.194487
51	261d09a9-7b75-4fe2-b324-634cba4db003	preset	f9708937-d36a-4d99-a7e3-f54fd7377957	expression	2025-10-23 02:49:06.194488
52	31d23e9b-fecc-415f-bfc6-9acec311c40d	clothing_item	c9fda71b-cc41-4038-aae6-f3485002a4e4	outerwear	2025-10-23 02:49:29.49803
53	31d23e9b-fecc-415f-bfc6-9acec311c40d	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:49:29.498032
54	31d23e9b-fecc-415f-bfc6-9acec311c40d	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:49:29.498032
55	31d23e9b-fecc-415f-bfc6-9acec311c40d	preset	3018a4b3-4c5a-467f-af71-2aa5498b063a	visual_style	2025-10-23 02:49:29.498032
56	6c2a6e18-5797-40b6-8d3c-19f1f4138874	clothing_item	c9fda71b-cc41-4038-aae6-f3485002a4e4	outerwear	2025-10-23 02:49:46.560079
57	6c2a6e18-5797-40b6-8d3c-19f1f4138874	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:49:46.56008
58	6c2a6e18-5797-40b6-8d3c-19f1f4138874	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:49:46.56008
59	6c2a6e18-5797-40b6-8d3c-19f1f4138874	preset	9730992c-5156-436e-af0a-f12d0c23e91a	visual_style	2025-10-23 02:49:46.56008
60	3e7900a6-12b1-45d2-a89e-30b5ed7771cd	clothing_item	c9fda71b-cc41-4038-aae6-f3485002a4e4	outerwear	2025-10-23 02:50:13.15016
61	3e7900a6-12b1-45d2-a89e-30b5ed7771cd	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:50:13.15016
62	3e7900a6-12b1-45d2-a89e-30b5ed7771cd	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:50:13.150161
63	3e7900a6-12b1-45d2-a89e-30b5ed7771cd	preset	b0235b3f-5df8-4475-8eeb-b55d045c2f41	visual_style	2025-10-23 02:50:13.150161
64	1c4f020c-0585-4dcc-85fe-6b3dcb40d040	clothing_item	c9fda71b-cc41-4038-aae6-f3485002a4e4	outerwear	2025-10-23 02:50:36.786292
65	1c4f020c-0585-4dcc-85fe-6b3dcb40d040	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:50:36.786293
66	1c4f020c-0585-4dcc-85fe-6b3dcb40d040	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:50:36.786293
67	1c4f020c-0585-4dcc-85fe-6b3dcb40d040	preset	b972d257-f908-4670-98fa-3c1301f0d8da	visual_style	2025-10-23 02:50:36.786294
68	778bc926-c610-4671-8bd9-a4d1710a01d2	clothing_item	c9fda71b-cc41-4038-aae6-f3485002a4e4	outerwear	2025-10-23 02:50:59.689713
69	778bc926-c610-4671-8bd9-a4d1710a01d2	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:50:59.689713
70	778bc926-c610-4671-8bd9-a4d1710a01d2	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:50:59.689714
71	778bc926-c610-4671-8bd9-a4d1710a01d2	preset	3cf8cca9-e296-4708-89e3-f41fcf412563	visual_style	2025-10-23 02:50:59.689714
72	d300ff17-2b80-4344-99ee-0f65f2c85d39	clothing_item	c9fda71b-cc41-4038-aae6-f3485002a4e4	outerwear	2025-10-23 02:51:32.018308
73	d300ff17-2b80-4344-99ee-0f65f2c85d39	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:51:32.018309
74	d300ff17-2b80-4344-99ee-0f65f2c85d39	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:51:32.018309
75	d300ff17-2b80-4344-99ee-0f65f2c85d39	preset	3cf8cca9-e296-4708-89e3-f41fcf412563	visual_style	2025-10-23 02:51:32.018309
76	d300ff17-2b80-4344-99ee-0f65f2c85d39	preset	133dd66a-8ce9-411c-a935-8881f1ff12ed	hair_style	2025-10-23 02:51:32.018309
77	501102fd-a10b-41ff-82f6-9746ef1d0708	clothing_item	c9fda71b-cc41-4038-aae6-f3485002a4e4	outerwear	2025-10-23 02:51:57.121755
78	501102fd-a10b-41ff-82f6-9746ef1d0708	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:51:57.121756
79	501102fd-a10b-41ff-82f6-9746ef1d0708	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:51:57.121756
80	501102fd-a10b-41ff-82f6-9746ef1d0708	preset	3cf8cca9-e296-4708-89e3-f41fcf412563	visual_style	2025-10-23 02:51:57.121756
81	501102fd-a10b-41ff-82f6-9746ef1d0708	preset	133dd66a-8ce9-411c-a935-8881f1ff12ed	hair_style	2025-10-23 02:51:57.121757
82	501102fd-a10b-41ff-82f6-9746ef1d0708	preset	a133557e-11fe-413f-b84b-f6393651c9d6	hair_color	2025-10-23 02:51:57.121757
83	0017e333-bba4-40ca-b1dd-f0e03c581a2b	clothing_item	c9fda71b-cc41-4038-aae6-f3485002a4e4	outerwear	2025-10-23 02:52:18.576355
84	0017e333-bba4-40ca-b1dd-f0e03c581a2b	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:52:18.576356
85	0017e333-bba4-40ca-b1dd-f0e03c581a2b	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:52:18.576357
86	0017e333-bba4-40ca-b1dd-f0e03c581a2b	preset	3cf8cca9-e296-4708-89e3-f41fcf412563	visual_style	2025-10-23 02:52:18.576357
87	0017e333-bba4-40ca-b1dd-f0e03c581a2b	preset	a133557e-11fe-413f-b84b-f6393651c9d6	hair_color	2025-10-23 02:52:18.576357
88	8f99b4bc-8a7f-4467-9986-c7419f866e33	clothing_item	c9fda71b-cc41-4038-aae6-f3485002a4e4	outerwear	2025-10-23 02:52:36.036353
89	8f99b4bc-8a7f-4467-9986-c7419f866e33	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:52:36.036354
90	8f99b4bc-8a7f-4467-9986-c7419f866e33	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:52:36.036355
91	8f99b4bc-8a7f-4467-9986-c7419f866e33	preset	3cf8cca9-e296-4708-89e3-f41fcf412563	visual_style	2025-10-23 02:52:36.036355
92	8f99b4bc-8a7f-4467-9986-c7419f866e33	preset	a133557e-11fe-413f-b84b-f6393651c9d6	hair_color	2025-10-23 02:52:36.036355
93	8f99b4bc-8a7f-4467-9986-c7419f866e33	preset	96f748cb-7000-4511-8d74-d2ca44b3976b	accessories	2025-10-23 02:52:36.036355
94	10c14ad3-f199-49af-8a4b-7f60debad404	clothing_item	df828cb5-baa6-4b8c-ba7f-9ff5b47517c5	outerwear	2025-10-23 02:53:37.210914
95	10c14ad3-f199-49af-8a4b-7f60debad404	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:53:37.210915
96	10c14ad3-f199-49af-8a4b-7f60debad404	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:53:37.210915
97	10c14ad3-f199-49af-8a4b-7f60debad404	preset	3cf8cca9-e296-4708-89e3-f41fcf412563	visual_style	2025-10-23 02:53:37.210915
98	d08c5a19-7e11-4e9d-81b3-751a46ba6f5c	clothing_item	6e163e1d-6e84-4bc1-b22d-576567c15d9f	outerwear	2025-10-23 02:54:03.254912
99	d08c5a19-7e11-4e9d-81b3-751a46ba6f5c	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:54:03.254913
100	d08c5a19-7e11-4e9d-81b3-751a46ba6f5c	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:54:03.254913
101	d08c5a19-7e11-4e9d-81b3-751a46ba6f5c	preset	3cf8cca9-e296-4708-89e3-f41fcf412563	visual_style	2025-10-23 02:54:03.254913
102	2fbe2618-2310-419c-a89c-f74591b73d1a	clothing_item	20534242-ef32-4fc7-a7fa-f72f3d51bd87	outerwear	2025-10-23 02:54:38.710891
103	2fbe2618-2310-419c-a89c-f74591b73d1a	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:54:38.710892
104	2fbe2618-2310-419c-a89c-f74591b73d1a	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:54:38.710892
105	2fbe2618-2310-419c-a89c-f74591b73d1a	preset	e6082bfc-53af-478d-bdf3-afd2a4adfe7e	visual_style	2025-10-23 02:54:38.710892
106	0ea18371-df0a-4757-9711-77877bb3b795	clothing_item	30bdaaca-066a-4a92-ab6b-b0fe58c5b76b	headwear	2025-10-23 02:55:08.669676
107	0ea18371-df0a-4757-9711-77877bb3b795	clothing_item	20534242-ef32-4fc7-a7fa-f72f3d51bd87	outerwear	2025-10-23 02:55:08.669677
108	0ea18371-df0a-4757-9711-77877bb3b795	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:55:08.669677
109	0ea18371-df0a-4757-9711-77877bb3b795	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:55:08.669678
110	0ea18371-df0a-4757-9711-77877bb3b795	preset	e6082bfc-53af-478d-bdf3-afd2a4adfe7e	visual_style	2025-10-23 02:55:08.669678
111	ef002301-5126-41b3-811e-1bf22d0f3750	clothing_item	ec2b6dfd-9872-46bf-8efe-10c8d6374ead	headwear	2025-10-23 02:55:27.336767
112	ef002301-5126-41b3-811e-1bf22d0f3750	clothing_item	20534242-ef32-4fc7-a7fa-f72f3d51bd87	outerwear	2025-10-23 02:55:27.336768
113	ef002301-5126-41b3-811e-1bf22d0f3750	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:55:27.336768
114	ef002301-5126-41b3-811e-1bf22d0f3750	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:55:27.336768
115	ef002301-5126-41b3-811e-1bf22d0f3750	preset	e6082bfc-53af-478d-bdf3-afd2a4adfe7e	visual_style	2025-10-23 02:55:27.336769
116	2b398cbb-d2b3-412c-8fe2-00f926c165da	clothing_item	19f5601c-25bc-46f3-8d78-aca07513ced8	headwear	2025-10-23 02:56:52.258677
117	2b398cbb-d2b3-412c-8fe2-00f926c165da	clothing_item	20534242-ef32-4fc7-a7fa-f72f3d51bd87	outerwear	2025-10-23 02:56:52.258678
118	2b398cbb-d2b3-412c-8fe2-00f926c165da	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:56:52.258679
119	2b398cbb-d2b3-412c-8fe2-00f926c165da	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:56:52.258679
120	2b398cbb-d2b3-412c-8fe2-00f926c165da	preset	e6082bfc-53af-478d-bdf3-afd2a4adfe7e	visual_style	2025-10-23 02:56:52.258679
121	fcabceb1-2c53-4187-9bdb-17f8d719bb6a	clothing_item	19f5601c-25bc-46f3-8d78-aca07513ced8	headwear	2025-10-23 02:57:22.286378
122	fcabceb1-2c53-4187-9bdb-17f8d719bb6a	clothing_item	37091233-b4c7-449b-9c26-46c22fb24d3d	outerwear	2025-10-23 02:57:22.286379
123	fcabceb1-2c53-4187-9bdb-17f8d719bb6a	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:57:22.286379
124	fcabceb1-2c53-4187-9bdb-17f8d719bb6a	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:57:22.286379
125	fcabceb1-2c53-4187-9bdb-17f8d719bb6a	preset	e6082bfc-53af-478d-bdf3-afd2a4adfe7e	visual_style	2025-10-23 02:57:22.28638
126	80c0b9a3-5b2b-452f-850d-12d183879d3a	clothing_item	19f5601c-25bc-46f3-8d78-aca07513ced8	headwear	2025-10-23 02:58:07.104493
127	80c0b9a3-5b2b-452f-850d-12d183879d3a	clothing_item	75c9d2df-0af7-4014-a176-fcfedb4d80c5	outerwear	2025-10-23 02:58:07.104494
128	80c0b9a3-5b2b-452f-850d-12d183879d3a	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:58:07.104494
129	80c0b9a3-5b2b-452f-850d-12d183879d3a	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:58:07.104494
130	80c0b9a3-5b2b-452f-850d-12d183879d3a	preset	e6082bfc-53af-478d-bdf3-afd2a4adfe7e	visual_style	2025-10-23 02:58:07.104495
131	cfb9752f-96d7-48a3-bed7-5e4f982e6d1b	clothing_item	19f5601c-25bc-46f3-8d78-aca07513ced8	headwear	2025-10-23 02:58:35.240717
132	cfb9752f-96d7-48a3-bed7-5e4f982e6d1b	clothing_item	efa6cd09-edf4-4872-bd44-1fadadb76a4c	outerwear	2025-10-23 02:58:35.240718
133	cfb9752f-96d7-48a3-bed7-5e4f982e6d1b	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:58:35.240719
134	cfb9752f-96d7-48a3-bed7-5e4f982e6d1b	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:58:35.240719
135	cfb9752f-96d7-48a3-bed7-5e4f982e6d1b	preset	e6082bfc-53af-478d-bdf3-afd2a4adfe7e	visual_style	2025-10-23 02:58:35.240719
136	eeeed8ed-6b1a-474c-8d01-7af5e27ead60	clothing_item	19f5601c-25bc-46f3-8d78-aca07513ced8	headwear	2025-10-23 02:58:57.007208
137	eeeed8ed-6b1a-474c-8d01-7af5e27ead60	clothing_item	efa6cd09-edf4-4872-bd44-1fadadb76a4c	outerwear	2025-10-23 02:58:57.007209
138	eeeed8ed-6b1a-474c-8d01-7af5e27ead60	clothing_item	54889628-d76e-46cc-9f85-87fd8488ef2c	outerwear	2025-10-23 02:58:57.007209
139	eeeed8ed-6b1a-474c-8d01-7af5e27ead60	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:58:57.00721
140	eeeed8ed-6b1a-474c-8d01-7af5e27ead60	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:58:57.00721
141	eeeed8ed-6b1a-474c-8d01-7af5e27ead60	preset	e6082bfc-53af-478d-bdf3-afd2a4adfe7e	visual_style	2025-10-23 02:58:57.00721
142	8b08dbf6-300e-4ad8-900b-3af4771df8dc	clothing_item	19f5601c-25bc-46f3-8d78-aca07513ced8	headwear	2025-10-23 02:59:27.752182
143	8b08dbf6-300e-4ad8-900b-3af4771df8dc	clothing_item	efa6cd09-edf4-4872-bd44-1fadadb76a4c	outerwear	2025-10-23 02:59:27.752183
144	8b08dbf6-300e-4ad8-900b-3af4771df8dc	clothing_item	5cc3e8fc-9bcd-4e30-bd67-0b440e53709f	outerwear	2025-10-23 02:59:27.752183
145	8b08dbf6-300e-4ad8-900b-3af4771df8dc	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 02:59:27.752184
146	8b08dbf6-300e-4ad8-900b-3af4771df8dc	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 02:59:27.752184
147	8b08dbf6-300e-4ad8-900b-3af4771df8dc	preset	e6082bfc-53af-478d-bdf3-afd2a4adfe7e	visual_style	2025-10-23 02:59:27.752184
148	0cc48e46-a696-4ead-b8b3-8f1f61232b7f	clothing_item	19f5601c-25bc-46f3-8d78-aca07513ced8	headwear	2025-10-23 03:00:03.4987
149	0cc48e46-a696-4ead-b8b3-8f1f61232b7f	clothing_item	efa6cd09-edf4-4872-bd44-1fadadb76a4c	outerwear	2025-10-23 03:00:03.498701
150	0cc48e46-a696-4ead-b8b3-8f1f61232b7f	clothing_item	54d1c58d-774d-44f2-a979-f327430c003b	outerwear	2025-10-23 03:00:03.498701
151	0cc48e46-a696-4ead-b8b3-8f1f61232b7f	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 03:00:03.498702
152	0cc48e46-a696-4ead-b8b3-8f1f61232b7f	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:00:03.498702
153	0cc48e46-a696-4ead-b8b3-8f1f61232b7f	preset	e6082bfc-53af-478d-bdf3-afd2a4adfe7e	visual_style	2025-10-23 03:00:03.498702
154	305372b1-43b7-4b25-9e95-3ffc4c7b2c52	clothing_item	19f5601c-25bc-46f3-8d78-aca07513ced8	headwear	2025-10-23 03:01:07.6777
155	305372b1-43b7-4b25-9e95-3ffc4c7b2c52	clothing_item	efa6cd09-edf4-4872-bd44-1fadadb76a4c	outerwear	2025-10-23 03:01:07.677701
156	305372b1-43b7-4b25-9e95-3ffc4c7b2c52	clothing_item	54d1c58d-774d-44f2-a979-f327430c003b	outerwear	2025-10-23 03:01:07.677701
157	305372b1-43b7-4b25-9e95-3ffc4c7b2c52	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 03:01:07.677701
158	305372b1-43b7-4b25-9e95-3ffc4c7b2c52	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:01:07.677702
159	305372b1-43b7-4b25-9e95-3ffc4c7b2c52	preset	103857b1-3194-436f-9bb0-17b6c5f37ca1	visual_style	2025-10-23 03:01:07.677702
160	c3a7cda7-8017-4f1d-81ec-7dbc0d50bbb6	clothing_item	19f5601c-25bc-46f3-8d78-aca07513ced8	headwear	2025-10-23 03:01:42.920952
161	c3a7cda7-8017-4f1d-81ec-7dbc0d50bbb6	clothing_item	54d1c58d-774d-44f2-a979-f327430c003b	outerwear	2025-10-23 03:01:42.920952
162	c3a7cda7-8017-4f1d-81ec-7dbc0d50bbb6	clothing_item	33d8c16f-379f-4a17-b3e8-82a9671925a6	outerwear	2025-10-23 03:01:42.920953
163	c3a7cda7-8017-4f1d-81ec-7dbc0d50bbb6	clothing_item	2adbc096-894a-43de-89fe-90e7c9332764	bottoms	2025-10-23 03:01:42.920953
164	c3a7cda7-8017-4f1d-81ec-7dbc0d50bbb6	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:01:42.920953
165	c3a7cda7-8017-4f1d-81ec-7dbc0d50bbb6	preset	103857b1-3194-436f-9bb0-17b6c5f37ca1	visual_style	2025-10-23 03:01:42.920954
166	87b90798-8b58-4380-a423-e7635a2865a6	character	ed013856	subject	2025-10-23 03:14:31.771753
167	d4041ef8-b33b-4166-9707-3411adbcade8	character	ed013856	subject	2025-10-23 03:14:31.771755
168	3e7cd6d9-ec36-4af4-bf46-e9486ae6e7c6	character	ed013856	subject	2025-10-23 03:14:31.771756
169	32b97c66-f197-4b80-b775-a64665ae9e6a	character	ed013856	subject	2025-10-23 03:14:31.771756
170	2153290f-cd58-4e09-ae72-97397e9ed681	character	ed013856	subject	2025-10-23 03:14:31.771756
171	c5fa69fb-199c-45d0-bc68-3818ac15805a	character	ed013856	subject	2025-10-23 03:14:31.771756
172	93480946-202e-411b-b828-e6cdb4e192b3	character	ed013856	subject	2025-10-23 03:14:31.771756
173	95172adf-37b3-46cb-9a93-8254f91bd872	character	ed013856	subject	2025-10-23 03:14:31.771757
174	b591eea0-3677-4e5f-b7ac-97f44a240c59	character	ed013856	subject	2025-10-23 03:14:31.771757
175	259a988e-200b-4ba4-a280-1a62c6526169	character	ed013856	subject	2025-10-23 03:14:31.771757
176	e3cb82b8-4a9b-4e79-b3b5-728d8e8445da	character	ed013856	subject	2025-10-23 03:14:31.771757
177	631b2a4c-24df-4b2f-bca8-a8e5e277f816	character	ed013856	subject	2025-10-23 03:14:31.771757
178	a93d4bbd-59bc-4b11-99fd-6172fec308c8	character	ed013856	subject	2025-10-23 03:14:31.771757
179	261d09a9-7b75-4fe2-b324-634cba4db003	character	ed013856	subject	2025-10-23 03:14:31.771758
180	31d23e9b-fecc-415f-bfc6-9acec311c40d	character	ed013856	subject	2025-10-23 03:14:31.771758
181	6c2a6e18-5797-40b6-8d3c-19f1f4138874	character	ed013856	subject	2025-10-23 03:14:31.771758
182	3e7900a6-12b1-45d2-a89e-30b5ed7771cd	character	ed013856	subject	2025-10-23 03:14:31.771758
183	1c4f020c-0585-4dcc-85fe-6b3dcb40d040	character	ed013856	subject	2025-10-23 03:14:31.771758
184	778bc926-c610-4671-8bd9-a4d1710a01d2	character	ed013856	subject	2025-10-23 03:14:31.771759
185	d300ff17-2b80-4344-99ee-0f65f2c85d39	character	ed013856	subject	2025-10-23 03:14:31.771759
186	501102fd-a10b-41ff-82f6-9746ef1d0708	character	ed013856	subject	2025-10-23 03:14:31.771759
187	0017e333-bba4-40ca-b1dd-f0e03c581a2b	character	ed013856	subject	2025-10-23 03:14:31.771759
188	8f99b4bc-8a7f-4467-9986-c7419f866e33	character	ed013856	subject	2025-10-23 03:14:31.771759
189	10c14ad3-f199-49af-8a4b-7f60debad404	character	ed013856	subject	2025-10-23 03:14:31.77176
190	d08c5a19-7e11-4e9d-81b3-751a46ba6f5c	character	ed013856	subject	2025-10-23 03:14:31.77176
191	0ea18371-df0a-4757-9711-77877bb3b795	character	ed013856	subject	2025-10-23 03:14:31.77176
192	2b398cbb-d2b3-412c-8fe2-00f926c165da	character	ed013856	subject	2025-10-23 03:14:31.77176
193	fcabceb1-2c53-4187-9bdb-17f8d719bb6a	character	ed013856	subject	2025-10-23 03:14:31.77176
194	80c0b9a3-5b2b-452f-850d-12d183879d3a	character	ed013856	subject	2025-10-23 03:14:31.771761
195	eeeed8ed-6b1a-474c-8d01-7af5e27ead60	character	ed013856	subject	2025-10-23 03:14:31.771761
196	0cc48e46-a696-4ead-b8b3-8f1f61232b7f	character	ed013856	subject	2025-10-23 03:14:31.771761
197	c3a7cda7-8017-4f1d-81ec-7dbc0d50bbb6	character	ed013856	subject	2025-10-23 03:14:31.771761
198	2fbe2618-2310-419c-a89c-f74591b73d1a	character	ed013856	subject	2025-10-23 03:14:31.771761
199	ef002301-5126-41b3-811e-1bf22d0f3750	character	ed013856	subject	2025-10-23 03:14:31.771762
200	cfb9752f-96d7-48a3-bed7-5e4f982e6d1b	character	ed013856	subject	2025-10-23 03:14:31.771762
201	305372b1-43b7-4b25-9e95-3ffc4c7b2c52	character	ed013856	subject	2025-10-23 03:14:31.771763
202	8b08dbf6-300e-4ad8-900b-3af4771df8dc	character	ed013856	subject	2025-10-23 03:14:31.771763
203	61ad3a99-3713-47bf-9e3d-6da889d5dfcf	preset	e68524e5-b251-4944-ae27-dca2a23ec475	visual_style	2025-10-23 03:42:39.832837
204	0ed0d9dd-2983-4f42-a0bd-413364796639	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:42:54.953709
205	0ed0d9dd-2983-4f42-a0bd-413364796639	preset	e68524e5-b251-4944-ae27-dca2a23ec475	visual_style	2025-10-23 03:42:54.95371
206	11ff509d-14a9-4569-ae26-315dee1cedb3	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:44:11.50594
207	11ff509d-14a9-4569-ae26-315dee1cedb3	clothing_item	147fd9d3-7ba1-49ca-bd1e-49d147eee920	outerwear	2025-10-23 03:44:11.505941
208	11ff509d-14a9-4569-ae26-315dee1cedb3	preset	e68524e5-b251-4944-ae27-dca2a23ec475	visual_style	2025-10-23 03:44:11.505941
209	598f2d5f-07a7-4fce-a9ea-8edf1eeb6cc9	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:45:05.819128
210	598f2d5f-07a7-4fce-a9ea-8edf1eeb6cc9	clothing_item	147fd9d3-7ba1-49ca-bd1e-49d147eee920	outerwear	2025-10-23 03:45:05.819129
211	598f2d5f-07a7-4fce-a9ea-8edf1eeb6cc9	clothing_item	7b5c6c8e-bfae-407b-9575-85581d5265b2	handwear	2025-10-23 03:45:05.81913
212	598f2d5f-07a7-4fce-a9ea-8edf1eeb6cc9	preset	e68524e5-b251-4944-ae27-dca2a23ec475	visual_style	2025-10-23 03:45:05.81913
213	2abb2966-4908-47b3-997f-8a44dda0cab0	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:45:58.890622
214	2abb2966-4908-47b3-997f-8a44dda0cab0	clothing_item	147fd9d3-7ba1-49ca-bd1e-49d147eee920	outerwear	2025-10-23 03:45:58.890623
215	2abb2966-4908-47b3-997f-8a44dda0cab0	clothing_item	7b5c6c8e-bfae-407b-9575-85581d5265b2	handwear	2025-10-23 03:45:58.890623
216	2abb2966-4908-47b3-997f-8a44dda0cab0	preset	28cb5959-7139-4eeb-99a3-ccdd3d3da361	visual_style	2025-10-23 03:45:58.890623
217	32ab831d-3776-4239-ae71-c6fe76ed7631	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:46:20.107269
218	32ab831d-3776-4239-ae71-c6fe76ed7631	clothing_item	147fd9d3-7ba1-49ca-bd1e-49d147eee920	outerwear	2025-10-23 03:46:20.10727
219	32ab831d-3776-4239-ae71-c6fe76ed7631	clothing_item	7b5c6c8e-bfae-407b-9575-85581d5265b2	handwear	2025-10-23 03:46:20.107271
220	32ab831d-3776-4239-ae71-c6fe76ed7631	preset	28cb5959-7139-4eeb-99a3-ccdd3d3da361	visual_style	2025-10-23 03:46:20.107271
221	32ab831d-3776-4239-ae71-c6fe76ed7631	preset	a133557e-11fe-413f-b84b-f6393651c9d6	hair_color	2025-10-23 03:46:20.107271
222	9371a345-6981-49c3-b466-362345fc668d	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:46:40.439947
223	9371a345-6981-49c3-b466-362345fc668d	clothing_item	147fd9d3-7ba1-49ca-bd1e-49d147eee920	outerwear	2025-10-23 03:46:40.439948
224	9371a345-6981-49c3-b466-362345fc668d	clothing_item	7b5c6c8e-bfae-407b-9575-85581d5265b2	handwear	2025-10-23 03:46:40.439948
225	9371a345-6981-49c3-b466-362345fc668d	preset	28cb5959-7139-4eeb-99a3-ccdd3d3da361	visual_style	2025-10-23 03:46:40.439949
226	9371a345-6981-49c3-b466-362345fc668d	preset	3b476660-57a9-4d70-bf0b-0b4ef9b160a5	hair_color	2025-10-23 03:46:40.439949
227	5b72d4a1-4029-42b8-8532-6c9d9211e13e	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:46:40.629577
228	5b72d4a1-4029-42b8-8532-6c9d9211e13e	clothing_item	147fd9d3-7ba1-49ca-bd1e-49d147eee920	outerwear	2025-10-23 03:46:40.629578
229	5b72d4a1-4029-42b8-8532-6c9d9211e13e	clothing_item	7b5c6c8e-bfae-407b-9575-85581d5265b2	handwear	2025-10-23 03:46:40.629578
230	5b72d4a1-4029-42b8-8532-6c9d9211e13e	preset	28cb5959-7139-4eeb-99a3-ccdd3d3da361	visual_style	2025-10-23 03:46:40.629578
231	5b72d4a1-4029-42b8-8532-6c9d9211e13e	preset	81b45f8a-7f1f-4993-8ad9-643d4742ad74	hair_style	2025-10-23 03:46:40.629579
232	5b72d4a1-4029-42b8-8532-6c9d9211e13e	preset	3b476660-57a9-4d70-bf0b-0b4ef9b160a5	hair_color	2025-10-23 03:46:40.629579
233	ac86027b-6cf9-4763-97be-d4508d532f57	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:47:30.30636
234	ac86027b-6cf9-4763-97be-d4508d532f57	clothing_item	147fd9d3-7ba1-49ca-bd1e-49d147eee920	outerwear	2025-10-23 03:47:30.306361
235	ac86027b-6cf9-4763-97be-d4508d532f57	clothing_item	7b5c6c8e-bfae-407b-9575-85581d5265b2	handwear	2025-10-23 03:47:30.306361
236	ac86027b-6cf9-4763-97be-d4508d532f57	preset	28cb5959-7139-4eeb-99a3-ccdd3d3da361	visual_style	2025-10-23 03:47:30.306362
237	ac86027b-6cf9-4763-97be-d4508d532f57	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:47:30.306362
238	ac86027b-6cf9-4763-97be-d4508d532f57	preset	3b476660-57a9-4d70-bf0b-0b4ef9b160a5	hair_color	2025-10-23 03:47:30.306362
239	8c4846e8-8509-4f77-b4e4-311ed575e56a	preset	b0235b3f-5df8-4475-8eeb-b55d045c2f41	visual_style	2025-10-23 03:48:25.415476
240	a4a5075f-f338-45c7-9c3f-5faee197e6b3	clothing_item	29aff18c-043c-46fb-8ec9-718d017d64c9	outerwear	2025-10-23 03:48:39.15055
241	a4a5075f-f338-45c7-9c3f-5faee197e6b3	preset	b0235b3f-5df8-4475-8eeb-b55d045c2f41	visual_style	2025-10-23 03:48:39.150551
242	15815a91-0a5c-4370-9bc7-9fae468e1366	clothing_item	29aff18c-043c-46fb-8ec9-718d017d64c9	outerwear	2025-10-23 03:48:56.363038
243	15815a91-0a5c-4370-9bc7-9fae468e1366	preset	b0235b3f-5df8-4475-8eeb-b55d045c2f41	visual_style	2025-10-23 03:48:56.363039
244	15815a91-0a5c-4370-9bc7-9fae468e1366	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:48:56.363039
245	be22182c-18e6-4219-9202-140948957333	clothing_item	29aff18c-043c-46fb-8ec9-718d017d64c9	outerwear	2025-10-23 03:49:16.495374
246	be22182c-18e6-4219-9202-140948957333	preset	88b40ba7-b918-4951-9fa4-bd31850a934a	visual_style	2025-10-23 03:49:16.495374
247	be22182c-18e6-4219-9202-140948957333	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:49:16.495375
248	194147c6-9521-4786-936b-044b4c6c8e9d	clothing_item	29aff18c-043c-46fb-8ec9-718d017d64c9	outerwear	2025-10-23 03:49:31.085288
249	194147c6-9521-4786-936b-044b4c6c8e9d	preset	28cb5959-7139-4eeb-99a3-ccdd3d3da361	visual_style	2025-10-23 03:49:31.085289
250	194147c6-9521-4786-936b-044b4c6c8e9d	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:49:31.085289
251	eafbb73b-1fd9-413a-b9b6-0ae4c75d08aa	clothing_item	3d4dc11e-1d45-4e47-9151-8366a40120f8	outerwear	2025-10-23 03:50:02.733543
252	eafbb73b-1fd9-413a-b9b6-0ae4c75d08aa	clothing_item	371de43a-ce4d-4a83-b0b6-a02cda1c329f	outerwear	2025-10-23 03:50:02.733545
253	eafbb73b-1fd9-413a-b9b6-0ae4c75d08aa	clothing_item	33d8c16f-379f-4a17-b3e8-82a9671925a6	outerwear	2025-10-23 03:50:02.733545
254	eafbb73b-1fd9-413a-b9b6-0ae4c75d08aa	preset	28cb5959-7139-4eeb-99a3-ccdd3d3da361	visual_style	2025-10-23 03:50:02.733546
255	eafbb73b-1fd9-413a-b9b6-0ae4c75d08aa	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:50:02.733546
256	317ebfde-e1c8-4bc2-8220-6f152069ec35	clothing_item	3d4dc11e-1d45-4e47-9151-8366a40120f8	outerwear	2025-10-23 03:50:16.881557
257	317ebfde-e1c8-4bc2-8220-6f152069ec35	clothing_item	371de43a-ce4d-4a83-b0b6-a02cda1c329f	outerwear	2025-10-23 03:50:16.881559
258	317ebfde-e1c8-4bc2-8220-6f152069ec35	clothing_item	33d8c16f-379f-4a17-b3e8-82a9671925a6	outerwear	2025-10-23 03:50:16.881559
259	317ebfde-e1c8-4bc2-8220-6f152069ec35	clothing_item	c3cf387a-4fcd-44cf-b2e4-294a00f2995f	outerwear	2025-10-23 03:50:16.881559
260	317ebfde-e1c8-4bc2-8220-6f152069ec35	preset	28cb5959-7139-4eeb-99a3-ccdd3d3da361	visual_style	2025-10-23 03:50:16.88156
261	317ebfde-e1c8-4bc2-8220-6f152069ec35	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:50:16.88156
262	dae2d81d-bf62-46eb-8417-893a9f74f262	clothing_item	3d4dc11e-1d45-4e47-9151-8366a40120f8	outerwear	2025-10-23 03:50:32.049396
263	dae2d81d-bf62-46eb-8417-893a9f74f262	clothing_item	33d8c16f-379f-4a17-b3e8-82a9671925a6	outerwear	2025-10-23 03:50:32.049397
264	dae2d81d-bf62-46eb-8417-893a9f74f262	preset	28cb5959-7139-4eeb-99a3-ccdd3d3da361	visual_style	2025-10-23 03:50:32.049397
265	dae2d81d-bf62-46eb-8417-893a9f74f262	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:50:32.049397
266	7f308fbb-2e4d-43f4-98c5-6e976a0b6868	clothing_item	3d4dc11e-1d45-4e47-9151-8366a40120f8	outerwear	2025-10-23 03:50:34.337966
267	7f308fbb-2e4d-43f4-98c5-6e976a0b6868	preset	28cb5959-7139-4eeb-99a3-ccdd3d3da361	visual_style	2025-10-23 03:50:34.337967
268	7f308fbb-2e4d-43f4-98c5-6e976a0b6868	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:50:34.337968
269	e5da60d7-598e-48c4-b0d4-ca9e78771c68	clothing_item	3d4dc11e-1d45-4e47-9151-8366a40120f8	outerwear	2025-10-23 03:50:52.020091
270	e5da60d7-598e-48c4-b0d4-ca9e78771c68	preset	28cb5959-7139-4eeb-99a3-ccdd3d3da361	visual_style	2025-10-23 03:50:52.020091
271	e5da60d7-598e-48c4-b0d4-ca9e78771c68	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:50:52.020092
272	e5da60d7-598e-48c4-b0d4-ca9e78771c68	preset	60abaaba-808c-4283-90c0-5520c61a6699	expression	2025-10-23 03:50:52.020092
277	07e3a62e-f549-46e9-9904-59d0de0be82a	clothing_item	3d4dc11e-1d45-4e47-9151-8366a40120f8	outerwear	2025-10-23 03:51:30.407688
278	07e3a62e-f549-46e9-9904-59d0de0be82a	preset	918d3d8f-392a-4c33-bb36-b579390084b7	visual_style	2025-10-23 03:51:30.407689
279	07e3a62e-f549-46e9-9904-59d0de0be82a	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:51:30.407689
280	07e3a62e-f549-46e9-9904-59d0de0be82a	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:51:30.40769
273	f4db73d8-8cb3-4104-86cf-68e141f9a7b5	clothing_item	3d4dc11e-1d45-4e47-9151-8366a40120f8	outerwear	2025-10-23 03:51:09.560778
274	f4db73d8-8cb3-4104-86cf-68e141f9a7b5	preset	918d3d8f-392a-4c33-bb36-b579390084b7	visual_style	2025-10-23 03:51:09.560779
275	f4db73d8-8cb3-4104-86cf-68e141f9a7b5	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:51:09.56078
276	f4db73d8-8cb3-4104-86cf-68e141f9a7b5	preset	60abaaba-808c-4283-90c0-5520c61a6699	expression	2025-10-23 03:51:09.56078
281	310ccba5-7186-4d47-8395-7d91c7ddf6e8	clothing_item	3d4dc11e-1d45-4e47-9151-8366a40120f8	outerwear	2025-10-23 03:52:28.736495
282	310ccba5-7186-4d47-8395-7d91c7ddf6e8	clothing_item	4499f26b-508f-4dfa-abc0-540eaf554023	handwear	2025-10-23 03:52:28.736495
283	310ccba5-7186-4d47-8395-7d91c7ddf6e8	preset	918d3d8f-392a-4c33-bb36-b579390084b7	visual_style	2025-10-23 03:52:28.736496
284	310ccba5-7186-4d47-8395-7d91c7ddf6e8	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:52:28.736496
285	310ccba5-7186-4d47-8395-7d91c7ddf6e8	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:52:28.736496
286	8d926cce-9d18-4532-8bed-933a300d8b64	clothing_item	3d4dc11e-1d45-4e47-9151-8366a40120f8	outerwear	2025-10-23 03:53:01.232111
287	8d926cce-9d18-4532-8bed-933a300d8b64	clothing_item	4499f26b-508f-4dfa-abc0-540eaf554023	handwear	2025-10-23 03:53:01.232112
288	8d926cce-9d18-4532-8bed-933a300d8b64	preset	918d3d8f-392a-4c33-bb36-b579390084b7	visual_style	2025-10-23 03:53:01.232112
289	8d926cce-9d18-4532-8bed-933a300d8b64	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:53:01.232113
290	8d926cce-9d18-4532-8bed-933a300d8b64	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:53:01.232113
291	7ae02f55-e15b-4a5b-be78-6524800ff6eb	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:53:17.083879
292	7ae02f55-e15b-4a5b-be78-6524800ff6eb	clothing_item	3d4dc11e-1d45-4e47-9151-8366a40120f8	outerwear	2025-10-23 03:53:17.083879
293	7ae02f55-e15b-4a5b-be78-6524800ff6eb	clothing_item	4499f26b-508f-4dfa-abc0-540eaf554023	handwear	2025-10-23 03:53:17.08388
294	7ae02f55-e15b-4a5b-be78-6524800ff6eb	preset	918d3d8f-392a-4c33-bb36-b579390084b7	visual_style	2025-10-23 03:53:17.08388
295	7ae02f55-e15b-4a5b-be78-6524800ff6eb	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:53:17.08388
296	7ae02f55-e15b-4a5b-be78-6524800ff6eb	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:53:17.08388
297	68ca8cc1-e6ee-4d82-83c1-c23aadcd4e4d	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:53:31.057414
298	68ca8cc1-e6ee-4d82-83c1-c23aadcd4e4d	clothing_item	8f337fe8-02ba-47f9-a6aa-b3dfa6c39c38	eyewear	2025-10-23 03:53:31.057415
299	68ca8cc1-e6ee-4d82-83c1-c23aadcd4e4d	clothing_item	3d4dc11e-1d45-4e47-9151-8366a40120f8	outerwear	2025-10-23 03:53:31.057415
300	68ca8cc1-e6ee-4d82-83c1-c23aadcd4e4d	clothing_item	4499f26b-508f-4dfa-abc0-540eaf554023	handwear	2025-10-23 03:53:31.057416
301	68ca8cc1-e6ee-4d82-83c1-c23aadcd4e4d	preset	918d3d8f-392a-4c33-bb36-b579390084b7	visual_style	2025-10-23 03:53:31.057416
302	68ca8cc1-e6ee-4d82-83c1-c23aadcd4e4d	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:53:31.057416
303	68ca8cc1-e6ee-4d82-83c1-c23aadcd4e4d	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:53:31.057417
304	8c03e36d-c8ed-471e-87b6-d1b1c3f0e8c0	clothing_item	8f337fe8-02ba-47f9-a6aa-b3dfa6c39c38	eyewear	2025-10-23 03:53:34.660801
305	8c03e36d-c8ed-471e-87b6-d1b1c3f0e8c0	clothing_item	3d4dc11e-1d45-4e47-9151-8366a40120f8	outerwear	2025-10-23 03:53:34.660802
306	8c03e36d-c8ed-471e-87b6-d1b1c3f0e8c0	clothing_item	4499f26b-508f-4dfa-abc0-540eaf554023	handwear	2025-10-23 03:53:34.660802
307	8c03e36d-c8ed-471e-87b6-d1b1c3f0e8c0	preset	918d3d8f-392a-4c33-bb36-b579390084b7	visual_style	2025-10-23 03:53:34.660803
308	8c03e36d-c8ed-471e-87b6-d1b1c3f0e8c0	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:53:34.660803
309	8c03e36d-c8ed-471e-87b6-d1b1c3f0e8c0	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:53:34.660803
310	212c0633-1751-45e0-9f5a-f5cd3589c1f0	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:54:08.241183
311	212c0633-1751-45e0-9f5a-f5cd3589c1f0	clothing_item	3d4dc11e-1d45-4e47-9151-8366a40120f8	outerwear	2025-10-23 03:54:08.241184
312	212c0633-1751-45e0-9f5a-f5cd3589c1f0	clothing_item	4499f26b-508f-4dfa-abc0-540eaf554023	handwear	2025-10-23 03:54:08.241184
313	212c0633-1751-45e0-9f5a-f5cd3589c1f0	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:54:08.241184
314	212c0633-1751-45e0-9f5a-f5cd3589c1f0	preset	918d3d8f-392a-4c33-bb36-b579390084b7	visual_style	2025-10-23 03:54:08.241184
315	212c0633-1751-45e0-9f5a-f5cd3589c1f0	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:54:08.241185
316	212c0633-1751-45e0-9f5a-f5cd3589c1f0	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:54:08.241185
317	e722485e-7eb8-4672-8073-926e87710a27	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:54:09.439099
318	e722485e-7eb8-4672-8073-926e87710a27	clothing_item	3d4dc11e-1d45-4e47-9151-8366a40120f8	outerwear	2025-10-23 03:54:09.439099
319	e722485e-7eb8-4672-8073-926e87710a27	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:54:09.4391
320	e722485e-7eb8-4672-8073-926e87710a27	preset	918d3d8f-392a-4c33-bb36-b579390084b7	visual_style	2025-10-23 03:54:09.4391
321	e722485e-7eb8-4672-8073-926e87710a27	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:54:09.4391
322	e722485e-7eb8-4672-8073-926e87710a27	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:54:09.4391
323	757e6769-7a9c-4f8c-b05c-d6d95bc057bb	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:54:35.619242
324	757e6769-7a9c-4f8c-b05c-d6d95bc057bb	clothing_item	75c9d2df-0af7-4014-a176-fcfedb4d80c5	outerwear	2025-10-23 03:54:35.619243
325	757e6769-7a9c-4f8c-b05c-d6d95bc057bb	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:54:35.619243
326	757e6769-7a9c-4f8c-b05c-d6d95bc057bb	preset	918d3d8f-392a-4c33-bb36-b579390084b7	visual_style	2025-10-23 03:54:35.619244
327	757e6769-7a9c-4f8c-b05c-d6d95bc057bb	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:54:35.619244
328	757e6769-7a9c-4f8c-b05c-d6d95bc057bb	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:54:35.619244
329	e4c63a29-d5ae-42f4-85ef-24fa7dc0f6ce	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:55:21.860268
330	e4c63a29-d5ae-42f4-85ef-24fa7dc0f6ce	clothing_item	c19ff0b6-0a88-44e8-b6d5-cb4b95650829	neckwear	2025-10-23 03:55:21.860269
331	e4c63a29-d5ae-42f4-85ef-24fa7dc0f6ce	clothing_item	75c9d2df-0af7-4014-a176-fcfedb4d80c5	outerwear	2025-10-23 03:55:21.86027
332	e4c63a29-d5ae-42f4-85ef-24fa7dc0f6ce	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:55:21.86027
333	e4c63a29-d5ae-42f4-85ef-24fa7dc0f6ce	preset	918d3d8f-392a-4c33-bb36-b579390084b7	visual_style	2025-10-23 03:55:21.860271
334	e4c63a29-d5ae-42f4-85ef-24fa7dc0f6ce	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:55:21.860271
335	e4c63a29-d5ae-42f4-85ef-24fa7dc0f6ce	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:55:21.860271
336	42ceb554-481a-4c8a-a0cd-56dbb84d75c5	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:55:40.977358
337	42ceb554-481a-4c8a-a0cd-56dbb84d75c5	clothing_item	c19ff0b6-0a88-44e8-b6d5-cb4b95650829	neckwear	2025-10-23 03:55:40.977359
338	42ceb554-481a-4c8a-a0cd-56dbb84d75c5	clothing_item	362e6e6a-93d1-4946-85bb-3b4ef683348c	neckwear	2025-10-23 03:55:40.97736
339	42ceb554-481a-4c8a-a0cd-56dbb84d75c5	clothing_item	75c9d2df-0af7-4014-a176-fcfedb4d80c5	outerwear	2025-10-23 03:55:40.97736
340	42ceb554-481a-4c8a-a0cd-56dbb84d75c5	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:55:40.97736
341	42ceb554-481a-4c8a-a0cd-56dbb84d75c5	preset	918d3d8f-392a-4c33-bb36-b579390084b7	visual_style	2025-10-23 03:55:40.97736
342	42ceb554-481a-4c8a-a0cd-56dbb84d75c5	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:55:40.977361
343	42ceb554-481a-4c8a-a0cd-56dbb84d75c5	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:55:40.977361
344	4f732bbd-1589-4586-b775-5e022c0dc8eb	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:55:41.259736
345	4f732bbd-1589-4586-b775-5e022c0dc8eb	clothing_item	362e6e6a-93d1-4946-85bb-3b4ef683348c	neckwear	2025-10-23 03:55:41.259737
346	4f732bbd-1589-4586-b775-5e022c0dc8eb	clothing_item	75c9d2df-0af7-4014-a176-fcfedb4d80c5	outerwear	2025-10-23 03:55:41.259738
347	4f732bbd-1589-4586-b775-5e022c0dc8eb	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:55:41.259738
348	4f732bbd-1589-4586-b775-5e022c0dc8eb	preset	918d3d8f-392a-4c33-bb36-b579390084b7	visual_style	2025-10-23 03:55:41.259738
349	4f732bbd-1589-4586-b775-5e022c0dc8eb	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:55:41.259738
350	4f732bbd-1589-4586-b775-5e022c0dc8eb	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:55:41.259738
351	e55ee9e8-5f6e-4f98-a5ca-c9b7c62b7806	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:56:03.7259
352	e55ee9e8-5f6e-4f98-a5ca-c9b7c62b7806	clothing_item	362e6e6a-93d1-4946-85bb-3b4ef683348c	neckwear	2025-10-23 03:56:03.725901
353	e55ee9e8-5f6e-4f98-a5ca-c9b7c62b7806	clothing_item	75c9d2df-0af7-4014-a176-fcfedb4d80c5	outerwear	2025-10-23 03:56:03.725902
354	e55ee9e8-5f6e-4f98-a5ca-c9b7c62b7806	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:56:03.725902
355	e55ee9e8-5f6e-4f98-a5ca-c9b7c62b7806	preset	918d3d8f-392a-4c33-bb36-b579390084b7	visual_style	2025-10-23 03:56:03.725902
356	e55ee9e8-5f6e-4f98-a5ca-c9b7c62b7806	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:56:03.725902
357	e55ee9e8-5f6e-4f98-a5ca-c9b7c62b7806	preset	45a2c167-07da-4210-80ac-7e98d84b4ad7	expression	2025-10-23 03:56:03.725903
358	ee65688a-24fb-4140-a172-4391a2b88e2a	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:56:18.606351
359	ee65688a-24fb-4140-a172-4391a2b88e2a	clothing_item	362e6e6a-93d1-4946-85bb-3b4ef683348c	neckwear	2025-10-23 03:56:18.606352
360	ee65688a-24fb-4140-a172-4391a2b88e2a	clothing_item	75c9d2df-0af7-4014-a176-fcfedb4d80c5	outerwear	2025-10-23 03:56:18.606352
361	ee65688a-24fb-4140-a172-4391a2b88e2a	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:56:18.606352
362	ee65688a-24fb-4140-a172-4391a2b88e2a	preset	918d3d8f-392a-4c33-bb36-b579390084b7	visual_style	2025-10-23 03:56:18.606353
363	ee65688a-24fb-4140-a172-4391a2b88e2a	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:56:18.606353
364	df12b7d5-3fcf-4230-8bc4-2f329b4830b0	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:56:40.243627
365	df12b7d5-3fcf-4230-8bc4-2f329b4830b0	clothing_item	362e6e6a-93d1-4946-85bb-3b4ef683348c	neckwear	2025-10-23 03:56:40.243629
366	df12b7d5-3fcf-4230-8bc4-2f329b4830b0	clothing_item	75c9d2df-0af7-4014-a176-fcfedb4d80c5	outerwear	2025-10-23 03:56:40.243629
367	df12b7d5-3fcf-4230-8bc4-2f329b4830b0	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:56:40.243629
368	df12b7d5-3fcf-4230-8bc4-2f329b4830b0	preset	c4285e69-f4a1-4987-b16b-cf5c4ee92f78	visual_style	2025-10-23 03:56:40.243629
369	df12b7d5-3fcf-4230-8bc4-2f329b4830b0	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:56:40.24363
370	f5ab75ef-b828-4301-9cb6-1a9df004593c	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:56:59.211491
371	f5ab75ef-b828-4301-9cb6-1a9df004593c	clothing_item	362e6e6a-93d1-4946-85bb-3b4ef683348c	neckwear	2025-10-23 03:56:59.211492
372	f5ab75ef-b828-4301-9cb6-1a9df004593c	clothing_item	75c9d2df-0af7-4014-a176-fcfedb4d80c5	outerwear	2025-10-23 03:56:59.211493
373	f5ab75ef-b828-4301-9cb6-1a9df004593c	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:56:59.211493
374	f5ab75ef-b828-4301-9cb6-1a9df004593c	preset	c4285e69-f4a1-4987-b16b-cf5c4ee92f78	visual_style	2025-10-23 03:56:59.211493
375	f5ab75ef-b828-4301-9cb6-1a9df004593c	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:56:59.211493
376	f5ab75ef-b828-4301-9cb6-1a9df004593c	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:56:59.211493
377	806703e8-17e0-4f75-9bd2-7f2780936d73	clothing_item	ec2b6dfd-9872-46bf-8efe-10c8d6374ead	headwear	2025-10-23 03:57:29.512264
378	806703e8-17e0-4f75-9bd2-7f2780936d73	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:57:29.512265
379	806703e8-17e0-4f75-9bd2-7f2780936d73	clothing_item	362e6e6a-93d1-4946-85bb-3b4ef683348c	neckwear	2025-10-23 03:57:29.512266
380	806703e8-17e0-4f75-9bd2-7f2780936d73	clothing_item	75c9d2df-0af7-4014-a176-fcfedb4d80c5	outerwear	2025-10-23 03:57:29.512266
381	806703e8-17e0-4f75-9bd2-7f2780936d73	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:57:29.512266
382	806703e8-17e0-4f75-9bd2-7f2780936d73	preset	c4285e69-f4a1-4987-b16b-cf5c4ee92f78	visual_style	2025-10-23 03:57:29.512267
383	806703e8-17e0-4f75-9bd2-7f2780936d73	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:57:29.512267
384	806703e8-17e0-4f75-9bd2-7f2780936d73	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:57:29.512267
385	01c552f9-ac5f-4e43-9526-64f76bb75c32	clothing_item	ec2b6dfd-9872-46bf-8efe-10c8d6374ead	headwear	2025-10-23 03:57:56.055038
386	01c552f9-ac5f-4e43-9526-64f76bb75c32	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:57:56.055039
387	01c552f9-ac5f-4e43-9526-64f76bb75c32	clothing_item	362e6e6a-93d1-4946-85bb-3b4ef683348c	neckwear	2025-10-23 03:57:56.05504
388	01c552f9-ac5f-4e43-9526-64f76bb75c32	clothing_item	75c9d2df-0af7-4014-a176-fcfedb4d80c5	outerwear	2025-10-23 03:57:56.05504
389	01c552f9-ac5f-4e43-9526-64f76bb75c32	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:57:56.05504
390	01c552f9-ac5f-4e43-9526-64f76bb75c32	preset	c4285e69-f4a1-4987-b16b-cf5c4ee92f78	visual_style	2025-10-23 03:57:56.05504
391	01c552f9-ac5f-4e43-9526-64f76bb75c32	preset	e6a8b0ab-d207-47aa-a4ef-0e8d4310a7dc	hair_style	2025-10-23 03:57:56.055041
392	01c552f9-ac5f-4e43-9526-64f76bb75c32	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:57:56.055041
393	ee11d9e1-7d1f-46b8-b775-0d2615d7e524	clothing_item	ec2b6dfd-9872-46bf-8efe-10c8d6374ead	headwear	2025-10-23 03:58:37.881416
394	ee11d9e1-7d1f-46b8-b775-0d2615d7e524	clothing_item	eef5156b-2792-455f-9b07-561c1527d016	eyewear	2025-10-23 03:58:37.881417
395	ee11d9e1-7d1f-46b8-b775-0d2615d7e524	clothing_item	362e6e6a-93d1-4946-85bb-3b4ef683348c	neckwear	2025-10-23 03:58:37.881418
396	ee11d9e1-7d1f-46b8-b775-0d2615d7e524	clothing_item	75c9d2df-0af7-4014-a176-fcfedb4d80c5	outerwear	2025-10-23 03:58:37.881418
397	ee11d9e1-7d1f-46b8-b775-0d2615d7e524	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:58:37.881418
398	ee11d9e1-7d1f-46b8-b775-0d2615d7e524	preset	c4285e69-f4a1-4987-b16b-cf5c4ee92f78	visual_style	2025-10-23 03:58:37.881418
399	ee11d9e1-7d1f-46b8-b775-0d2615d7e524	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:58:37.881419
400	64f617fd-ee2b-4a34-824e-6797b3620658	clothing_item	ec2b6dfd-9872-46bf-8efe-10c8d6374ead	headwear	2025-10-23 03:58:47.736712
401	64f617fd-ee2b-4a34-824e-6797b3620658	clothing_item	362e6e6a-93d1-4946-85bb-3b4ef683348c	neckwear	2025-10-23 03:58:47.736713
402	64f617fd-ee2b-4a34-824e-6797b3620658	clothing_item	75c9d2df-0af7-4014-a176-fcfedb4d80c5	outerwear	2025-10-23 03:58:47.736714
403	64f617fd-ee2b-4a34-824e-6797b3620658	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:58:47.736714
404	64f617fd-ee2b-4a34-824e-6797b3620658	preset	c4285e69-f4a1-4987-b16b-cf5c4ee92f78	visual_style	2025-10-23 03:58:47.736715
405	64f617fd-ee2b-4a34-824e-6797b3620658	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:58:47.736715
406	3819b69e-507a-4623-b124-7fda5bae50be	clothing_item	ec2b6dfd-9872-46bf-8efe-10c8d6374ead	headwear	2025-10-23 03:59:04.30792
407	3819b69e-507a-4623-b124-7fda5bae50be	clothing_item	75c9d2df-0af7-4014-a176-fcfedb4d80c5	outerwear	2025-10-23 03:59:04.307921
408	3819b69e-507a-4623-b124-7fda5bae50be	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:59:04.307922
409	3819b69e-507a-4623-b124-7fda5bae50be	preset	c4285e69-f4a1-4987-b16b-cf5c4ee92f78	visual_style	2025-10-23 03:59:04.307922
410	3819b69e-507a-4623-b124-7fda5bae50be	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:59:04.307922
416	c7336d84-9c64-4460-9732-106696ea8337	clothing_item	ec2b6dfd-9872-46bf-8efe-10c8d6374ead	headwear	2025-10-23 03:59:46.924665
417	c7336d84-9c64-4460-9732-106696ea8337	clothing_item	75c9d2df-0af7-4014-a176-fcfedb4d80c5	outerwear	2025-10-23 03:59:46.924665
418	c7336d84-9c64-4460-9732-106696ea8337	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:59:46.924666
419	c7336d84-9c64-4460-9732-106696ea8337	preset	2ec9596a-9d0c-42c1-ac63-c6a48bfcc3e9	visual_style	2025-10-23 03:59:46.924666
420	c7336d84-9c64-4460-9732-106696ea8337	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:59:46.924666
430	0b202d3b-30eb-43e1-8ff7-c4cda10813f2	clothing_item	90593337-5d62-45cb-9576-64d98070b9ce	outerwear	2025-10-23 04:00:53.212935
431	0b202d3b-30eb-43e1-8ff7-c4cda10813f2	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 04:00:53.212936
432	0b202d3b-30eb-43e1-8ff7-c4cda10813f2	preset	2ec9596a-9d0c-42c1-ac63-c6a48bfcc3e9	visual_style	2025-10-23 04:00:53.212937
433	0b202d3b-30eb-43e1-8ff7-c4cda10813f2	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 04:00:53.212937
434	1767ccca-9636-421d-9359-5402407b9673	clothing_item	90593337-5d62-45cb-9576-64d98070b9ce	outerwear	2025-10-23 04:01:12.078261
435	1767ccca-9636-421d-9359-5402407b9673	preset	2ec9596a-9d0c-42c1-ac63-c6a48bfcc3e9	visual_style	2025-10-23 04:01:12.078262
436	1767ccca-9636-421d-9359-5402407b9673	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 04:01:12.078262
437	f3e297ed-af77-420e-9881-e537a788ecbb	clothing_item	90593337-5d62-45cb-9576-64d98070b9ce	outerwear	2025-10-23 04:01:27.644705
438	f3e297ed-af77-420e-9881-e537a788ecbb	clothing_item	7b5c6c8e-bfae-407b-9575-85581d5265b2	handwear	2025-10-23 04:01:27.644706
439	f3e297ed-af77-420e-9881-e537a788ecbb	preset	2ec9596a-9d0c-42c1-ac63-c6a48bfcc3e9	visual_style	2025-10-23 04:01:27.644706
440	f3e297ed-af77-420e-9881-e537a788ecbb	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 04:01:27.644707
441	e296022e-f16b-4e9a-8fd0-cbe5c2c85d9f	clothing_item	90593337-5d62-45cb-9576-64d98070b9ce	outerwear	2025-10-23 04:02:02.25849
442	e296022e-f16b-4e9a-8fd0-cbe5c2c85d9f	clothing_item	7b5c6c8e-bfae-407b-9575-85581d5265b2	handwear	2025-10-23 04:02:02.258491
443	e296022e-f16b-4e9a-8fd0-cbe5c2c85d9f	preset	9730992c-5156-436e-af0a-f12d0c23e91a	visual_style	2025-10-23 04:02:02.258492
444	e296022e-f16b-4e9a-8fd0-cbe5c2c85d9f	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 04:02:02.258492
456	160a2ff8-7399-427b-8e15-6cdba00668a9	clothing_item	90593337-5d62-45cb-9576-64d98070b9ce	outerwear	2025-10-23 04:04:14.166595
457	160a2ff8-7399-427b-8e15-6cdba00668a9	clothing_item	7b5c6c8e-bfae-407b-9575-85581d5265b2	handwear	2025-10-23 04:04:14.166596
458	160a2ff8-7399-427b-8e15-6cdba00668a9	preset	9730992c-5156-436e-af0a-f12d0c23e91a	visual_style	2025-10-23 04:04:14.166596
459	3d097621-042c-468a-a0f8-3dd0dae21d53	clothing_item	90593337-5d62-45cb-9576-64d98070b9ce	outerwear	2025-10-23 04:04:30.992102
460	3d097621-042c-468a-a0f8-3dd0dae21d53	clothing_item	7b5c6c8e-bfae-407b-9575-85581d5265b2	handwear	2025-10-23 04:04:30.992103
461	3d097621-042c-468a-a0f8-3dd0dae21d53	preset	9730992c-5156-436e-af0a-f12d0c23e91a	visual_style	2025-10-23 04:04:30.992103
411	3b617bc4-0759-4ede-b92f-265b3ff758b6	clothing_item	ec2b6dfd-9872-46bf-8efe-10c8d6374ead	headwear	2025-10-23 03:59:22.00737
412	3b617bc4-0759-4ede-b92f-265b3ff758b6	clothing_item	75c9d2df-0af7-4014-a176-fcfedb4d80c5	outerwear	2025-10-23 03:59:22.007371
413	3b617bc4-0759-4ede-b92f-265b3ff758b6	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 03:59:22.007371
414	3b617bc4-0759-4ede-b92f-265b3ff758b6	preset	81805c02-35c1-47b3-91c7-6bc0f8318569	visual_style	2025-10-23 03:59:22.007371
415	3b617bc4-0759-4ede-b92f-265b3ff758b6	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 03:59:22.007372
421	a4d6bca5-54e5-4187-8139-bd4723632b9e	clothing_item	ec2b6dfd-9872-46bf-8efe-10c8d6374ead	headwear	2025-10-23 04:00:09.392542
422	a4d6bca5-54e5-4187-8139-bd4723632b9e	clothing_item	90593337-5d62-45cb-9576-64d98070b9ce	outerwear	2025-10-23 04:00:09.392543
423	a4d6bca5-54e5-4187-8139-bd4723632b9e	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 04:00:09.392543
424	a4d6bca5-54e5-4187-8139-bd4723632b9e	preset	2ec9596a-9d0c-42c1-ac63-c6a48bfcc3e9	visual_style	2025-10-23 04:00:09.392543
425	a4d6bca5-54e5-4187-8139-bd4723632b9e	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 04:00:09.392544
426	de8a0114-050f-4379-9a0d-2d4097c3cbe0	clothing_item	90593337-5d62-45cb-9576-64d98070b9ce	outerwear	2025-10-23 04:00:35.814111
427	de8a0114-050f-4379-9a0d-2d4097c3cbe0	clothing_item	fa8faacf-1ac6-4b06-a91b-def31062dede	handwear	2025-10-23 04:00:35.814112
428	de8a0114-050f-4379-9a0d-2d4097c3cbe0	preset	2ec9596a-9d0c-42c1-ac63-c6a48bfcc3e9	visual_style	2025-10-23 04:00:35.814112
429	de8a0114-050f-4379-9a0d-2d4097c3cbe0	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 04:00:35.814112
445	ec518bcb-b587-4294-8488-77e56b604667	clothing_item	90593337-5d62-45cb-9576-64d98070b9ce	outerwear	2025-10-23 04:02:19.947035
446	ec518bcb-b587-4294-8488-77e56b604667	clothing_item	7b5c6c8e-bfae-407b-9575-85581d5265b2	handwear	2025-10-23 04:02:19.947037
447	ec518bcb-b587-4294-8488-77e56b604667	preset	9730992c-5156-436e-af0a-f12d0c23e91a	visual_style	2025-10-23 04:02:19.947037
448	ec518bcb-b587-4294-8488-77e56b604667	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 04:02:19.947037
449	51afbf6b-9d27-4185-9cff-37dcf6e3284c	clothing_item	90593337-5d62-45cb-9576-64d98070b9ce	outerwear	2025-10-23 04:03:02.290775
450	51afbf6b-9d27-4185-9cff-37dcf6e3284c	clothing_item	7b5c6c8e-bfae-407b-9575-85581d5265b2	handwear	2025-10-23 04:03:02.290777
451	51afbf6b-9d27-4185-9cff-37dcf6e3284c	preset	9730992c-5156-436e-af0a-f12d0c23e91a	visual_style	2025-10-23 04:03:02.290777
452	51afbf6b-9d27-4185-9cff-37dcf6e3284c	preset	9fe7efe1-0567-401c-911e-44cc42986e51	expression	2025-10-23 04:03:02.290777
453	35accf4b-ef4b-45d9-9a78-adeb23175c4a	clothing_item	90593337-5d62-45cb-9576-64d98070b9ce	outerwear	2025-10-23 04:03:23.508438
454	35accf4b-ef4b-45d9-9a78-adeb23175c4a	clothing_item	7b5c6c8e-bfae-407b-9575-85581d5265b2	handwear	2025-10-23 04:03:23.508439
455	35accf4b-ef4b-45d9-9a78-adeb23175c4a	preset	9730992c-5156-436e-af0a-f12d0c23e91a	visual_style	2025-10-23 04:03:23.50844
462	1368c462-aef6-46c5-ad4e-54074e891529	character	ed394873	subject	2025-10-23 04:11:05.329754
463	1368c462-aef6-46c5-ad4e-54074e891529	clothing_item	45ffdb1e-f95e-4bf2-a69f-f49b33a8c436	outerwear	2025-10-23 04:11:05.329755
464	1368c462-aef6-46c5-ad4e-54074e891529	preset	3cf8cca9-e296-4708-89e3-f41fcf412563	visual_style	2025-10-23 04:11:05.329755
465	2a8ea10c-a029-4f92-9c4b-22c6b25186f5	character	ed394873	subject	2025-10-23 04:11:18.69993
466	2a8ea10c-a029-4f92-9c4b-22c6b25186f5	clothing_item	45ffdb1e-f95e-4bf2-a69f-f49b33a8c436	outerwear	2025-10-23 04:11:18.699931
467	2a8ea10c-a029-4f92-9c4b-22c6b25186f5	clothing_item	c9fda71b-cc41-4038-aae6-f3485002a4e4	outerwear	2025-10-23 04:11:18.699931
468	2a8ea10c-a029-4f92-9c4b-22c6b25186f5	preset	3cf8cca9-e296-4708-89e3-f41fcf412563	visual_style	2025-10-23 04:11:18.699931
469	8db96cf7-70aa-479f-a5fd-2bcb8d347068	character	ed394873	subject	2025-10-23 04:12:57.78289
470	8db96cf7-70aa-479f-a5fd-2bcb8d347068	preset	99df90f7-0973-4712-983c-01acf7a7288a	visual_style	2025-10-23 04:12:57.782891
471	e4807b64-2694-4018-b6c2-39c9672cda69	character	ed394873	subject	2025-10-23 04:13:14.399121
472	e4807b64-2694-4018-b6c2-39c9672cda69	clothing_item	e0db974f-5c30-4930-86af-80df5e6618f2	outerwear	2025-10-23 04:13:14.399122
473	e4807b64-2694-4018-b6c2-39c9672cda69	clothing_item	4ae3a661-a2e0-4629-9cd8-563eea216247	one_piece	2025-10-23 04:13:14.399122
474	e4807b64-2694-4018-b6c2-39c9672cda69	preset	99df90f7-0973-4712-983c-01acf7a7288a	visual_style	2025-10-23 04:13:14.399122
475	a5697be8-1cab-41a6-b459-5aa1de54d994	character	ed394873	subject	2025-10-23 04:14:54.715672
476	a5697be8-1cab-41a6-b459-5aa1de54d994	clothing_item	e0db974f-5c30-4930-86af-80df5e6618f2	outerwear	2025-10-23 04:14:54.715673
477	a5697be8-1cab-41a6-b459-5aa1de54d994	clothing_item	4ae3a661-a2e0-4629-9cd8-563eea216247	one_piece	2025-10-23 04:14:54.715674
478	a5697be8-1cab-41a6-b459-5aa1de54d994	preset	d999f1c7-545f-45c2-a522-3c216bc6c11a	visual_style	2025-10-23 04:14:54.715674
479	3d097621-042c-468a-a0f8-3dd0dae21d53	character	1af92043	subject	2025-10-23 04:15:11.31941
480	160a2ff8-7399-427b-8e15-6cdba00668a9	character	cc68e0e0	subject	2025-10-23 04:15:11.321965
481	35accf4b-ef4b-45d9-9a78-adeb23175c4a	character	ed013856	subject	2025-10-23 04:15:11.322932
482	51afbf6b-9d27-4185-9cff-37dcf6e3284c	character	ed013856	subject	2025-10-23 04:15:11.323842
483	ec518bcb-b587-4294-8488-77e56b604667	character	8bf67f72	subject	2025-10-23 04:15:11.324606
484	e296022e-f16b-4e9a-8fd0-cbe5c2c85d9f	character	41c5726d	subject	2025-10-23 04:15:11.325436
485	f3e297ed-af77-420e-9881-e537a788ecbb	character	41c5726d	subject	2025-10-23 04:15:11.327434
486	1767ccca-9636-421d-9359-5402407b9673	character	41c5726d	subject	2025-10-23 04:15:11.328089
487	0b202d3b-30eb-43e1-8ff7-c4cda10813f2	character	41c5726d	subject	2025-10-23 04:15:11.328725
488	de8a0114-050f-4379-9a0d-2d4097c3cbe0	character	165d9c0c	subject	2025-10-23 04:15:11.329326
489	a4d6bca5-54e5-4187-8139-bd4723632b9e	character	165d9c0c	subject	2025-10-23 04:15:11.330015
490	c7336d84-9c64-4460-9732-106696ea8337	character	165d9c0c	subject	2025-10-23 04:15:11.33068
491	3b617bc4-0759-4ede-b92f-265b3ff758b6	character	165d9c0c	subject	2025-10-23 04:15:11.331295
492	3819b69e-507a-4623-b124-7fda5bae50be	character	165d9c0c	subject	2025-10-23 04:15:11.3319
493	64f617fd-ee2b-4a34-824e-6797b3620658	character	165d9c0c	subject	2025-10-23 04:15:11.332533
494	ee11d9e1-7d1f-46b8-b775-0d2615d7e524	character	165d9c0c	subject	2025-10-23 04:15:11.333275
495	01c552f9-ac5f-4e43-9526-64f76bb75c32	character	165d9c0c	subject	2025-10-23 04:15:11.333874
496	806703e8-17e0-4f75-9bd2-7f2780936d73	character	e9f5d330	subject	2025-10-23 04:15:11.334473
497	f5ab75ef-b828-4301-9cb6-1a9df004593c	character	e9f5d330	subject	2025-10-23 04:15:11.335077
498	df12b7d5-3fcf-4230-8bc4-2f329b4830b0	character	e9f5d330	subject	2025-10-23 04:15:11.335722
499	ee65688a-24fb-4140-a172-4391a2b88e2a	character	e9f5d330	subject	2025-10-23 04:15:11.336381
500	e55ee9e8-5f6e-4f98-a5ca-c9b7c62b7806	character	e9f5d330	subject	2025-10-23 04:15:11.33696
501	4f732bbd-1589-4586-b775-5e022c0dc8eb	character	e9f5d330	subject	2025-10-23 04:15:11.337604
502	42ceb554-481a-4c8a-a0cd-56dbb84d75c5	character	e9f5d330	subject	2025-10-23 04:15:11.338195
503	e4c63a29-d5ae-42f4-85ef-24fa7dc0f6ce	character	e9f5d330	subject	2025-10-23 04:15:11.338859
504	757e6769-7a9c-4f8c-b05c-d6d95bc057bb	character	e9f5d330	subject	2025-10-23 04:15:11.339438
505	e722485e-7eb8-4672-8073-926e87710a27	character	e9f5d330	subject	2025-10-23 04:15:11.340187
506	212c0633-1751-45e0-9f5a-f5cd3589c1f0	character	e9f5d330	subject	2025-10-23 04:15:11.340769
507	8c03e36d-c8ed-471e-87b6-d1b1c3f0e8c0	character	e9f5d330	subject	2025-10-23 04:15:11.341358
508	68ca8cc1-e6ee-4d82-83c1-c23aadcd4e4d	character	e9f5d330	subject	2025-10-23 04:15:11.341957
509	7ae02f55-e15b-4a5b-be78-6524800ff6eb	character	e9f5d330	subject	2025-10-23 04:15:11.342577
510	8d926cce-9d18-4532-8bed-933a300d8b64	character	e9f5d330	subject	2025-10-23 04:15:11.343155
511	310ccba5-7186-4d47-8395-7d91c7ddf6e8	character	ac73052d	subject	2025-10-23 04:15:11.34394
512	07e3a62e-f549-46e9-9904-59d0de0be82a	character	ac73052d	subject	2025-10-23 04:15:11.344578
513	f4db73d8-8cb3-4104-86cf-68e141f9a7b5	character	ac73052d	subject	2025-10-23 04:15:11.345208
514	e5da60d7-598e-48c4-b0d4-ca9e78771c68	character	ac73052d	subject	2025-10-23 04:15:11.345802
515	7f308fbb-2e4d-43f4-98c5-6e976a0b6868	character	ac73052d	subject	2025-10-23 04:15:11.346425
516	dae2d81d-bf62-46eb-8417-893a9f74f262	character	ac73052d	subject	2025-10-23 04:15:11.346993
517	317ebfde-e1c8-4bc2-8220-6f152069ec35	character	ac73052d	subject	2025-10-23 04:15:11.347563
518	eafbb73b-1fd9-413a-b9b6-0ae4c75d08aa	character	ac73052d	subject	2025-10-23 04:15:11.348199
519	194147c6-9521-4786-936b-044b4c6c8e9d	character	ac73052d	subject	2025-10-23 04:15:11.348798
520	be22182c-18e6-4219-9202-140948957333	character	ac73052d	subject	2025-10-23 04:15:11.349413
521	15815a91-0a5c-4370-9bc7-9fae468e1366	character	ac73052d	subject	2025-10-23 04:15:11.349984
522	a4a5075f-f338-45c7-9c3f-5faee197e6b3	character	ac73052d	subject	2025-10-23 04:15:11.350749
523	8c4846e8-8509-4f77-b4e4-311ed575e56a	character	ac73052d	subject	2025-10-23 04:15:11.351328
524	ac86027b-6cf9-4763-97be-d4508d532f57	character	e1f4fe53	subject	2025-10-23 04:15:11.352
525	5b72d4a1-4029-42b8-8532-6c9d9211e13e	character	e1f4fe53	subject	2025-10-23 04:15:11.352643
526	9371a345-6981-49c3-b466-362345fc668d	character	e1f4fe53	subject	2025-10-23 04:15:11.353262
527	32ab831d-3776-4239-ae71-c6fe76ed7631	character	e1f4fe53	subject	2025-10-23 04:15:11.353907
528	2abb2966-4908-47b3-997f-8a44dda0cab0	character	e1f4fe53	subject	2025-10-23 04:15:11.354519
529	598f2d5f-07a7-4fce-a9ea-8edf1eeb6cc9	character	e1f4fe53	subject	2025-10-23 04:15:11.35515
530	11ff509d-14a9-4569-ae26-315dee1cedb3	character	e1f4fe53	subject	2025-10-23 04:15:11.355808
531	0ed0d9dd-2983-4f42-a0bd-413364796639	character	e1f4fe53	subject	2025-10-23 04:15:11.356409
532	61ad3a99-3713-47bf-9e3d-6da889d5dfcf	character	e1f4fe53	subject	2025-10-23 04:15:11.357062
533	323acaed-dbcf-411c-927f-d22f749619a5	character	ed394873	subject	2025-10-23 04:15:21.658285
534	323acaed-dbcf-411c-927f-d22f749619a5	clothing_item	e0db974f-5c30-4930-86af-80df5e6618f2	outerwear	2025-10-23 04:15:21.658286
535	323acaed-dbcf-411c-927f-d22f749619a5	clothing_item	4ae3a661-a2e0-4629-9cd8-563eea216247	one_piece	2025-10-23 04:15:21.658286
536	323acaed-dbcf-411c-927f-d22f749619a5	preset	b03709d4-24be-4770-bb6a-f96c37f9eb5f	visual_style	2025-10-23 04:15:21.658287
537	1652d3a3-37f3-48a8-b2aa-f8b747954f7a	character	1d191360	subject	2025-10-23 04:15:36.298016
538	1652d3a3-37f3-48a8-b2aa-f8b747954f7a	clothing_item	e0db974f-5c30-4930-86af-80df5e6618f2	outerwear	2025-10-23 04:15:36.298017
539	1652d3a3-37f3-48a8-b2aa-f8b747954f7a	clothing_item	4ae3a661-a2e0-4629-9cd8-563eea216247	one_piece	2025-10-23 04:15:36.298017
540	1652d3a3-37f3-48a8-b2aa-f8b747954f7a	preset	b03709d4-24be-4770-bb6a-f96c37f9eb5f	visual_style	2025-10-23 04:15:36.298018
541	5713b65b-5dfc-48e9-ba60-7a8aa8c1635e	character	1d191360	subject	2025-10-23 04:15:56.293942
542	5713b65b-5dfc-48e9-ba60-7a8aa8c1635e	clothing_item	e0db974f-5c30-4930-86af-80df5e6618f2	outerwear	2025-10-23 04:15:56.293943
543	5713b65b-5dfc-48e9-ba60-7a8aa8c1635e	clothing_item	4ae3a661-a2e0-4629-9cd8-563eea216247	one_piece	2025-10-23 04:15:56.293943
544	5713b65b-5dfc-48e9-ba60-7a8aa8c1635e	preset	b03709d4-24be-4770-bb6a-f96c37f9eb5f	visual_style	2025-10-23 04:15:56.293944
545	5713b65b-5dfc-48e9-ba60-7a8aa8c1635e	preset	a133557e-11fe-413f-b84b-f6393651c9d6	hair_color	2025-10-23 04:15:56.293944
\.


--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: lifeos
--

COPY public.images (id, image_id, file_path, filename, width, height, generation_metadata, created_at, user_id) FROM stdin;
1	87b90798-8b58-4380-a423-e7635a2865a6	output/generated/ed013856_ref_modular_20251023_024158.png	ed013856_ref_modular_20251023_024158.png	\N	\N	{"job_id": "75c8d457-d168-4c96-93a9-9a27998246aa", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:41:58.513811	\N
2	d4041ef8-b33b-4166-9707-3411adbcade8	output/generated/ed013856_ref_modular_20251023_024307.png	ed013856_ref_modular_20251023_024307.png	\N	\N	{"job_id": "b0ca9017-46da-445d-9e0d-671c2d97f00b", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:43:07.302755	\N
3	3e7cd6d9-ec36-4af4-bf46-e9486ae6e7c6	output/generated/ed013856_ref_modular_20251023_024323.png	ed013856_ref_modular_20251023_024323.png	\N	\N	{"job_id": "a61e9602-b740-46ce-8540-befeb1a1f92f", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:43:23.549051	\N
4	32b97c66-f197-4b80-b775-a64665ae9e6a	output/generated/ed013856_ref_modular_20251023_024348.png	ed013856_ref_modular_20251023_024348.png	\N	\N	{"job_id": "b4d8f369-bb0d-4724-8232-384f0f2c3df2", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:43:48.47941	\N
5	2153290f-cd58-4e09-ae72-97397e9ed681	output/generated/ed013856_ref_modular_20251023_024406.png	ed013856_ref_modular_20251023_024406.png	\N	\N	{"job_id": "de071fe2-ff9b-4c51-a0cb-51b669015fb1", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:44:06.751813	\N
6	c5fa69fb-199c-45d0-bc68-3818ac15805a	output/generated/ed013856_ref_modular_20251023_024418.png	ed013856_ref_modular_20251023_024418.png	\N	\N	{"job_id": "0178740f-58d0-445f-9d5d-bc68dadd534c", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:44:18.845431	\N
7	93480946-202e-411b-b828-e6cdb4e192b3	output/generated/ed013856_ref_modular_20251023_024439.png	ed013856_ref_modular_20251023_024439.png	\N	\N	{"job_id": "c5f0ecfc-8dc5-4573-a12c-da718b6ee899", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:44:39.752297	\N
8	95172adf-37b3-46cb-9a93-8254f91bd872	output/generated/ed013856_ref_modular_20251023_024551.png	ed013856_ref_modular_20251023_024551.png	\N	\N	{"job_id": "c1349229-22e6-473e-b636-94abf08daba6", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:45:51.465094	\N
9	b591eea0-3677-4e5f-b7ac-97f44a240c59	output/generated/ed013856_ref_modular_20251023_024646.png	ed013856_ref_modular_20251023_024646.png	\N	\N	{"job_id": "76120a8b-3e9e-482f-a77d-8103c50f929b", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:46:46.003711	\N
10	259a988e-200b-4ba4-a280-1a62c6526169	output/generated/ed013856_ref_modular_20251023_024705.png	ed013856_ref_modular_20251023_024705.png	\N	\N	{"job_id": "cb2dcfd9-9978-415d-a8bd-1fd5642a29c7", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:47:05.805785	\N
11	e3cb82b8-4a9b-4e79-b3b5-728d8e8445da	output/generated/ed013856_ref_modular_20251023_024808.png	ed013856_ref_modular_20251023_024808.png	\N	\N	{"job_id": "e19807be-d9c8-4a73-b0f4-8e5d0c665d03", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:48:08.491968	\N
12	631b2a4c-24df-4b2f-bca8-a8e5e277f816	output/generated/ed013856_ref_modular_20251023_024827.png	ed013856_ref_modular_20251023_024827.png	\N	\N	{"job_id": "65951bbc-96a4-4947-9859-f10578d224ac", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:48:27.82016	\N
13	a93d4bbd-59bc-4b11-99fd-6172fec308c8	output/generated/ed013856_ref_modular_20251023_024849.png	ed013856_ref_modular_20251023_024849.png	\N	\N	{"job_id": "af165ad7-fcd1-4a3e-ab41-7fbf478f36c7", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:48:49.909194	\N
14	261d09a9-7b75-4fe2-b324-634cba4db003	output/generated/ed013856_ref_modular_20251023_024906.png	ed013856_ref_modular_20251023_024906.png	\N	\N	{"job_id": "db9ada91-08be-4ef5-9c9c-088f3056727c", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:49:06.192294	\N
15	31d23e9b-fecc-415f-bfc6-9acec311c40d	output/generated/ed013856_ref_modular_20251023_024929.png	ed013856_ref_modular_20251023_024929.png	\N	\N	{"job_id": "90fdf373-4157-4cda-ba87-8d69f2123412", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:49:29.495893	\N
16	6c2a6e18-5797-40b6-8d3c-19f1f4138874	output/generated/ed013856_ref_modular_20251023_024946.png	ed013856_ref_modular_20251023_024946.png	\N	\N	{"job_id": "e8a162f5-9dbc-44a1-925c-4ec7aed9da4c", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:49:46.55782	\N
17	3e7900a6-12b1-45d2-a89e-30b5ed7771cd	output/generated/ed013856_ref_modular_20251023_025013.png	ed013856_ref_modular_20251023_025013.png	\N	\N	{"job_id": "92936c9c-98bd-4b16-98d0-f3a7c2d4ecd9", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:50:13.148294	\N
18	1c4f020c-0585-4dcc-85fe-6b3dcb40d040	output/generated/ed013856_ref_modular_20251023_025036.png	ed013856_ref_modular_20251023_025036.png	\N	\N	{"job_id": "d71af300-949d-4194-8d05-6e249096644e", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:50:36.783307	\N
19	778bc926-c610-4671-8bd9-a4d1710a01d2	output/generated/ed013856_ref_modular_20251023_025059.png	ed013856_ref_modular_20251023_025059.png	\N	\N	{"job_id": "e02eeba7-0133-4163-9807-041f41db3fe1", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:50:59.687787	\N
20	d300ff17-2b80-4344-99ee-0f65f2c85d39	output/generated/ed013856_ref_modular_20251023_025132.png	ed013856_ref_modular_20251023_025132.png	\N	\N	{"job_id": "0c837096-8e80-43e3-8816-7c6216583331", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:51:32.015792	\N
21	501102fd-a10b-41ff-82f6-9746ef1d0708	output/generated/ed013856_ref_modular_20251023_025157.png	ed013856_ref_modular_20251023_025157.png	\N	\N	{"job_id": "a24d43e6-c237-45c2-bbed-12aedb505f3c", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:51:57.119625	\N
22	0017e333-bba4-40ca-b1dd-f0e03c581a2b	output/generated/ed013856_ref_modular_20251023_025218.png	ed013856_ref_modular_20251023_025218.png	\N	\N	{"job_id": "c5f5e263-a8eb-4d67-bc9d-01f922bdd70c", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:52:18.57401	\N
23	8f99b4bc-8a7f-4467-9986-c7419f866e33	output/generated/ed013856_ref_modular_20251023_025236.png	ed013856_ref_modular_20251023_025236.png	\N	\N	{"job_id": "21ceffde-e680-4826-a8f2-80419d7b87b5", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:52:36.034078	\N
24	10c14ad3-f199-49af-8a4b-7f60debad404	output/generated/ed013856_ref_modular_20251023_025337.png	ed013856_ref_modular_20251023_025337.png	\N	\N	{"job_id": "9edf0be1-ae2e-421a-88e0-a7f96687b27d", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:53:37.208711	\N
25	d08c5a19-7e11-4e9d-81b3-751a46ba6f5c	output/generated/ed013856_ref_modular_20251023_025403.png	ed013856_ref_modular_20251023_025403.png	\N	\N	{"job_id": "11df2eee-0fc5-49b0-a04e-71660fda0f56", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:54:03.252744	\N
27	0ea18371-df0a-4757-9711-77877bb3b795	output/generated/ed013856_ref_modular_20251023_025508.png	ed013856_ref_modular_20251023_025508.png	\N	\N	{"job_id": "840a4dc5-654b-424a-b8cb-204239c0b0ad", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:55:08.667673	\N
29	2b398cbb-d2b3-412c-8fe2-00f926c165da	output/generated/ed013856_ref_modular_20251023_025652.png	ed013856_ref_modular_20251023_025652.png	\N	\N	{"job_id": "63b6ea4e-10ca-448e-8e66-1705ca5553e0", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:56:52.256558	\N
30	fcabceb1-2c53-4187-9bdb-17f8d719bb6a	output/generated/ed013856_ref_modular_20251023_025722.png	ed013856_ref_modular_20251023_025722.png	\N	\N	{"job_id": "953564a7-da90-44cd-bd30-b1332fe7e3ec", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:57:22.284317	\N
31	80c0b9a3-5b2b-452f-850d-12d183879d3a	output/generated/ed013856_ref_modular_20251023_025807.png	ed013856_ref_modular_20251023_025807.png	\N	\N	{"job_id": "0d133d5d-3957-4bfc-8372-0ba02fe1ca39", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:58:07.102454	\N
33	eeeed8ed-6b1a-474c-8d01-7af5e27ead60	output/generated/ed013856_ref_modular_20251023_025857.png	ed013856_ref_modular_20251023_025857.png	\N	\N	{"job_id": "0e9d5f10-3096-48e6-90f6-c87036faf6f9", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:58:57.005247	\N
35	0cc48e46-a696-4ead-b8b3-8f1f61232b7f	output/generated/ed013856_ref_modular_20251023_030003.png	ed013856_ref_modular_20251023_030003.png	\N	\N	{"job_id": "0d4dff37-da5e-490a-af8f-2a62c2fdb812", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 03:00:03.496643	\N
37	c3a7cda7-8017-4f1d-81ec-7dbc0d50bbb6	output/generated/ed013856_ref_modular_20251023_030142.png	ed013856_ref_modular_20251023_030142.png	\N	\N	{"job_id": "18bb000d-9e0b-4273-8814-4b7a3fc8020f", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 03:01:42.919091	\N
26	2fbe2618-2310-419c-a89c-f74591b73d1a	output/generated/ed013856_ref_modular_20251023_025438.png	ed013856_ref_modular_20251023_025438.png	\N	\N	{"job_id": "2afe3d1d-7bff-4bd5-b0a8-dae1716ddbb9", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:54:38.708215	\N
28	ef002301-5126-41b3-811e-1bf22d0f3750	output/generated/ed013856_ref_modular_20251023_025527.png	ed013856_ref_modular_20251023_025527.png	\N	\N	{"job_id": "a5cc4d4e-2741-4cdb-b0cc-8a8f2f82bdbf", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:55:27.334362	\N
32	cfb9752f-96d7-48a3-bed7-5e4f982e6d1b	output/generated/ed013856_ref_modular_20251023_025835.png	ed013856_ref_modular_20251023_025835.png	\N	\N	{"job_id": "3e960d8c-701c-42de-a279-3bbecd2c231b", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:58:35.238574	\N
36	305372b1-43b7-4b25-9e95-3ffc4c7b2c52	output/generated/ed013856_ref_modular_20251023_030107.png	ed013856_ref_modular_20251023_030107.png	\N	\N	{"job_id": "b2583a99-4a70-4b7e-ab62-71cabd18a5f3", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 03:01:07.676001	\N
34	8b08dbf6-300e-4ad8-900b-3af4771df8dc	output/generated/ed013856_ref_modular_20251023_025927.png	ed013856_ref_modular_20251023_025927.png	\N	\N	{"job_id": "b5c9cf51-fc41-451d-bece-307b30e87819", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 02:59:27.749603	\N
38	61ad3a99-3713-47bf-9e3d-6da889d5dfcf	output/generated/e1f4fe53_ref_modular_20251023_034239.png	e1f4fe53_ref_modular_20251023_034239.png	\N	\N	{"job_id": "8d9869b5-4d8d-456a-8f3a-6470c948c917", "variation": 1, "generator": "modular", "subject_image": "data/characters/e1f4fe53_ref.png"}	2025-10-23 03:42:39.829325	\N
39	0ed0d9dd-2983-4f42-a0bd-413364796639	output/generated/e1f4fe53_ref_modular_20251023_034254.png	e1f4fe53_ref_modular_20251023_034254.png	\N	\N	{"job_id": "e8ee2ba4-10fc-4c1e-9831-3d95ff024e25", "variation": 1, "generator": "modular", "subject_image": "data/characters/e1f4fe53_ref.png"}	2025-10-23 03:42:54.950659	\N
40	11ff509d-14a9-4569-ae26-315dee1cedb3	output/generated/e1f4fe53_ref_modular_20251023_034411.png	e1f4fe53_ref_modular_20251023_034411.png	\N	\N	{"job_id": "cbed90c2-a91c-4e8e-bdac-ec091bf01296", "variation": 1, "generator": "modular", "subject_image": "data/characters/e1f4fe53_ref.png"}	2025-10-23 03:44:11.499226	\N
41	598f2d5f-07a7-4fce-a9ea-8edf1eeb6cc9	output/generated/e1f4fe53_ref_modular_20251023_034505.png	e1f4fe53_ref_modular_20251023_034505.png	\N	\N	{"job_id": "28c68608-100a-4ea2-975f-8768d20eb5d7", "variation": 1, "generator": "modular", "subject_image": "data/characters/e1f4fe53_ref.png"}	2025-10-23 03:45:05.817057	\N
42	2abb2966-4908-47b3-997f-8a44dda0cab0	output/generated/e1f4fe53_ref_modular_20251023_034558.png	e1f4fe53_ref_modular_20251023_034558.png	\N	\N	{"job_id": "708223c3-b368-461a-8fda-95bcbf41d6c3", "variation": 1, "generator": "modular", "subject_image": "data/characters/e1f4fe53_ref.png"}	2025-10-23 03:45:58.887182	\N
43	32ab831d-3776-4239-ae71-c6fe76ed7631	output/generated/e1f4fe53_ref_modular_20251023_034620.png	e1f4fe53_ref_modular_20251023_034620.png	\N	\N	{"job_id": "32d263b5-7cea-4810-b3a4-e99aa681f03b", "variation": 1, "generator": "modular", "subject_image": "data/characters/e1f4fe53_ref.png"}	2025-10-23 03:46:20.10388	\N
44	9371a345-6981-49c3-b466-362345fc668d	output/generated/e1f4fe53_ref_modular_20251023_034640.png	e1f4fe53_ref_modular_20251023_034640.png	\N	\N	{"job_id": "e33e1d31-e23d-4bb9-8334-a8b58aea1690", "variation": 1, "generator": "modular", "subject_image": "data/characters/e1f4fe53_ref.png"}	2025-10-23 03:46:40.436806	\N
45	5b72d4a1-4029-42b8-8532-6c9d9211e13e	output/generated/e1f4fe53_ref_modular_20251023_034640.png	e1f4fe53_ref_modular_20251023_034640.png	\N	\N	{"job_id": "a1f3f355-7778-47ae-8bec-10b4eafafe62", "variation": 1, "generator": "modular", "subject_image": "data/characters/e1f4fe53_ref.png"}	2025-10-23 03:46:40.627431	\N
46	ac86027b-6cf9-4763-97be-d4508d532f57	output/generated/e1f4fe53_ref_modular_20251023_034730.png	e1f4fe53_ref_modular_20251023_034730.png	\N	\N	{"job_id": "ecfbbb47-99f0-468d-8c18-867e597d812b", "variation": 1, "generator": "modular", "subject_image": "data/characters/e1f4fe53_ref.png"}	2025-10-23 03:47:30.304089	\N
47	8c4846e8-8509-4f77-b4e4-311ed575e56a	output/generated/ac73052d_ref_modular_20251023_034825.png	ac73052d_ref_modular_20251023_034825.png	\N	\N	{"job_id": "0e67eedf-a924-4fb7-8886-16d6fbd5b52c", "variation": 1, "generator": "modular", "subject_image": "data/characters/ac73052d_ref.png"}	2025-10-23 03:48:25.413285	\N
48	a4a5075f-f338-45c7-9c3f-5faee197e6b3	output/generated/ac73052d_ref_modular_20251023_034839.png	ac73052d_ref_modular_20251023_034839.png	\N	\N	{"job_id": "5257265d-e668-43cb-800a-90d37eaeeafc", "variation": 1, "generator": "modular", "subject_image": "data/characters/ac73052d_ref.png"}	2025-10-23 03:48:39.147599	\N
49	15815a91-0a5c-4370-9bc7-9fae468e1366	output/generated/ac73052d_ref_modular_20251023_034856.png	ac73052d_ref_modular_20251023_034856.png	\N	\N	{"job_id": "ba1ea170-9018-4221-8c19-76754605b748", "variation": 1, "generator": "modular", "subject_image": "data/characters/ac73052d_ref.png"}	2025-10-23 03:48:56.360613	\N
50	be22182c-18e6-4219-9202-140948957333	output/generated/ac73052d_ref_modular_20251023_034916.png	ac73052d_ref_modular_20251023_034916.png	\N	\N	{"job_id": "5f1d2144-a6a1-4e3e-9834-5c78a24f527e", "variation": 1, "generator": "modular", "subject_image": "data/characters/ac73052d_ref.png"}	2025-10-23 03:49:16.493138	\N
51	194147c6-9521-4786-936b-044b4c6c8e9d	output/generated/ac73052d_ref_modular_20251023_034931.png	ac73052d_ref_modular_20251023_034931.png	\N	\N	{"job_id": "0cf0e451-c5d3-48a7-8a3f-aabea0271c6a", "variation": 1, "generator": "modular", "subject_image": "data/characters/ac73052d_ref.png"}	2025-10-23 03:49:31.083353	\N
52	eafbb73b-1fd9-413a-b9b6-0ae4c75d08aa	output/generated/ac73052d_ref_modular_20251023_035002.png	ac73052d_ref_modular_20251023_035002.png	\N	\N	{"job_id": "79264abd-5943-4ee8-98d8-e978327f1ae0", "variation": 1, "generator": "modular", "subject_image": "data/characters/ac73052d_ref.png"}	2025-10-23 03:50:02.73157	\N
53	317ebfde-e1c8-4bc2-8220-6f152069ec35	output/generated/ac73052d_ref_modular_20251023_035016.png	ac73052d_ref_modular_20251023_035016.png	\N	\N	{"job_id": "f4555ef4-cba8-42d6-a6e5-565cef64c934", "variation": 1, "generator": "modular", "subject_image": "data/characters/ac73052d_ref.png"}	2025-10-23 03:50:16.879118	\N
54	dae2d81d-bf62-46eb-8417-893a9f74f262	output/generated/ac73052d_ref_modular_20251023_035032.png	ac73052d_ref_modular_20251023_035032.png	\N	\N	{"job_id": "7271bfd4-4dc1-4288-95c4-2b575daec52e", "variation": 1, "generator": "modular", "subject_image": "data/characters/ac73052d_ref.png"}	2025-10-23 03:50:32.047102	\N
55	7f308fbb-2e4d-43f4-98c5-6e976a0b6868	output/generated/ac73052d_ref_modular_20251023_035034.png	ac73052d_ref_modular_20251023_035034.png	\N	\N	{"job_id": "93657c03-8bb6-4e70-aa60-61d44c0c833e", "variation": 1, "generator": "modular", "subject_image": "data/characters/ac73052d_ref.png"}	2025-10-23 03:50:34.336071	\N
56	e5da60d7-598e-48c4-b0d4-ca9e78771c68	output/generated/ac73052d_ref_modular_20251023_035052.png	ac73052d_ref_modular_20251023_035052.png	\N	\N	{"job_id": "1148bbd5-bef4-4f66-9dee-554db48a5903", "variation": 1, "generator": "modular", "subject_image": "data/characters/ac73052d_ref.png"}	2025-10-23 03:50:52.017817	\N
57	f4db73d8-8cb3-4104-86cf-68e141f9a7b5	output/generated/ac73052d_ref_modular_20251023_035109.png	ac73052d_ref_modular_20251023_035109.png	\N	\N	{"job_id": "53b647c9-85d4-421d-8545-4f4fa11e24f8", "variation": 1, "generator": "modular", "subject_image": "data/characters/ac73052d_ref.png"}	2025-10-23 03:51:09.558338	\N
58	07e3a62e-f549-46e9-9904-59d0de0be82a	output/generated/ac73052d_ref_modular_20251023_035130.png	ac73052d_ref_modular_20251023_035130.png	\N	\N	{"job_id": "770e02ab-ae3c-483f-b10c-bbde65a52859", "variation": 1, "generator": "modular", "subject_image": "data/characters/ac73052d_ref.png"}	2025-10-23 03:51:30.405158	\N
59	310ccba5-7186-4d47-8395-7d91c7ddf6e8	output/generated/ac73052d_ref_modular_20251023_035228.png	ac73052d_ref_modular_20251023_035228.png	\N	\N	{"job_id": "f4d750dd-58f0-4741-b905-7b1de74c0f1d", "variation": 1, "generator": "modular", "subject_image": "data/characters/ac73052d_ref.png"}	2025-10-23 03:52:28.734304	\N
60	8d926cce-9d18-4532-8bed-933a300d8b64	output/generated/e9f5d330_ref_modular_20251023_035301.png	e9f5d330_ref_modular_20251023_035301.png	\N	\N	{"job_id": "71d82e4b-56c3-49dc-a7a6-02f488d4c187", "variation": 1, "generator": "modular", "subject_image": "data/characters/e9f5d330_ref.png"}	2025-10-23 03:53:01.229632	\N
61	7ae02f55-e15b-4a5b-be78-6524800ff6eb	output/generated/e9f5d330_ref_modular_20251023_035317.png	e9f5d330_ref_modular_20251023_035317.png	\N	\N	{"job_id": "3fc29ded-7728-4ddf-bafe-ad359249c133", "variation": 1, "generator": "modular", "subject_image": "data/characters/e9f5d330_ref.png"}	2025-10-23 03:53:17.081585	\N
62	68ca8cc1-e6ee-4d82-83c1-c23aadcd4e4d	output/generated/e9f5d330_ref_modular_20251023_035331.png	e9f5d330_ref_modular_20251023_035331.png	\N	\N	{"job_id": "461658d1-92ba-4691-b945-13b0ec64df7a", "variation": 1, "generator": "modular", "subject_image": "data/characters/e9f5d330_ref.png"}	2025-10-23 03:53:31.055089	\N
63	8c03e36d-c8ed-471e-87b6-d1b1c3f0e8c0	output/generated/e9f5d330_ref_modular_20251023_035334.png	e9f5d330_ref_modular_20251023_035334.png	\N	\N	{"job_id": "757f682e-66c0-4d70-a5d7-cbea07da207b", "variation": 1, "generator": "modular", "subject_image": "data/characters/e9f5d330_ref.png"}	2025-10-23 03:53:34.658228	\N
64	212c0633-1751-45e0-9f5a-f5cd3589c1f0	output/generated/e9f5d330_ref_modular_20251023_035408.png	e9f5d330_ref_modular_20251023_035408.png	\N	\N	{"job_id": "a4ac5b62-4660-4206-9596-4404445b9110", "variation": 1, "generator": "modular", "subject_image": "data/characters/e9f5d330_ref.png"}	2025-10-23 03:54:08.238717	\N
65	e722485e-7eb8-4672-8073-926e87710a27	output/generated/e9f5d330_ref_modular_20251023_035409.png	e9f5d330_ref_modular_20251023_035409.png	\N	\N	{"job_id": "c9bc6893-17e8-414f-9f84-2f690940fd00", "variation": 1, "generator": "modular", "subject_image": "data/characters/e9f5d330_ref.png"}	2025-10-23 03:54:09.437062	\N
66	757e6769-7a9c-4f8c-b05c-d6d95bc057bb	output/generated/e9f5d330_ref_modular_20251023_035435.png	e9f5d330_ref_modular_20251023_035435.png	\N	\N	{"job_id": "6ad0627c-5d60-48b6-b0a5-e17850896e80", "variation": 1, "generator": "modular", "subject_image": "data/characters/e9f5d330_ref.png"}	2025-10-23 03:54:35.617103	\N
67	e4c63a29-d5ae-42f4-85ef-24fa7dc0f6ce	output/generated/e9f5d330_ref_modular_20251023_035521.png	e9f5d330_ref_modular_20251023_035521.png	\N	\N	{"job_id": "b15a4266-9c98-4f85-9e54-9b824ffbde07", "variation": 1, "generator": "modular", "subject_image": "data/characters/e9f5d330_ref.png"}	2025-10-23 03:55:21.858051	\N
68	42ceb554-481a-4c8a-a0cd-56dbb84d75c5	output/generated/e9f5d330_ref_modular_20251023_035540.png	e9f5d330_ref_modular_20251023_035540.png	\N	\N	{"job_id": "60965807-ccdf-4d0d-90b4-6b0445d5d081", "variation": 1, "generator": "modular", "subject_image": "data/characters/e9f5d330_ref.png"}	2025-10-23 03:55:40.973734	\N
69	4f732bbd-1589-4586-b775-5e022c0dc8eb	output/generated/e9f5d330_ref_modular_20251023_035541.png	e9f5d330_ref_modular_20251023_035541.png	\N	\N	{"job_id": "a1a8bd21-ade0-4fa0-a222-b1133974ba8c", "variation": 1, "generator": "modular", "subject_image": "data/characters/e9f5d330_ref.png"}	2025-10-23 03:55:41.257734	\N
70	e55ee9e8-5f6e-4f98-a5ca-c9b7c62b7806	output/generated/e9f5d330_ref_modular_20251023_035603.png	e9f5d330_ref_modular_20251023_035603.png	\N	\N	{"job_id": "63a62716-61f7-4b1d-bb16-3d7ee9552072", "variation": 1, "generator": "modular", "subject_image": "data/characters/e9f5d330_ref.png"}	2025-10-23 03:56:03.723673	\N
72	df12b7d5-3fcf-4230-8bc4-2f329b4830b0	output/generated/e9f5d330_ref_modular_20251023_035640.png	e9f5d330_ref_modular_20251023_035640.png	\N	\N	{"job_id": "81c64440-bc4a-4ec7-88a8-1b030995a9be", "variation": 1, "generator": "modular", "subject_image": "data/characters/e9f5d330_ref.png"}	2025-10-23 03:56:40.240941	\N
73	f5ab75ef-b828-4301-9cb6-1a9df004593c	output/generated/e9f5d330_ref_modular_20251023_035659.png	e9f5d330_ref_modular_20251023_035659.png	\N	\N	{"job_id": "7de252ef-1154-4c7f-bfca-b876673d6192", "variation": 1, "generator": "modular", "subject_image": "data/characters/e9f5d330_ref.png"}	2025-10-23 03:56:59.208373	\N
74	806703e8-17e0-4f75-9bd2-7f2780936d73	output/generated/e9f5d330_ref_modular_20251023_035729.png	e9f5d330_ref_modular_20251023_035729.png	\N	\N	{"job_id": "be421b14-55fc-468c-8f47-ea296c9672c6", "variation": 1, "generator": "modular", "subject_image": "data/characters/e9f5d330_ref.png"}	2025-10-23 03:57:29.510151	\N
75	01c552f9-ac5f-4e43-9526-64f76bb75c32	output/generated/165d9c0c_ref_modular_20251023_035756.png	165d9c0c_ref_modular_20251023_035756.png	\N	\N	{"job_id": "f91e94e1-f682-4b00-84ca-f2a4507b6f82", "variation": 1, "generator": "modular", "subject_image": "data/characters/165d9c0c_ref.png"}	2025-10-23 03:57:56.053008	\N
76	ee11d9e1-7d1f-46b8-b775-0d2615d7e524	output/generated/165d9c0c_ref_modular_20251023_035837.png	165d9c0c_ref_modular_20251023_035837.png	\N	\N	{"job_id": "77baf50b-6766-42d1-a853-f4747e846d8f", "variation": 1, "generator": "modular", "subject_image": "data/characters/165d9c0c_ref.png"}	2025-10-23 03:58:37.878954	\N
77	64f617fd-ee2b-4a34-824e-6797b3620658	output/generated/165d9c0c_ref_modular_20251023_035847.png	165d9c0c_ref_modular_20251023_035847.png	\N	\N	{"job_id": "d0c517fd-9c5a-4b48-b417-a29ab31af1b2", "variation": 1, "generator": "modular", "subject_image": "data/characters/165d9c0c_ref.png"}	2025-10-23 03:58:47.734241	\N
78	3819b69e-507a-4623-b124-7fda5bae50be	output/generated/165d9c0c_ref_modular_20251023_035904.png	165d9c0c_ref_modular_20251023_035904.png	\N	\N	{"job_id": "d1b63c7b-2669-471c-b23a-87b38f71a6d8", "variation": 1, "generator": "modular", "subject_image": "data/characters/165d9c0c_ref.png"}	2025-10-23 03:59:04.305698	\N
79	3b617bc4-0759-4ede-b92f-265b3ff758b6	output/generated/165d9c0c_ref_modular_20251023_035922.png	165d9c0c_ref_modular_20251023_035922.png	\N	\N	{"job_id": "84d2b069-0651-4f90-8bdc-3a9ceb52dd77", "variation": 1, "generator": "modular", "subject_image": "data/characters/165d9c0c_ref.png"}	2025-10-23 03:59:22.005313	\N
80	c7336d84-9c64-4460-9732-106696ea8337	output/generated/165d9c0c_ref_modular_20251023_035946.png	165d9c0c_ref_modular_20251023_035946.png	\N	\N	{"job_id": "81db64af-385f-45b4-ab94-f4f8fe8a907b", "variation": 1, "generator": "modular", "subject_image": "data/characters/165d9c0c_ref.png"}	2025-10-23 03:59:46.922699	\N
81	a4d6bca5-54e5-4187-8139-bd4723632b9e	output/generated/165d9c0c_ref_modular_20251023_040009.png	165d9c0c_ref_modular_20251023_040009.png	\N	\N	{"job_id": "84402871-2f01-4867-b1ee-1fc9a62efc6c", "variation": 1, "generator": "modular", "subject_image": "data/characters/165d9c0c_ref.png"}	2025-10-23 04:00:09.390419	\N
83	0b202d3b-30eb-43e1-8ff7-c4cda10813f2	output/generated/41c5726d_ref_modular_20251023_040053.png	41c5726d_ref_modular_20251023_040053.png	\N	\N	{"job_id": "6f6bf031-68b2-4b0b-aed0-c79080dc86ae", "variation": 1, "generator": "modular", "subject_image": "data/characters/41c5726d_ref.png"}	2025-10-23 04:00:53.210463	\N
84	1767ccca-9636-421d-9359-5402407b9673	output/generated/41c5726d_ref_modular_20251023_040112.png	41c5726d_ref_modular_20251023_040112.png	\N	\N	{"job_id": "827aa999-83fe-42e7-b5dd-b43e649a9fb9", "variation": 1, "generator": "modular", "subject_image": "data/characters/41c5726d_ref.png"}	2025-10-23 04:01:12.076259	\N
85	f3e297ed-af77-420e-9881-e537a788ecbb	output/generated/41c5726d_ref_modular_20251023_040127.png	41c5726d_ref_modular_20251023_040127.png	\N	\N	{"job_id": "d45d1912-9449-4c7d-9ee1-5af5ad42b9d9", "variation": 1, "generator": "modular", "subject_image": "data/characters/41c5726d_ref.png"}	2025-10-23 04:01:27.642646	\N
86	e296022e-f16b-4e9a-8fd0-cbe5c2c85d9f	output/generated/41c5726d_ref_modular_20251023_040202.png	41c5726d_ref_modular_20251023_040202.png	\N	\N	{"job_id": "0acc18e6-801c-435d-aeea-bb54065f807d", "variation": 1, "generator": "modular", "subject_image": "data/characters/41c5726d_ref.png"}	2025-10-23 04:02:02.256293	\N
71	ee65688a-24fb-4140-a172-4391a2b88e2a	output/generated/e9f5d330_ref_modular_20251023_035618.png	e9f5d330_ref_modular_20251023_035618.png	\N	\N	{"job_id": "eb67b8bd-a1fe-4cb2-a460-0c0448e74e44", "variation": 1, "generator": "modular", "subject_image": "data/characters/e9f5d330_ref.png"}	2025-10-23 03:56:18.603929	\N
82	de8a0114-050f-4379-9a0d-2d4097c3cbe0	output/generated/165d9c0c_ref_modular_20251023_040035.png	165d9c0c_ref_modular_20251023_040035.png	\N	\N	{"job_id": "0b086ab7-7602-4c50-b1f1-3cd69467f247", "variation": 1, "generator": "modular", "subject_image": "data/characters/165d9c0c_ref.png"}	2025-10-23 04:00:35.812027	\N
87	ec518bcb-b587-4294-8488-77e56b604667	output/generated/8bf67f72_ref_modular_20251023_040219.png	8bf67f72_ref_modular_20251023_040219.png	\N	\N	{"job_id": "aa40ca1e-9eaa-4a23-800d-c27c445844c8", "variation": 1, "generator": "modular", "subject_image": "data/characters/8bf67f72_ref.png"}	2025-10-23 04:02:19.944931	\N
88	51afbf6b-9d27-4185-9cff-37dcf6e3284c	output/generated/ed013856_ref_modular_20251023_040302.png	ed013856_ref_modular_20251023_040302.png	\N	\N	{"job_id": "287724a5-dcb3-41da-b520-bb7f6d4663ef", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 04:03:02.288159	\N
89	35accf4b-ef4b-45d9-9a78-adeb23175c4a	output/generated/ed013856_ref_modular_20251023_040323.png	ed013856_ref_modular_20251023_040323.png	\N	\N	{"job_id": "e9ee3639-36b8-4f78-a0b4-cf10405b5adc", "variation": 1, "generator": "modular", "subject_image": "data/characters/ed013856_ref.png"}	2025-10-23 04:03:23.506141	\N
90	160a2ff8-7399-427b-8e15-6cdba00668a9	output/generated/cc68e0e0_ref_modular_20251023_040414.png	cc68e0e0_ref_modular_20251023_040414.png	\N	\N	{"job_id": "2b333322-64fc-4ea5-9e30-2cd0402edfb2", "variation": 1, "generator": "modular", "subject_image": "data/characters/cc68e0e0_ref.png"}	2025-10-23 04:04:14.164189	\N
91	3d097621-042c-468a-a0f8-3dd0dae21d53	output/generated/1af92043_ref_modular_20251023_040430.png	1af92043_ref_modular_20251023_040430.png	\N	\N	{"job_id": "85941bec-01cf-4fd5-bb75-82eaf52804f5", "variation": 1, "generator": "modular", "subject_image": "data/characters/1af92043_ref.png"}	2025-10-23 04:04:30.989997	\N
92	1368c462-aef6-46c5-ad4e-54074e891529	output/generated/ed394873_ref_modular_20251023_041105.png	ed394873_ref_modular_20251023_041105.png	\N	\N	{"job_id": "7dc1ad44-75be-4f16-af06-84f42ba929c4", "variation": 1, "generator": "modular", "subject_image": "character:ed394873"}	2025-10-23 04:11:05.32674	\N
93	2a8ea10c-a029-4f92-9c4b-22c6b25186f5	output/generated/ed394873_ref_modular_20251023_041118.png	ed394873_ref_modular_20251023_041118.png	\N	\N	{"job_id": "7ce7358f-05cd-49a9-ad20-cb3d3c29df9f", "variation": 1, "generator": "modular", "subject_image": "character:ed394873"}	2025-10-23 04:11:18.697745	\N
94	8db96cf7-70aa-479f-a5fd-2bcb8d347068	output/generated/ed394873_ref_modular_20251023_041257.png	ed394873_ref_modular_20251023_041257.png	\N	\N	{"job_id": "7918620d-2d8f-431a-9e95-fe8fc48afb7c", "variation": 1, "generator": "modular", "subject_image": "character:ed394873"}	2025-10-23 04:12:57.779402	\N
95	e4807b64-2694-4018-b6c2-39c9672cda69	output/generated/ed394873_ref_modular_20251023_041314.png	ed394873_ref_modular_20251023_041314.png	\N	\N	{"job_id": "2ebc14a1-3ee8-483e-a5d8-86ec59221103", "variation": 1, "generator": "modular", "subject_image": "character:ed394873"}	2025-10-23 04:13:14.396953	\N
96	a5697be8-1cab-41a6-b459-5aa1de54d994	output/generated/ed394873_ref_modular_20251023_041454.png	ed394873_ref_modular_20251023_041454.png	\N	\N	{"job_id": "829ea72d-c7e7-44d5-b366-921408a8469c", "variation": 1, "generator": "modular", "subject_image": "character:ed394873"}	2025-10-23 04:14:54.711407	\N
97	323acaed-dbcf-411c-927f-d22f749619a5	output/generated/ed394873_ref_modular_20251023_041521.png	ed394873_ref_modular_20251023_041521.png	\N	\N	{"job_id": "ac6bf299-9549-4887-a0ff-983574dffa47", "variation": 1, "generator": "modular", "subject_image": "character:ed394873"}	2025-10-23 04:15:21.655439	\N
98	1652d3a3-37f3-48a8-b2aa-f8b747954f7a	output/generated/1d191360_ref_modular_20251023_041536.png	1d191360_ref_modular_20251023_041536.png	\N	\N	{"job_id": "59654b9e-43bf-4225-b011-eda67e146415", "variation": 1, "generator": "modular", "subject_image": "character:1d191360"}	2025-10-23 04:15:36.295824	\N
99	5713b65b-5dfc-48e9-ba60-7a8aa8c1635e	output/generated/1d191360_ref_modular_20251023_041556.png	1d191360_ref_modular_20251023_041556.png	\N	\N	{"job_id": "ea0c93d1-016a-46ba-91dc-ee033d250bca", "variation": 1, "generator": "modular", "subject_image": "character:1d191360"}	2025-10-23 04:15:56.291005	\N
\.


--
-- Data for Name: outfits; Type: TABLE DATA; Schema: public; Owner: lifeos
--

COPY public.outfits (id, outfit_id, name, description, style_genre, formality, clothing_item_ids, source_image, preview_image_path, metadata, created_at, updated_at, user_id) FROM stdin;
1	9867921f	Test Outfit	This is a test outfit	\N	\N	["item1", "item2", "item3"]	\N	\N	{}	2025-10-22 23:47:35.636169	2025-10-22 23:47:35.636171	1
\.


--
-- Data for Name: stories; Type: TABLE DATA; Schema: public; Owner: lifeos
--

COPY public.stories (id, story_id, title, content, character_id, theme, story_type, word_count, metadata, created_at, updated_at, user_id) FROM stdin;
\.


--
-- Data for Name: story_scenes; Type: TABLE DATA; Schema: public; Owner: lifeos
--

COPY public.story_scenes (id, scene_id, story_id, scene_number, title, content, action, illustration_prompt, illustration_url, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: lifeos
--

COPY public.users (id, username, email, full_name, hashed_password, disabled, created_at, last_login) FROM stdin;
1	fancymatt	matt@henrymatt.com	\N	$2b$12$sVADYc14qa0Y6SPsnqMGUeVkbLhmAxww9ykGjjbviyykFh64aQGx6	f	2025-10-15 23:46:57.43322	2025-10-23 04:09:49.021588
\.


--
-- Name: board_games_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeos
--

SELECT pg_catalog.setval('public.board_games_id_seq', 1, true);


--
-- Name: characters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeos
--

SELECT pg_catalog.setval('public.characters_id_seq', 13, true);


--
-- Name: clothing_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeos
--

SELECT pg_catalog.setval('public.clothing_items_id_seq', 198, true);


--
-- Name: compositions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeos
--

SELECT pg_catalog.setval('public.compositions_id_seq', 1, true);


--
-- Name: favorites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeos
--

SELECT pg_catalog.setval('public.favorites_id_seq', 1, true);


--
-- Name: image_entity_relationships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeos
--

SELECT pg_catalog.setval('public.image_entity_relationships_id_seq', 545, true);


--
-- Name: images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeos
--

SELECT pg_catalog.setval('public.images_id_seq', 99, true);


--
-- Name: outfits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeos
--

SELECT pg_catalog.setval('public.outfits_id_seq', 1, true);


--
-- Name: stories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeos
--

SELECT pg_catalog.setval('public.stories_id_seq', 1, false);


--
-- Name: story_scenes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeos
--

SELECT pg_catalog.setval('public.story_scenes_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lifeos
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: board_games pk_board_games; Type: CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.board_games
    ADD CONSTRAINT pk_board_games PRIMARY KEY (id);


--
-- Name: characters pk_characters; Type: CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.characters
    ADD CONSTRAINT pk_characters PRIMARY KEY (id);


--
-- Name: clothing_items pk_clothing_items; Type: CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.clothing_items
    ADD CONSTRAINT pk_clothing_items PRIMARY KEY (id);


--
-- Name: compositions pk_compositions; Type: CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.compositions
    ADD CONSTRAINT pk_compositions PRIMARY KEY (id);


--
-- Name: favorites pk_favorites; Type: CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT pk_favorites PRIMARY KEY (id);


--
-- Name: image_entity_relationships pk_image_entity_relationships; Type: CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.image_entity_relationships
    ADD CONSTRAINT pk_image_entity_relationships PRIMARY KEY (id);


--
-- Name: images pk_images; Type: CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT pk_images PRIMARY KEY (id);


--
-- Name: outfits pk_outfits; Type: CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.outfits
    ADD CONSTRAINT pk_outfits PRIMARY KEY (id);


--
-- Name: stories pk_stories; Type: CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT pk_stories PRIMARY KEY (id);


--
-- Name: story_scenes pk_story_scenes; Type: CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.story_scenes
    ADD CONSTRAINT pk_story_scenes PRIMARY KEY (id);


--
-- Name: users pk_users; Type: CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT pk_users PRIMARY KEY (id);


--
-- Name: ix_board_games_bgg_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_board_games_bgg_id ON public.board_games USING btree (bgg_id);


--
-- Name: ix_board_games_game_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE UNIQUE INDEX ix_board_games_game_id ON public.board_games USING btree (game_id);


--
-- Name: ix_board_games_name; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_board_games_name ON public.board_games USING btree (name);


--
-- Name: ix_board_games_user_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_board_games_user_id ON public.board_games USING btree (user_id);


--
-- Name: ix_boardgame_bgg_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_boardgame_bgg_id ON public.board_games USING btree (bgg_id);


--
-- Name: ix_boardgame_user_name; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_boardgame_user_name ON public.board_games USING btree (user_id, name);


--
-- Name: ix_character_user_id_name; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_character_user_id_name ON public.characters USING btree (user_id, name);


--
-- Name: ix_characters_character_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE UNIQUE INDEX ix_characters_character_id ON public.characters USING btree (character_id);


--
-- Name: ix_characters_name; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_characters_name ON public.characters USING btree (name);


--
-- Name: ix_characters_user_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_characters_user_id ON public.characters USING btree (user_id);


--
-- Name: ix_clothing_items_category; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_clothing_items_category ON public.clothing_items USING btree (category);


--
-- Name: ix_clothing_items_item_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE UNIQUE INDEX ix_clothing_items_item_id ON public.clothing_items USING btree (item_id);


--
-- Name: ix_clothing_items_user_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_clothing_items_user_id ON public.clothing_items USING btree (user_id);


--
-- Name: ix_clothing_user_category; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_clothing_user_category ON public.clothing_items USING btree (user_id, category);


--
-- Name: ix_composition_name; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_composition_name ON public.compositions USING btree (name);


--
-- Name: ix_composition_user_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_composition_user_id ON public.compositions USING btree (user_id);


--
-- Name: ix_compositions_composition_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE UNIQUE INDEX ix_compositions_composition_id ON public.compositions USING btree (composition_id);


--
-- Name: ix_compositions_user_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_compositions_user_id ON public.compositions USING btree (user_id);


--
-- Name: ix_favorite_unique; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE UNIQUE INDEX ix_favorite_unique ON public.favorites USING btree (user_id, category, preset_id);


--
-- Name: ix_favorite_user_category; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_favorite_user_category ON public.favorites USING btree (user_id, category);


--
-- Name: ix_favorites_category; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_favorites_category ON public.favorites USING btree (category);


--
-- Name: ix_favorites_user_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_favorites_user_id ON public.favorites USING btree (user_id);


--
-- Name: ix_image_entity_relationships_entity_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_image_entity_relationships_entity_id ON public.image_entity_relationships USING btree (entity_id);


--
-- Name: ix_image_entity_relationships_entity_type; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_image_entity_relationships_entity_type ON public.image_entity_relationships USING btree (entity_type);


--
-- Name: ix_image_entity_relationships_image_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_image_entity_relationships_image_id ON public.image_entity_relationships USING btree (image_id);


--
-- Name: ix_image_entity_relationships_role; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_image_entity_relationships_role ON public.image_entity_relationships USING btree (role);


--
-- Name: ix_image_user_created; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_image_user_created ON public.images USING btree (user_id, created_at);


--
-- Name: ix_images_image_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE UNIQUE INDEX ix_images_image_id ON public.images USING btree (image_id);


--
-- Name: ix_images_user_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_images_user_id ON public.images USING btree (user_id);


--
-- Name: ix_outfits_outfit_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE UNIQUE INDEX ix_outfits_outfit_id ON public.outfits USING btree (outfit_id);


--
-- Name: ix_outfits_user_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_outfits_user_id ON public.outfits USING btree (user_id);


--
-- Name: ix_relationship_entity; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_relationship_entity ON public.image_entity_relationships USING btree (entity_type, entity_id);


--
-- Name: ix_relationship_image; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_relationship_image ON public.image_entity_relationships USING btree (image_id);


--
-- Name: ix_relationship_unique; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE UNIQUE INDEX ix_relationship_unique ON public.image_entity_relationships USING btree (image_id, entity_type, entity_id, role);


--
-- Name: ix_scene_story_number; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_scene_story_number ON public.story_scenes USING btree (story_id, scene_number);


--
-- Name: ix_stories_character_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_stories_character_id ON public.stories USING btree (character_id);


--
-- Name: ix_stories_story_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE UNIQUE INDEX ix_stories_story_id ON public.stories USING btree (story_id);


--
-- Name: ix_stories_user_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_stories_user_id ON public.stories USING btree (user_id);


--
-- Name: ix_story_scenes_scene_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE UNIQUE INDEX ix_story_scenes_scene_id ON public.story_scenes USING btree (scene_id);


--
-- Name: ix_story_scenes_story_id; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE INDEX ix_story_scenes_story_id ON public.story_scenes USING btree (story_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: lifeos
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: board_games fk_board_games_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.board_games
    ADD CONSTRAINT fk_board_games_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: characters fk_characters_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.characters
    ADD CONSTRAINT fk_characters_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: clothing_items fk_clothing_items_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.clothing_items
    ADD CONSTRAINT fk_clothing_items_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: compositions fk_compositions_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.compositions
    ADD CONSTRAINT fk_compositions_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: favorites fk_favorites_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT fk_favorites_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: image_entity_relationships fk_image_entity_relationships_image_id_images; Type: FK CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.image_entity_relationships
    ADD CONSTRAINT fk_image_entity_relationships_image_id_images FOREIGN KEY (image_id) REFERENCES public.images(image_id);


--
-- Name: images fk_images_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT fk_images_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: outfits fk_outfits_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.outfits
    ADD CONSTRAINT fk_outfits_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: stories fk_stories_character_id_characters; Type: FK CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT fk_stories_character_id_characters FOREIGN KEY (character_id) REFERENCES public.characters(character_id);


--
-- Name: stories fk_stories_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT fk_stories_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: story_scenes fk_story_scenes_story_id_stories; Type: FK CONSTRAINT; Schema: public; Owner: lifeos
--

ALTER TABLE ONLY public.story_scenes
    ADD CONSTRAINT fk_story_scenes_story_id_stories FOREIGN KEY (story_id) REFERENCES public.stories(story_id);


--
-- PostgreSQL database dump complete
--

\unrestrict oB2pJ2mm1B2BDDjdWCFufQGTIqiKvMjvob5BpZhu7xbxS36OJURv5fVX6HgIDw0

